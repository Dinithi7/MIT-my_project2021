<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

</head>
<body>
<div class="container">
<?php
foreach($data2 as $row){
//?>
<form id="myForm" method="post">
<table class="table">



<tr>
<div class="form-group">
<td><label for="FirstName">FirstName:</label></td>
<td><input type="text" class="form-control"  id="FN" name="FirstName" value="<?php echo $row->FirstName;?>"></td>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="LastName">LastName:</label></td>
<td><input type="text" class="form-control" id="LN" name="LastName" value="<?php echo $row->LastName;?>"></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="SupplierName"> Supplier Name:</label></td>
<td><input type="text" class="form-control" id="SupplierName" name="SupplierName" value="<?php echo $row->SupplierName;?>"></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Address">Address:</label></td>
<td><input type="text" class="form-control" id="Address" name="Address" value="<?php echo $row->Address;?>"></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="LandLine">Land Line:</label></td>
<td><input type="text" class="form-control" id="LandLine" name="LandLine" value="<?php echo $row->LandLine;?>"></td>
</div>
</tr>
<tr>
<tr>
<div class="form-group">
<td><label for="MobileNo"> Mobile No:</label></td>
<td><input type="text" class="form-control" id="MobileNo" name="MobileNo" value="<?php echo $row->MobileNo;?>"></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Email">E-Mail:</label></td>
<td><input type="text"  class="form-control" id="Email" name="Email" value="<?php echo $row->Email;?>"></td>
</tr>

</table>
<label>Status</label>
<select class="form-control" name="Status"  value= "<?php echo  $row->Status; ?>">
<option value="<?php echo $row->Status;?>" selected><?php echo $row->Status;?></option>

<option value="<?php echo "Activated";?>"><?php echo "Activated";?></option>
<option value="<?php echo "Deactivated";?>"><?php echo "Deactivated";?></option>

</select> <br/>
	<input type="submit" class="btn btn-info" name= "update" value="Update Supplier">
</tr>
</form>


<?php
} ?>

</body>
</html>