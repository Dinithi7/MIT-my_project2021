<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Schedule Home-Visit Repair</h1>

</head>
<body>
  
<div class="container">
<?php
foreach($data1 as $row){
//?>
<form id="myForm1" method="post">
<table class="table">



<tr>
<div class="form-group">
<td><label for="FaultID">FaultID:</label></td>
<td><input type="text" class="form-control" id="FaultID" name="FaultID" value="<?php echo $row->FaultID;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="ItemName">ItemName:</label></td>
<td><input type="text" class="form-control" id="ItemName" name="ItemName" value="<?php echo $row->ItemName;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Fault">Fault:</label></td>
<td><input type="text"  class="form-control" id="Fault" name="Fault" value="<?php echo $row->Fault;?>"disabled></td>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="TotalCost">TotalCost:</label></td>
<td><input type="text" class="form-control" id="TotalCost" name="TotalCost" value="<?php echo $row->TotalCost;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="TimeToRepair"> Time To Repair(Hours):</label></td>
<td><input type="text" class="form-control" id="TimeToRepair" name="TimeToRepair" value="<?php echo $row->TimeToRepair;?>"disabled></td>
</div>
</tr>



</form>
<?php
} ?>

<form method="post">
<table class="table">
<div class="container">


<tr>
<div class="form-group">
      <label for="Warranty">Warranty</label>
      <select class="form-control" id="Warranty" name="Warranty">
        <option>Yes</option>
        <option>No</option>
      </select>

</div>
<tr>


<div class="form-group">
<td><label for="ScheduledDate"> Date for Repair:</label></td>
<td><input type="date" class="form-control" id="ScheduledDate" name="ScheduledDate" value="<?php echo set_value('ScheduledDate');?>"/></td>
<?php if(form_error('ScheduledDate'))
{
echo "<span style='color:red'>".form_error('ScheduledDate')."</span>";
}
?>
</div>
</table>

	<input type="submit" class="btn btn-info"   value="Schedule"  name="save">

</script>
</form>

</body>
</html>