<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

<h1 align="center";> Update Home Visit Schedules</h1>


</head>
<body>

<div class="container">
<?php
foreach($data8 as $row){
//?>
<form id="myForm" method="post">
<table class="table">
<p>The Last Scheduled Details of the Technician you selected are listed below.</p>
<tr>
<div class="form-group">
<td><label for="EmpID1">Emp ID :</label></td>
<td><input type="text" class="form-control" rows="3" id="EmpID1" name="EmpID1" value="<?php echo $row->EmpID ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Technician1">Technician :</label></td>
<td><input type="text" class="form-control" rows="3" id="Technician1" name="Technician1" value="<?php echo $row->Technician ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="DateOFRepair1">DateOfRepair :</label></td>
<td><input type="text" class="form-control" rows="3" id="DateOFRepair1" name="DateOFRepair1" value="<?php echo $row->DateOFRepair ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="LStartTime">Last StartTime :</label></td>
<td><input type="time" class="form-control" rows="3" id="LStartTime" name="LStartTime" value="<?php echo $row->StartTime ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="LEndTime">Last EndTime :</label></td>
<td><input type="time" class="form-control" rows="3" id="LEndTime" name="LEndTime" value="<?php echo $row->EndTime ;?>"disabled></td>
</div>
</tr>



<tr>
<?php
} ?>
<div class="container">
<?php
foreach($data7 as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<p>The HomeVisit request details are as follows.</p>
<tr>
<div class="form-group">
<td><label for="VisitJobID">VisitJob ID :</label></td>
<td><input type="text" class="form-control" rows="3" id="VisitJobID " name="VisitJobID" value="<?php echo $row->VisitJobID ;?>"disabled></td>
</div>
</tr>
<tr>
<tr>
<div class="form-group">
<td><label for="FaultID">Fault ID :</label></td>
<td><input type="text" class="form-control" rows="3" id="FaultID " name="FaultID" value="<?php echo $row->FaultID ;?>"disabled></td>
</div>
</tr>
<tr>
<tr>
<div class="form-group">
<td><label for="ItemName ">ItemName :</label></td>
<td><input type="text" class="form-control" rows="3" id="ItemName " name="ItemName" value="<?php echo $row->ItemName ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Fault ">Fault :</label></td>
<td><input type="text" class="form-control" rows="3" id="Fault " name="Fault" value="<?php echo $row->Fault ;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="CustomerID">CustomerID :</label></td>
<td><input type="text" class="form-control" rows="3" id="CustomerID " name="CustomerID" value="<?php echo $row->CustomerID ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Email">Email :</label></td>
<td><input type="text" class="form-control" rows="3" id="Email" name="Email" value="<?php echo $row->Email ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Address">Address :</label></td>
<td><input type="text" class="form-control" rows="3" id="Address" name="Address" value="<?php echo $row->Address;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Warranty">Warranty:</label></td>
<td><input type="text"  class="form-control" id="Warranty" name="Warranty" value="<?php echo $row->Warranty;?>"disabled></td>
</div>
</tr>
<tr>
<tr>
<div class="form-group">
<td><label for="DateOfRepair">Date Of Repair:</label></td>
<td><input type="date"  class="form-control" id="DateOfRepair" name="DateOfRepair" value="<?php echo $row->DateOfRepair;?>" disabled></td>
</div>
</tr>


<?php
} ?>
<div class="container">
</form>
<form id="myForm2" method="post">
<table class="table">
<div class="form-group">

<label>Status</label>
<select class="form-control" name="SStatus" id="SStatus" value= "">
<option value="">Select Status</option>
<option value="<?php echo "Scheduled";?>"><?php echo "Scheduled";?></option>
<option value="<?php echo "Rejected";?>"><?php echo "Rejected";?></option>


</select> <br/>







<label>Technician</label>
<select class="form-control" name="EmpID" id="EmpID" value= "<?php echo set_value($Technician['EmpID']); ?>" required>
 <option value="">Select Technician</option>'
    <?php
    foreach($groups as $Technician)
    {
     
        echo '<option value="'.$Technician['EmpID'].'">'.$Technician['Technician'].'</option>';
        
    }
    ?>  
   

</select> <br/>
<?php if(form_error('EmpID'))
{
echo "<span style='color:red'>".form_error('EmpID')."</span>";
}
?>

</table>



	<input type="submit" class="btn btn-info" name= "update" value="Update Home Visit Schedule">
	
  




</form>




</body>
</html>