<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h6 align="left"><a href="<?= site_url('repairs_controller/displaydata'); ?>" > Go back </a></h6>
</head>
<body>
<div class="container">
<?php
foreach($data2 as $row){
//?>
<form id="myForm" method="post">
<table class="table">
<h1 align="center";> Update Item For Repair</h1>
<tr>
<div class="form-group">
<td><label for="CustomerID">CustomerID :</label></td>
<td><input type="text" class="form-control" rows="3" id="CustomerID " name="CustomerID " value="<?php echo $row->CustomerID ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Email "> Email :</label></td>
<td><input type="text" class="form-control" rows="3" id="Email " name="Email " value="<?php echo $row->Email ;?>"disabled></td>
</div>
</tr>
<?php
} ?>
<div class="container">
<?php
foreach($data1 as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="ItemName ">ItemName :</label></td>
<td><input type="text" class="form-control" rows="3" id="ItemName " name="ItemName " value="<?php echo $row->ItemName ;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Fault ">Fault :</label></td>
<td><input type="text" class="form-control" rows="3" id="Fault " name="Fault " value="<?php echo $row->Fault ;?>"disabled></td>
</div>
</tr>
<?php
} ?>


<div class="container">
<?php
foreach($data as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="Fault">Description :</label></td>
<td><input type="text" class="form-control" rows="3" id="Description" name="Description" value="<?php echo $row->Description;?>" disabled></td>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="ContactNo">Contact No:</label></td>
<td><input type="text" class="form-control" id="ContactNo" name="ContactNo" value="<?php echo $row->ContactNo;?>" disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="AcceptDate">Accept Date:</label></td>
<td><input type="date" class="form-control" id="AcceptDate" name="AcceptDate" value="<?php echo $row->AcceptDate;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="ReturnDate">Return Date:</label></td>
<td><input type="date" class="form-control" id="ReturnDate" name="ReturnDate" value="<?php echo $row->ReturnDate;?>"></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Warranty">Warranty:</label></td>
<td><input type="text"  class="form-control" id="Warranty" name="Warranty" value="<?php echo $row->Warranty;?>"disabled></td>
</tr>
<tr>
<div class="form-group">
<td><label for="TotalCost">Total Cost:</label></td>
<td><input type="text"  class="form-control" id="TotalCost" name="TotalCost" value="<?php echo $row->TotalCost;?>"disabled></td>
</tr>

<tr>
<div class="form-group">
<td><label for="AdvancePaid">Advance Paid:</label></td>
<td><input type="text"  class="form-control" id="AdvancePaid" name="AdvancePaid" value="<?php echo $row->AdvancePaid;?>"disabled></td>
</tr>

<tr>
<div class="form-group">
<td><label for="Balance">Balance:</label></td>
<td><input type="text"  class="form-control" id="Balance" name="Balance" value="<?php echo $row->Balance?>"disabled></td>
</tr>
</table>
<label>Technician</label>
<select class="form-control" name="Technician" id="Technician"  value= "<?php echo $Technician['EmpID']; ?>">
<option value="<?php echo $row->EmpID;?>" selected><?php echo $row->Technician;?></option>
    <?php
    foreach($groups as $Technician)
    {
      
      echo '<option value="'.$Technician['EmpID'].'">'.$Technician['Technician'].'</option>';
        
    }
    ?>  

</select> <br/>

<label>Status</label>
<select class="form-control" name="Status"  value= "<?php echo  $row->Status; ?>">
<option value="<?php echo $row->Status;?>" selected><?php echo $row->Status;?></option>
<option value="<?php echo "Accepted";?>"><?php echo "Accepted";?></option>
<option value="<?php echo "Ready";?>"><?php echo "Ready";?></option>
<option value="<?php echo "Delayed";?>"><?php echo "Delayed";?></option>
<option value="<?php echo "Delivered";?>"><?php echo "Delivered";?></option>
</select> <br/>

	<input type="submit" class="btn btn-info" name= "update" value="Update Item">
	




</table>
</form>



<?php
} ?>
</body>
</html>