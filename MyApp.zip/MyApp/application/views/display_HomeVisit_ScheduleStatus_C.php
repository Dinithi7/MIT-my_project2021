<!DOCTYPE html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
<h1 align="center";> View Home-Visit Repair Status</h1>
<div class="container">
<p> You can check the status of your request through this page.  If the Request is rejected, scheduled or cancelled,it will be displayed here.</p>
<table class="table table-bordered">
<tr>
<th>VisitJobID</th>
<th>FaultID</th>
<th>ItemName</th>
<th>Fault</th>
<th>CustomerID</th>
<th>Address</th>
<th>Email</th>
<th>Warranty</th>
<th>DateOfRepair</th>

<th>Technician</th>
<th>StartTime</th>
<th>EndTime</th>
<th>ScheduleStatus</th>

</tr>
<?php
foreach($data3 as $row){
echo "<tr>";
echo "<td>".$row->VisitJobID."</td>";
echo "<td>".$row->FaultID."</td>";
echo "<td>".$row->ItemName."</td>";
echo "<td>".$row->Fault."</td>";
echo "<td>".$row->CustomerID."</td>";
echo "<td>".$row->Address."</td>";
echo "<td>".$row->Email."</td>";
echo "<td>".$row->Warranty."</td>";
echo "<td style='background-color:lightblue;'>".$row->DateOfRepair."</td>";

echo "<td>".$row->Technician."</td>";
echo "<td>".$row->StartTime."</td>";
echo "<td>".$row->EndTime."</td>";

if ($row->ScheduleStatus=="Requested")
{
  echo "<td style='background-color:lightblue;'>".$row->ScheduleStatus."</td>"; 
}

else if ($row->ScheduleStatus=="Scheduled")
{
  echo "<td style='background-color:#00FF00;'>".$row->ScheduleStatus."</td>"; 
}
else if ($row->ScheduleStatus=="Rejected")
{
  echo "<td style='background-color:red;'>".$row->ScheduleStatus."</td>"; 
}

//echo "<td><a href='deletedata?ModelNo=".$row->ModelNo."'>Delete</a></td>";

echo "</tr>";
}
?>
</table>
</div>



</body>
</html>