<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<style>
.vertical-menu {
  width: 200px; /* Set a width if you like */
}

.vertical-menu a {
  background-color: #eee; /* Grey background color */
  color: black; /* Black text color */
  display: block; /* Make the links appear below each other */
  padding: 12px; /* Add some padding */
  text-decoration: none; /* Remove underline from links */
}

.vertical-menu a:hover {
  background-color: #ccc; /* Dark grey background on mouse-over */
}

.vertical-menu a.active {
  background-color: #4CAF50; /* Add a green color to the "active/current" link */
  color: white;
}
</style>


</style>
<!---------------------------------------->
<script>
function setActiveLink(setActive){
    if ($("a").hasClass('active'))
        $("a").removeClass('active');
    if (setActive)
        $("#"+setActive).addClass('active');
}

$(function() {
    $("a").click(function() {
        setActiveLink(this.id);
    });
});
</script>
<!----------------------------------->

<h1 text-align="left";> Customer Profile Page</h1>
</head>
<body>


<iframe src="" align="right" name="iframe_a"  style="height:600px;width:1100px;visibility: visible; box-sizing: content-box;" title="Iframe Example"></iframe>

<div class="vertical-menu">
<a id="link1" href="<?= site_url('products/'); ?>">Purchase Items</a>
<a id="link2" href="<?= site_url('login1_controller/UpdateCustomerDetails_C'); ?>" target="iframe_a">Update Personal Details</a>
<a id="link3" href="<?= site_url('Repairs_Controller/displayfaultsToHomeVisits'); ?>" target="iframe_a">Schedule Home Visit Repair</a>
<a id="link4" href="<?= site_url('login1_controller/ViewHomeVisitRequestScheduleStatus'); ?>" target="iframe_a">Check Status of HomeVisit Schedule </a>
<a id="link5" href="<?= site_url('login1_controller/ViewHandedOverJobStatusToCustomer'); ?>" target="iframe_a">Check Status of Repair </a>
<a id="link6" href="<?= site_url('Customers_Controller/ViewOrderHistory'); ?>">View Order History</a>
<a id="link7" href="<?= site_url('Customers_Controller/viewWarrantyExpires'); ?>" target="iframe_a">Warranty Details</a>
<a id="link8" href="<?= site_url('login1_controller/change_password'); ?>" target="iframe_a">Change Password</a>
<a id="link9" href="<?= site_url('login1_controller/DeactivateAccount'); ?>" target="iframe_a">Deactivate My Account</a>
</div>



</body>
</html>