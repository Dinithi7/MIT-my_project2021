<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Update Personal Details</h1>
</head>
<body>
<div class="container">
<?php
foreach($data2 as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="EmpID">Employee ID:</label></td>
<td><input type="text" class="form-control"  id="EmpID" name="EmpID" value="<?php echo $row->EmpID;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="FirstName">FirstName:</label></td>
<td><input type="text" class="form-control"  id="FN" name="FirstName" value="<?php echo $row->FirstName;?>"disabled></td>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="LastName">LastName:</label></td>
<td><input type="text" class="form-control" id="LN" name="LastName" value="<?php echo $row->LastName;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="NICNo">NIC Number:</label></td>
<td><input type="text" class="form-control" id="NICNo" name="NICNo" value="<?php echo $row->NIC;?>"></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Address">Address:</label></td>
<td><input type="text" class="form-control" id="Address" name="Address" value="<?php echo $row->Address;?>"></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="ContactNo">ContactNo:</label></td>
<td><input type="text" class="form-control" id="ContactNo" name="ContactNo" value="<?php echo $row->ContactNo;?>"></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Gender">Gender:</label></td>
<td><input type="text"  class="form-control" id="Gender" name="Gender" value="<?php echo $row->Gender;?>" disabled></td>
</tr>
<tr>
<div class="form-group">
<td><label for="DateOfBirth">Date-Of-Birth:</label></td>
<td><input type="date"  class="form-control" id="DateOfBirth" name="DateOfBirth" value="<?php echo $row->DateOfBirth;?>" disabled></td>
</tr>
<tr>
<div class="form-group">
<td><label for="DateJoined">Date Joined:</label></td>
<td><input type="date"  class="form-control" id="DateJoined" name="DateJoined" value="<?php echo $row->DateJoined;?>" disabled></td>
</tr>
<tr>
<div class="form-group">
<td><label for="Email">E-Mail:</label></td>
<td><input type="text"  class="form-control" id="Email" name="Email" value="<?php echo $row->Email;?>"disabled></td>
</tr>


</table>
<p> Note: If you wish to update FirstName, LastName and E-mail address please contact the Administrator </p>

	<input type="submit" class="btn btn-info" name= "update" value="Update My Details">
</tr>
</form>


<?php
} ?>

</body>
</html>