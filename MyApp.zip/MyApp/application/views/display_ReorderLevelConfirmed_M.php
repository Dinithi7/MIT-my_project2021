<!DOCTYPE html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<h6 align="left"><a href="<?= site_url('login1_Controller/enter'); ?>" > Go back to Profile Page</a></h6>
<body>
<h1 align="center";> Confirmed Requests</h1>
<div class="container">

<table class="table table-bordered">
<tr>
<th>RequestID</th>
<th>ModelNo</th>
<th>ProductName</th>
<th>ProductBrand</th>
<th>SupplierID</th>
<th>SupplierName</th>
<th>Date Required</th>
<th>Date of Supply</th>
<th>Quantity Needed</th>
<th>Quantity Suppliable</th>
<th>Unit Price</th>
<th>RequestStatus</th>

<th>Send Email</th>
</tr>
<?php
foreach($data1 as $row){
echo "<tr>";
echo "<td>".$row->RequestID."</td>";
echo "<td>".$row->ModelNo."</td>";
echo "<td>".$row->ProductName."</td>";
echo "<td>".$row->ProductBrand."</td>";
echo "<td>".$row->SupplierID."</td>";
echo "<td>".$row->SupplierName."</td>";
echo "<td>".$row->DateRequired."</td>";
echo "<td>".$row->DateOfSupply."</td>";
echo "<td>".$row->QuantityNeeded."</td>";
echo "<td>".$row->QuantityAvailable."</td>";
echo "<td>".$row->UnitPrice."</td>";
echo "<td style='background-color:#00FF00;'>".$row->RequestStatus."</td>"; 





echo "<td><a href='sendInvoice?RequestID=".$row->RequestID."'>Send Invoice</a></td>";
echo "</tr>";
}
?>
</table>
</div>
</body>
</html>