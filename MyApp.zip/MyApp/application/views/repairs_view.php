<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h6 align="left"><a href="<?= site_url('login1_Controller/enter'); ?>" > Go back to Profile Page</a></h6>
<h1 align="center";> Accept Repairs</h1>

</head>
<body>
  
<div class="container">
<?php
foreach($data1 as $row){
//?>
<form id="myForm1" method="post">
<table class="table">



<tr>
<div class="form-group">
<td><label for="FaultID">FaultID:</label></td>
<td><input type="text" class="form-control" id="FaultID" name="FaultID" value="<?php echo $row->FaultID;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="ItemName">ItemName:</label></td>
<td><input type="text" class="form-control" id="ItemName" name="ItemName" value="<?php echo $row->ItemName;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Fault">Fault:</label></td>
<td><input type="text"  class="form-control" id="Fault" name="Fault" value="<?php echo $row->Fault;?>"disabled></td>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="TotalCost">TotalCost:</label></td>
<td><input type="text" class="form-control" id="TotalCost" name="TotalCost" value="<?php echo $row->TotalCost;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="TimeToRepair"> Time To Repair(Hours):</label></td>
<td><input type="text" class="form-control" id="TimeToRepair" name="TimeToRepair" value="<?php echo $row->TimeToRepair;?>"disabled></td>
</div>
</tr>



</form>
<?php
} ?>

<form method="post">
<table class="table">
<div class="container">


<tr>
<div class="form-group">
<td><label for="Description">Item Description:</label></td>
<td><textarea class="form-control" rows=""2 id="Description" name="Description" value="<?php echo set_value('Description');?>"/></textarea></td>
<?php if(form_error('Description'))
{
echo "<span style='color:red'>".form_error('Description')."</span>";
}
?>
</div>
</tr>
<div class="form-group">

<label>Contact Number</label>
<select class="form-control" name="ContactNo" id="ContactNo" value= "<?php echo set_value($ContactNo['ContactNo']); ?>" required>
 <option value="">Select Contact No</option>'
    <?php
    foreach($ContactNo as $ContNo)
    {
     
        echo '<option value="'.$ContNo['ContactNo'].'">'.$ContNo['ContactNo'].'</option>';
        
    }
    ?>  
   

</select> <br/>
<?php if(form_error('EmpID'))
{
echo "<span style='color:red'>".form_error('EmpID')."</span>";
}
?>



<tr>
<div class="form-group">
<td><label for="AcceptDate">Accept Date:</label></td>
<td><input type="date" class="form-control" id="AcceptDate" name="AcceptDate" value="<?php echo set_value('AcceptDate');?>"/></td>
<?php if(form_error('AcceptDate'))
{
echo "<span style='color:red'>".form_error('AcceptDate')."</span>";
}
?>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="ReturnDate">Return Date:</label></td>
<td><input type="date"  class="form-control" id="ReturnDate" name="ReturnDate" value="<?php echo set_value('ReturnDate');?>"/></td>
<?php if(form_error('ReturnDate'))
{
echo "<span style='color:red'>".form_error('ReturnDate')."</span>";
}
?>
</div>
</tr>
<tr>
<div class="form-group">
      <label for="select">Warranty</label>
      <select class="form-control" id="Warranty" name="Warranty">
      
        <option>Yes</option>
        <option>No</option>
      </select>

</div>
</tr>
<tr>
<div class="form-group">
<td><label for="AdvancePaid">Advance Paid:</label></td>
<td><input type="text"  class="form-control" id="AdvancePaid" name="AdvancePaid" value="<?php echo set_value('AdvancePaid');?>"/></td>
<?php if(form_error('AdvancePaid'))
{
echo "<span style='color:red'>".form_error('AdvancePaid')."</span>";
}
?>
</div>
</tr>
</table>

<div class="form-group">

<label>Technician</label>
<select class="form-control" name="EmpID" id="EmpID" value= "<?php echo set_value($Technician['EmpID']); ?>" required>
 <option value="">Select Technician</option>'
    <?php
    foreach($groups as $Technician)
    {
     
        echo '<option value="'.$Technician['EmpID'].'">'.$Technician['Technician'].'</option>';
        
    }
    ?>  
   

</select> <br/>
<?php if(form_error('EmpID'))
{
echo "<span style='color:red'>".form_error('EmpID')."</span>";
}
?>


<div class="form-group">
      <label for="select">Select Status of Item (select one):</label>
      <select class="form-control" id="select" name="select">
        <option>Accepted</option>
        <option>Ready</option>
        <option>Delayed</option>
        <option>Delivered</option>
        
      </select>

</div>

	<input type="submit" class="btn btn-info" value="Add Item" name="save">
	



</form>

</body>
</html>