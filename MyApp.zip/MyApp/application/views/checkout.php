<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h6 align="left"><a href="<?php echo base_url('index.php/cart/'); ?>"> Go back </a></h6>
</head>
<h1>CHECKOUT</h1>
<div class="checkout">
    <div class="row">
        <?php if(!empty($error_msg)){ ?>
        <div class="col-md-12">
            <div class="alert alert-danger"><?php echo $error_msg; ?></div>
        </div>
        <?php } ?>
		
        <div class="col-md-4 order-md-2 mb-4">
            <h4 class="d-flex justify-content-between align-items-center mb-3">
                <span class="text-muted">Items in Your Cart:</span>
                <span class="badge badge-secondary badge-pill"><?php echo $this->cart->total_items(); ?></span>
            </h4>
            <ul class="list-group mb-3">
                <?php if($this->cart->total_items() > 0){ foreach($cartItems as $item){ ?>
                <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <div>
                        
                    <?php $imageURL = !empty($item["image"])?base_url('uploads/'.$item["image"]):base_url('uploads/'.$item["image"]); ?>
            <img src="<?php echo $imageURL; ?>" width="50"/>
                        <h6 class="my-0"><?php echo $item["name"]; ?></h6>
                        <small class="text-muted"><?php echo 'Rs.'.$item["price"]; ?>(<?php echo $item["qty"]; ?>)</small>
                    </div>
                    <span class="text-muted"><?php echo 'Rs.'.$item["subtotal"]; ?></span>
                </li>
				            <?php } }else{ ?>
                <li class="list-group-item d-flex justify-content-between lh-condensed">
                    <p>No items in your cart...</p>
                </li>
                <?php } ?>
                <li class="list-group-item d-flex justify-content-between">
                    <span>Total </span>
                    <strong><?php echo 'Rs.'.$this->cart->total(); ?></strong>
                </li>
            </ul>
            <a href="<?php echo base_url('index.php/products/'); ?>" class="btn btn-block btn-info">Add More Items</a>
        </div>
        <div class="col-md-8 order-md-1">
            <h4 class="mb-3">Contact Details</h4>
            <form method="post">
                <div class="mb-3">
                    <label for="FirstName">FirstName</label>
                    <input type="text" class="form-control" name="FirstName" value="<?php echo !empty($custData['FirstName'])?$custData['FirstName']:''; ?>" placeholder="Enter FirstName" required>
                    <?php if(form_error('FirstName'))
                    {
                    echo "<span style='color:red'>".form_error('FirstName')."</span>";
                    }
                    ?>
                </div>
                <div class="mb-3">
                    <label for="LastName">LastName</label>
                    <input type="text" class="form-control" name="LastName" value="<?php echo !empty($custData['LastName'])?$custData['LastName']:''; ?>" placeholder="Enter LastName" required>
                    <?php if(form_error('CustomerName'))
                    {
                    echo "<span style='color:red'>".form_error('LastName')."</span>";
                    }
                    ?>
                </div>
                <div class="mb-3">
                    <label for="Address">Address</label>
                    <input type="text" class="form-control" name="Address" value="<?php echo !empty($custData['Address'])?$custData['Address']:''; ?>" placeholder="Enter address" required>
                    <?php if(form_error('Address'))
                    {
                    echo "<span style='color:red'>".form_error('Address')."</span>";
                    }
                    ?>
                </div>
                <div class="mb-3">
                    <label for="ContactNo">ContactNo</label>
                    <input type="text" class="form-control" name="ContactNo" value="<?php echo !empty($custData['ContactNo'])?$custData['ContactNo']:''; ?>" placeholder="Enter contact no" required>
                    <?php if(form_error('ContactNo'))
                    {
                    echo "<span style='color:red'>".form_error('ContactNo')."</span>";
                    }
                    ?>
                </div>
                <div class="mb-3">
                    <label for="Email">Email</label>
                    <input type="email" class="form-control" name="Email" value="<?php echo !empty($custData['Email'])?$custData['Email']:''; ?>" placeholder="Enter email" required>
                    <?php if(form_error('Email'))
                    {
                    echo "<span style='color:red'>".form_error('Email')."</span>";
                    }
                    ?>
                </div>
                
                
                <input class="btn btn-success btn-lg btn-block" type="submit" name="placeOrder" value="Place Order">
                
            </form>
        </div>
    </div>
</div>