<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<h6 align="left"><a href="<?= site_url('login1_Controller/enter'); ?>" > Go back to Profile Page</a></h6>
<h1 align="center";> Invoice </h1>
<body>
<div class="container">
<table class="table">
<?php
echo "<tr>";
echo "<td> From: Antenna House, Kadawatha</td>";
echo "</tr>";

echo "<tr>";
echo "<td> Contact No: 0771234567</td>";
echo "</tr>";

$date=date('Y-m-d');
echo "<tr>";
echo "<td> Date:   $date</td>";


echo "</tr>";
?>
<table class="table table-bordered">
<?php
foreach($data10 as $row){


echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> Invoice No</td>";

echo "<td style='font-size:16'>". $row['InvoiceNo'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> VisitJobID</td>";
echo "<td style='font-size:16'>" . $row['VisitJobID'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> Customer Name</td>";
echo "<td style='font-size:16'>" . $row['Customer'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> Customer E-Mail</td>";
echo "<td style='font-size:16'>" . $row['Email'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> Customer Address</td>";
echo "<td style='font-size:16'>" . $row['Address'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> Technician</td>";
echo "<td style='font-size:16'>" . $row['Technician'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'>Technician's NIC</td>";
echo "<td style='font-size:16'>" . $row['NIC'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16' >Item Name</td>";
echo "<td style='font-size:16'>" . $row['ItemName'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'>Fault</td>";
echo "<td style='font-size:16'>" . $row['Fault'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'>Warranty</td>";
echo "<td style='font-size:16'>" . $row['Warranty'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'>Date Of Repair </td>";
echo "<td style='font-size:16'>" . $row['DateOfRepair'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> StartTime </td>";
echo "<td style='font-size:16'>" . $row['StartTime'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> EndTime </td>";
echo "<td style='font-size:16'>" . $row['EndTime'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> Payment </td>";
echo "<td style='font-size:16'>" . $row['Payment'] . "</td>";
echo "</tr>";


echo "<tr>";
echo "<tr>";
echo "<td style='font-size:16'> Payment Accepted By:</td>";
echo "<td style='font-size:16'>" . $row['Technician'] . "</td>";
echo "</tr>";
}
?>
</div>



</body>
</html>