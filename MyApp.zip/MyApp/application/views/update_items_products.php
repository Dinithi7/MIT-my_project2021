<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

</head>
<body>
<div class="container">
<?php
foreach($data as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="ModelNo">Model No:</label></td>
<td><input type="text" class="form-control" id="ModelNo" name="ModelNo" value="<?php echo $row->Id;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="ProductName">Product Name:</label></td>
<td><input type="text"  class="form-control" id="ProductName" name="ProductName" value="<?php echo $row->ProductName;?>"></td>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="ProductBrand">Product Brand:</label></td>
<td><input type="text" class="form-control" id="ProductBrand" name="ProductBrand" value="<?php echo $row->ProductBrand;?>"></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="ProductPrice">Unit Price:</label></td>
<td><input type="text" class="form-control" id="ProductPrice" name="ProductPrice" value="<?php echo $row->ProductPrice;?>"></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Quantity">Quantity to be added:</label></td>
<td><input type="text" class="form-control" id="Quantity" name="Quantity" value=""></td>
</tr>
<tr>
<div class="form-group">
<td><label for="Warranty">Warranty:</label></td>
<td><input type="text" class="form-control" id="Warranty" name="Warranty" value="<?php echo $row->Warranty;?>"></td>
</div>
</tr>


</table>

	<input type="submit" class="btn btn-info" name= "update" value="Update Item">

</form>


<?php
} ?>

</body>
</html>