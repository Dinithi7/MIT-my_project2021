<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";>Fault Item Details</h1>
</head>
<body>
<div class="container">
<?php
foreach($data1 as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="ItemName">Item Name:</label></td>
<td><input type="text" class="form-control" id="ItemName" name="ItemName" value="<?php echo $row->ItemName;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Fault"> Fault:</label></td>
<td><input type="text" class="form-control" id="Fault" name="Fault" value="<?php echo $row->Fault;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="TotalCost"> Total Cost:</label></td>
<td><input type="text" class="form-control" id="TotalCost" name="TotalCost" value="<?php echo $row->TotalCost;?>"></td>
</div>
</tr>
</table>
<label>Time To Repair(In Hours)</label>
<select class="form-control" name="TimeToRepair"  value= "<?php echo  $row->TimeToRepair; ?>">
<option value="<?php echo $row->TimeToRepair;?>" selected><?php echo $row->TimeToRepair;?></option>

<option>01:00:00.000000</option>
        <option>02:00:00.000000</option>
        <option>03:00:00.000000</option>
        <option>04:00:00.000000</option>
        <option>05:00:00.000000</option>
        <option>06:00:00.000000</option>
        <option>07:00:00.000000</option>
        <option>08:00:00.000000</option>
        <option>09:00:00.000000</option>

</select> <br/>

	<input type="submit" class="btn btn-info" name= "update" value="Update Faults">
</tr>
</form>


<?php
} ?>

</body>
</html>