<html>
<head>
<title>Upload Form</title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Upload Image for Sale Items</h1>
</head>
<body>


<!-- 1st line of upload_item_image_error.php was removed from here-->

<?php echo form_open_multipart('Item_Image_Controller/do_upload');?>

<label>ModelNo</label>
<select class="form-control" name="Id"  value= "<?php echo set_value('Id'); ?>" required>
 <option value="">Select Model No</option>'
    <?php
    foreach($groups as $MNo)
    {
     
        echo '<option value="'.$MNo['Id'].'">'.$MNo['Id'].'</option>';
        
    }
    ?>  
   

</select> <br/>
<?php if(form_error('ModelNo'))
{
echo "<span style='color:red'>".form_error('ModelNo')."</span>";
}
?>
<input type="file" name="userfile" size="20" />
<input type="submit" name="submit" value="upload" />

</form>

</body>
</html>