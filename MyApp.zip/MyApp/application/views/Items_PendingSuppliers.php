<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Requesting Items To Supply</h1>
</head>
<body>
<div class="container">


<form method="post">
<table class="table">


<tr>
<div class="form-group">
<td><label for="Id">Model No:</label></td>
<td><input type="text"  class="form-control" id="Id"name="Id" value="<?php echo set_value('Id');?>"/></td>
<?php if(form_error('Id'))
{
echo "<span style='color:red'>".form_error('Id')."</span>";
}
?>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="ItemName">Item Name:</label></td>
<td><input type="text" class="form-control" id="ItemName" name="ItemName" value="<?php echo set_value('ItemName');?>"/></td>
<?php if(form_error('ItemName'))
{
echo "<span style='color:red'>".form_error('ItemName')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Brand">Brand:</label></td>
<td><input type="text" class="form-control" id="Brand" name="Brand" value="<?php echo set_value('Brand');?>"/></td>
<?php if(form_error('Brand'))
{
echo "<span style='color:red'>".form_error('Brand')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Price">Unit Price:</label></td>
<td><input type="text" class="form-control" id="Price" name="Price" value="<?php echo set_value('Price');?>"/></td>
<?php if(form_error('Price'))
{
echo "<span style='color:red'>".form_error('Price')."</span>";
}
?>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="Quantity">Quanity:</label></td>
<td><input type="text"  class="form-control" id="Quantity" name="Quantity" value="<?php echo set_value('Quantity');?>"/></td>
<?php if(form_error('Quantity'))
{
echo "<span style='color:red'>".form_error('Quantity')."</span>";
}
?>
</div>
</tr>







</table>

<label for="Warranty">Warranty:</label>
<select class="form-control" name="Warranty" id="Warranty">
  <option value="1 month">1 month</option>
  <option value="3 months">3 months </option>
  <option value="6 months">6 months</option>
  <option value="1 year">1 year</option>
  <option value="2 years">2 years</option>
  <option value="3 years">3 years</option>
  <option value="4 years">4 years</option>
  <option value="5 years">5 years</option>
<?php if(form_error('Warranty'))
{
echo "<span style='color:red'>".form_error('Warranty')."</span>";
}
?>
</select>







<input type="submit" class="btn btn-info" value="Add Item" name="save">
	
	



</form>
</div>
</body>
</html>