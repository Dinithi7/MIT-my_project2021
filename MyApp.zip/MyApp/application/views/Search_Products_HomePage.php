<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>



<h6 align="left"><a href="<?php echo base_url('index.php/Homepage_Controller/'); ?>"> Go back to HomePage</a></h6>
<h1>Search Result</h1>
<!-- List all products -->
<div class="row col-lg-12">
    <?php if(!empty($products)){ foreach($products as $row){ ?>
        <div class="card col-lg-3">
        <img class="card-img-top" src="<?php echo base_url('uploads/'.$row['Image']); ?>" alt="" style="width:20% ;height:30%">
           
            <div class="card-body">
                <h5 class="card-title"><?php echo $row["ProductName"]; ?></h5>
                <h6 class="card-subtitle mb-2 text-muted">Price: <?php echo 'Rs. '.$row["ProductPrice"].''; ?></h6>
                <p class="card-text"><?php echo $row["Quantity"]." Item(s) Available"; ?></p>
                <a href="<?php echo base_url('index.php/products/addToCart/'.$row['Id']); ?>" class="btn btn-primary">Add to Cart</a>
            </div>
        </div>
    <?php } }else{ ?>
        <p>Product(s) not found...</p>
    <?php } ?>
</div>
  
   
   </html>