<?php

   foreach ($data as $row)
    {
        echo "Welcome"; echo "&nbsp";
           echo "$row->FirstName"; 
           echo "&nbsp";
           echo "$row->LastName"; echo "&nbsp";
           $emailname=$this->session->userdata('Email');
          // echo "$emailname";
           echo "\n";
           echo '<a href="logout">Logout</a>';
          
         
          
    }
    ?>
    
