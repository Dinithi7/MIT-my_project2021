<!DOCTYPE html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
<div class="container">
<table class="table table-bordered">
<tr>
<th>InvoiceNo</th>
<th>RequestID</th>
<th>ModelNo</th>
<th>SupplierID</th>
<th>SupplierName</th>
<th>TotalCost</th>
<th>Date</th>
</tr>
<?php
foreach($data4 as $row){
echo "<tr>";
echo "<tr>";
echo "<td>" . $row['InvoiceNo'] . "</td>";
echo "<td>" . $row['RequestID'] . "</td>";
echo "<td>" . $row['ModelNo'] . "</td>";
echo "<td>" . $row['SupplierID'] . "</td>";
echo "<td>" . $row['SupplierName'] . "</td>";
echo "<td>" . $row['TotalCost'] . "</td>";
echo "<td>" . $row['Date'] . "</td>";
echo "</tr>";
}
?>
</table>
<table>
<?php
foreach($data5 as $row){
echo "<tr>";
echo "<td> Total Payment for purchases <td>";
echo "<td>";
echo "<td>";
echo "<td>";
echo "<td style='font-weight:bold'>". $row['TotalPurchasePayment'] . "</td>";
echo "</tr>";
}
?>
</table>