
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Send Requests</h1>

</head>
<body>
  
<div class="container">
<?php
foreach($data1 as $row){
//?>
<form id="myForm1" method="post">
<table class="table">
<tr>
<div class="form-group">
<td><label for="ID">Model No:</label></td>
<td><input type="text" class="form-control" id="ID" name="ID" value="<?php echo $row->Id;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="ProductName">ProductName:</label></td>
<td><input type="text" class="form-control" id="ProductName" name="ProductName" value="<?php echo $row->ProductName;?>"disabled></td>
</div>
</tr>
<div class="form-group">
<td><label for="QAvailable">Quantity Available:</label></td>
<td><input type="text" class="form-control" id="QAvailable" name="QAvailable" value="<?php echo $row->Quantity;?>"disabled></td>
</div>
</tr>
<div class="form-group">
<td><label for="UnitPrice">Unit Price:</label></td>
<td><input type="text" class="form-control" id="UnitPrice" name="UnitPrice" value="<?php echo $row->ProductPrice;?>"disabled></td>
</div>
</tr>
<div class="form-group">
<td><label for="SupplierName">Supplier:</label></td>
<td><input type="text" class="form-control" id="SupplierName" name="SupplierName" value="<?php echo $row->SupplierName;?>"disabled></td>
</div>
</tr>
</tr>
<div class="form-group">
<td><label for="Warranty">Warranty:</label></td>
<td><input type="text" class="form-control" id="Warranty" name="Warranty" value="<?php echo $row->Warranty;?>"disabled></td>
</div>
</tr>


<?php
} ?>

<tr>
<div class="form-group">
<td><label for="DateRequired"> Date Required:</label></td>
<td><input type="date" class="form-control" id="DateRequired" name="DateRequired" value="<?php echo set_value('DateRequired');?>"></td>
<?php if(form_error('DateRequired'))
{
echo "<span style='color:red'>".form_error('DateRequired')."</span>";
}
?>
</div>
</tr>
<tr>

<div class="form-group">
<td><label for="QuantityNeeded">Quanity Needed:</label></td>
<td><input type="text" class="form-control" id="QuantityNeeded" name="QuantityNeeded" value="<?php echo set_value('QuantityNeeded');?>"></td>
<?php if(form_error('QuantityNeeded'))
{
echo "<span style='color:red'>".form_error('QuantityNeeded')."</span>";
}
?>
</div>
</tr>
</table>






<input type="submit" class="btn btn-info" value="Request" name="save">


</body>
</html>