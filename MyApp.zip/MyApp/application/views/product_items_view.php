<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Register Products For Sale</h1>
</head>
<body>
<div class="container">


<form method="post">
<table class="table">


<tr>
<div class="form-group">
<td><label for="ModelNo">Model No:</label></td>
<td><input type="text"  class="form-control" id="ModelNo"name="ModelNo" value="<?php echo set_value('ModelNo');?>"/></td>
<?php if(form_error('ModelNo'))
{
echo "<span style='color:red'>".form_error('ModelNo')."</span>";
}
?>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="ProductName">Product Name:</label></td>
<td><input type="text" class="form-control" id="ProductName" name="ProductName" value="<?php echo set_value('ProductName');?>"/></td>
<?php if(form_error('ProductName'))
{
echo "<span style='color:red'>".form_error('ProductName')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="ProductBrand">Product Brand:</label></td>
<td><input type="text" class="form-control" id="ProductBrand" name="ProductBrand" value="<?php echo set_value('ProductBrand');?>"/></td>
<?php if(form_error('ProductBrand'))
{
echo "<span style='color:red'>".form_error('ProductBrand')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="ProductPrice">Unit Price:</label></td>
<td><input type="text" class="form-control" id="ProductPrice" name="ProductPrice" value="<?php echo set_value('ProductPrice');?>"/></td>
<?php if(form_error('ProductPrice'))
{
echo "<span style='color:red'>".form_error('ProductPrice')."</span>";
}
?>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="Quantity">Quantity:</label></td>
<td><input type="text"  class="form-control" id="Quantity" name="Quantity" value="<?php echo set_value('Quantity');?>"/></td>
<?php if(form_error('Quantity'))
{
echo "<span style='color:red'>".form_error('Quantity')."</span>";
}
?>
</div>
</tr>
</table>

<label for="Warranty">Warranty:</label>
<select class="form-control" name="Warranty" id="Warranty">
  <option value="1 month">1 month</option>
  <option value="3 months">3 months </option>
  <option value="6 months">6 months</option>
  <option value="1 year">1 year</option>
  <option value="2 years">2 years</option>
  <option value="3 years">3 years</option>
  <option value="4 years">4 years</option>
  <option value="5 years">5 years</option>
<?php if(form_error('Warranty'))
{
echo "<span style='color:red'>".form_error('Warranty')."</span>";
}
?>
</select>
<input type="submit" class="btn btn-info" value="Add Item" name="save">
</form>
</div>
</body>
</html>