<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<style>
.vertical-menu {
  width: 200px; /* Set a width if you like */
}

.vertical-menu a {
  background-color: #eee; /* Grey background color */
  color: black; /* Black text color */
  display: block; /* Make the links appear below each other */
  padding: 12px; /* Add some padding */
  text-decoration: none; /* Remove underline from links */
}

.vertical-menu a:hover {
  background-color: #ccc; /* Dark grey background on mouse-over */
}

.vertical-menu a.active {
  background-color: #4CAF50; /* Add a green color to the "active/current" link */
  color: white;
}
/*-------------------------*/

</style>
<script>
function setActiveLink(setActive){
    if ($("a").hasClass('active'))
        $("a").removeClass('active');
    if (setActive)
        $("#"+setActive).addClass('active');
}

$(function() {
    $("a").click(function() {
        setActiveLink(this.id);
    });
});
</script>
<!----------------------------------->

</style>
<h1 text-align="left";> DEO Profile Page</h1>
</head>
<body>


<iframe src="" align="right" name="iframe_a"  style="height:800px;width:1100px;visibility: visible; box-sizing: content-box;" title="Iframe Example"></iframe>

<div class="vertical-menu">
<a id="link1" href="<?= site_url('login1_controller/UpdateEmployeeDetails_E'); ?>" target="iframe_a">Update Personal Details</a>
  <a id="link2" href="<?= site_url('Product_Item_Controller/savedata'); ?>"  target="iframe_a">Register Products For Sale</a>
  <a id="link3" href="<?= site_url('Item_Image_Controller'); ?>" target="iframe_a">Upload Item Image</a>
  <a id="link4" href="<?= site_url('Product_Item_Controller/displaydata'); ?>"  target="iframe_a">View Products For Sale</a>

  <a id="link5" href="<?= site_url('Checkout/view_undelivered_shoppingitems'); ?>" >Sales Orders</a>

 <a id="link6" href="<?= site_url('items_controller/savedata'); ?>"  target="iframe_a">Register Items</a>
 

  <a id="link7" href="<?= site_url('Customers_Controller/saveCustomerAtShop'); ?>" target="iframe_a">Register Customer</a>
  
  
  <a id="link8" href="<?= site_url('Fault_Controller/savedata'); ?>" target="iframe_a">Register Faults</a>
<a id="link9" href="<?= site_url('Fault_Controller/displaydata'); ?>" target="iframe_a">View Faults</a>
  
  <a id="link10" href="<?= site_url('repairs_controller/displayfaults'); ?>">Accept Repair Items</a>
  <a id="link11" href="<?= site_url('repairs_controller/displaydata'); ?>">Update Repair Items</a>
  <a id="link12" href="<?= site_url('repairs_controller/displaydata'); ?>" target="iframe_a">Delete Repair Items</a>
  <a id="link13" href="<?= site_url('repairs_controller/viewHomeVisitRequests'); ?>">Manage Home Visit Repairs</a>
  
  <a id="link14" href="<?= site_url('repairs_controller/displaySchedulesWithinPeriod'); ?>" target="iframe_a">View Home visits</a>
  
  <a id="link15" href="<?= site_url('repairs_controller/viewScheduledRepairsTogetInvoice'); ?>">Generate Invoice to Scheduled HomeVisits</a>
  <a id="link16" href="<?= site_url('Leave_Controller/ShowLeaveHistoryToEmployee'); ?>" target="iframe_a">Leave History</a>
  <a id="link17" href="<?= site_url('Leave_Controller/savedata'); ?>" target="iframe_a">Request Leave</a>
  <a id="link18" href="<?= site_url('login1_controller/change_password'); ?>" target="iframe_a">Change Password</a>
  
</div>



</body>
</html>