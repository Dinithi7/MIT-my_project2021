<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h6 align="left"><a href="<?= site_url('Checkout/view_undelivered_shoppingitems'); ?>" > Go back </a></h6>

<h1 align="center";>Order Details</h1>

</head>
<body>
<div class="container">
<?php
foreach($data12 as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="OrderID">Order ID:</label></td>
<td><input type="text" class="form-control" id="OrderID" name="OrderID" value="<?php echo $row['OrderID'];?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="DateOrder">Date Ordered:</label></td>
<td><input type="text" class="form-control" id="DateOrdered" name="DateOrdered" value="<?php echo $row['Created'];?>"disabled></td>
</div>
</tr>




<tr>
<div class="form-group">
<td><label for="Name"> Customer Name:</label></td>
<td><input type="text" class="form-control" id="Name" name="Name" value="<?php echo $row['Name'];?>"disabled></td>
</div>
</tr>
<tr>
<tr>
<div class="form-group">
<td><label for="Address"> Customer Address:</label></td>
<td><input type="text" class="form-control" id="Address" name="Address" value="<?php echo $row['Address'];?>"disabled></td>
</div>
</tr>
<tr>

<tr>
<div class="form-group">
<td><label for="ContactNo"> Customer ContactNo:</label></td>
<td><input type="text" class="form-control" id="ContactNo" name="ContactNo" value="<?php echo $row['ContactNo'];?>"disabled></td>
</div>
</tr>
<tr>


</table>
<label>Status</label>
<select class="form-control" name="Status"  value= "<?php echo  $row['Status']; ?>">
<option value="<?php echo $row['Status'];?>" selected><?php echo $row['Status'];?></option>

<option>Delivered</option>

</select> <br/>

<div class="row col-lg-12">
        <table class="table table-hover">
            <thead>
                <tr>
                    
                    <th>Model No</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Sub Total</th>
                    <th>Warranty Expires On</th>
                </tr>
            </thead>
<?php
foreach($data14 as $row){

echo "<tr>";
echo "<td>" . $row['ProductID'] . "</td>";
echo "<td>" . $row['ProductName'] . "</td>";
echo "<td>" . $row['ProductPrice'] . "</td>";
echo "<td>" . $row['Quantity'] . "</td>";
echo "<td>"."Rs. " . $row['SubTotal'] . "</td>";
echo "<td>" . $row['WarrantyExpires'] . "</td>";
echo "</tr>";
}
?>
<table class="table table-bordered">
<?php
foreach($data15 as $row){


echo "<tr>";
echo "<tr>";
echo "<td><b> GrandTotal<b></td>";
echo "<td style='font-weight:bold'>" ."Rs. ". $row['GrandTotal'] . "</td>";
echo "</tr>";
}
?>
</table>

	<input type="submit" class="btn btn-info" name= "update" value="Update Status">
</tr>
</form>


<?php
} ?>

</body>
</html>