<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Request Leave</h1>

</head>
<body>
<div class="container">


<form method="post">
<table class="table">
<div class="form-group">
<div class="form-group">
<td><label for="LeaveDate"> Select a date:</label>
<input type="date" class="form-control" id="LeaveDate" name="LeaveDate" value="<?php echo set_value('LeaveDate');?>"/></td>
<?php if(form_error('LeaveDate'))
{
echo "<span style='color:red'>".form_error('LeaveDate')."</span>";
}
?>
<tr>
<div class="form-group">
      <label for="select">Select Leave Type:</label>
      <select class="form-control" id="LeaveType" name="LeaveType">
        <option>Short Leave</option>
        <option>Half Day</option>
        <option>Full Day</option>
 </select>
<?php if(form_error('LeaveType'))
{
echo "<span style='color:red'>".form_error('LeaveType')."</span>";
}
?>
</div>
</tr><td>
<div class="form-group">
      <label for="select">If you chose Short Leave select a duration:</label>
      <select class="form-control" id="DurationSL" name="DurationSL">
        <option>9.00 A.M -10.00 A.M</option>
        <option>5.00 P.M - 6.00 P.M</option>
 </select> 
</div>
</td>
<td>
<div class="form-group">
      <label for="select">If you chose Half Day select a duration:</label>
      <select class="form-control" id="DurationHL" name="DurationHL">
        <option>9.00 A.M -1.00 P.M</option>
        <option>2.00 P.M - 6.00 P.M</option>
 </select>
</div>
</td>
<div class="form-group">
      <label for="select">Select Reason:</label>
      <select class="form-control" id="Reason" name="Reason">
        <option>Casual</option>
        <option>Medical</option>
        
 </select>
<?php if(form_error('Reason'))
{
echo "<span style='color:red'>".form_error('Reason')."</span>";
}
?>

</table>

	<input type="submit" class="btn btn-info" value="Request" name="save">
	
  </form>
  
  </body>
  </html>