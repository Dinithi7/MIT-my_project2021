<h6 align="left"><a href="<?= site_url('login1_Controller/enter'); ?>" > Go back to Profile Page</a></h6>

<h1>ORDER STATUS</h1>

<?php if(!empty($order)){ ?>
    <div class="col-md-12">
        <div class="alert alert-success">Your order has been placed successfully.</br>
        Please visit View Order History on the Profile Page to print the Invoice.
        </div>
        
    </div>
	</br>
    <!-- Order status & shipping info -->
    <div class="row col-lg-12 ord-addr-info">
        <div class="hdr">Order Info</div>
        <p><b>Reference ID:</b> #<?php echo $order['OrderID']; ?></p>
        <p><b>Total:</b> <?php echo 'Rs.'.$order['GrandTotal']; ?></p>
        <p><b>Placed On:</b> <?php echo $order['Created']; ?></p>
        <p><b>Buyer Name:</b> <?php echo $order['FirstName']." ".$order['LastName']; ?></p>
        <p><b>Email:</b> <?php echo $order['Email']; ?></p>
        <p><b>Phone:</b> <?php echo $order['ContactNo']; ?></p>
    </div>
	
    <!-- Order items -->
    <div class="row col-lg-12">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th></th>
                    <th>Model No</th>
                    <th>Product</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Sub Total</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if(!empty($order['items'])){  
                    foreach($order['items'] as $item){ 
                ?>
                <tr>
                    <td>
                   
                    <?php $imageURL = !empty($item["Image"])?base_url('uploads/'.$item["Image"]):base_url('uploads/'.$item["Image"]); ?>
            <img src="<?php echo $imageURL; ?>" width="50"/>
                    </td>
                    <td><?php echo $item["Id"]; ?></td>
                    <td><?php echo $item["ProductName"]; ?></td>
                    <td><?php echo 'Rs.'.$item["ProductPrice"]; ?></td>
                    <td><?php echo $item["Quantity"]; ?></td>
                    <td><?php echo 'Rs.'.$item["SubTotal"]; ?></td>
                </tr>
                <?php } 
                } ?>
            </tbody>
        </table>
    </div>
<?php } else{ ?>
<div class="col-md-12">
    <div class="alert alert-danger">Your order submission failed.</div>
</div>

<?php } ?>
