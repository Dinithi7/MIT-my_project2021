<?php
echo '<span style="color:blue;">Updation was successful</span>';
?>