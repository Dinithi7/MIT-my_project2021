<!DOCTYPE html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
<div class="container">
<table class="table table-bordered">
<tr>
<th>RepairID</th>
<th>FaultID</th>
<th>ItemName</th>
<th>Fault</th>
<th>Description</th>
<th>Accept Date</th>
<th>Return Date</th>
<th>Warranty</th>
<th>Total Cost</th>
<th>Advance Paid</th> 
<th>Balance</th> 
<th>Technician</th>
<th>Status</th>
</tr>
<?php
foreach($data4 as $row){
echo "<tr>";
echo "<td>".$row->RepairID."</td>";
echo "<td>".$row->FaultID."</td>";
echo "<td>".$row->ItemName."</td>";
echo "<td>".$row->Fault."</td>";
echo "<td>".$row->Description."</td>";
echo "<td>".$row->AcceptDate."</td>";

echo "<td style='background-color:pink;'>".$row->ReturnDate."</td>";


echo "<td>".$row->Warranty."</td>";
echo "<td>".$row->TotalCost."</td>";
echo "<td>".$row->AdvancePaid."</td>";
echo "<td>".$row->Balance."</td>";
echo "<td>".$row->Technician."</td>";
//------------------------------------------------------
//echo "<td>".$row->Status."</td>";
//------------------------------------------------------
if ($row->Status=="Accepted")
{
  echo "<td style='background-color: #00FF00;'>".$row->Status."</td>"; 
}

else if ($row->Status=="Ready")
{
  echo "<td style='background-color:orange;'>".$row->Status."</td>"; 
}
else if ($row->Status=="Delayed")
{
  echo "<td style='background-color: #FF0000;'>".$row->Status."</td>"; 
}
else if ($row->Status=="Delivered")
{
  echo "<td style='background-color: #FFFF00;'>".$row->Status."</td>"; 
}
//------------------------------------------------------
echo "</tr>";
}
?>
</table>
</div>
</body>
</html>