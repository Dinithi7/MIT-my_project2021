<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<h6 align="left"><a href="<?= site_url('login1_Controller/enter'); ?>" > Go back to Profile Page</a></h6>
<h1 align="center";> Invoice </h1>
<body>
<div class="container">
<table class="table">
<?php
echo "<tr>";
echo "<td> From: Antenna House, Kadawatha</td>";
echo "</tr>";

echo "<tr>";
echo "<td> Contact No: 0771234567</td>";
echo "</tr>";

$date=date('Y-m-d');
echo "<tr>";
echo "<td> Date:   $date</td>";


echo "</tr>";
?>
<table class="table table-bordered">
<?php
foreach($data3 as $row){


echo "<tr>";
echo "<tr>";
echo "<td> Invoice No</td>";
echo "<td>" . $row['InvoiceNo'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<tr>";
echo "<td> RequestID</td>";
echo "<td>" . $row['RequestID'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<td> ModelNo</td>";
echo "<td>" . $row['ModelNo'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<td> SupplierID</td>";
echo "<td>" . $row['SupplierID'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<td> Supplier Name</td>";
echo "<td>" . $row['SupplierName'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<td> Supplier Email</td>";
echo "<td>" . $row['Email'] . "</td>";
echo "</tr>";


echo "<tr>";
echo "<td> Date Agreed to Supply </td>";
echo "<td>" . $row['DateOfSupply'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<td> Quantity Supplied </td>";
echo "<td>" . $row['Quantity'] . "</td>";
echo "</tr>";

echo "<tr>";
echo "<td> Unit Price (In Rupees)</td>";
echo "<td>" . $row['UnitPrice'] . "</td>";
echo "</tr>";

echo "</tr>";

}
?>
<?php
foreach($data4 as $row){
echo "<tr>";

echo "<td style='font-weight:bold'> Total Payment (In Rupees) </td>";
echo "<td style='font-weight:bold'>".$row['TotalPrice'] ."</td>";
echo "</tr>";
}
?>
</div>
</body>
</html>