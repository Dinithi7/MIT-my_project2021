
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Confirm Requests</h1>

</head>
<body>
  
<div class="container">
<?php
foreach($data2 as $row){
//?>
<form id="myForm1" method="post">
<table class="table">
    
<tr>
<div class="form-group">
<td><label for="RequestID"> RequestID:</label></td>
<td><input type="text" class="form-control" id="RequestID" name="RequestID" value="<?php echo $row->RequestID;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="ModelNo">Model No:</label></td>
<td><input type="text" class="form-control" id="ModelNo" name="ModelNo" value="<?php echo $row->ModelNo;?>"disabled></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="ProductName">Product Name:</label></td>
<td><input type="text" class="form-control" id="ProductName" name="ProductName" value="<?php echo $row->ProductName;?>"disabled></td>
</div>
</tr>
<div class="form-group">
<td><label for="ProductBrand">Product Brand:</label></td>
<td><input type="text" class="form-control" id="ProductBrand" name="ProductBrand" value="<?php echo $row->ProductBrand;?>"disabled></td>
</div>
</tr>

<div class="form-group">
<td><label for="ProductPrice">Unit Price:</label></td>
<td><input type="text" class="form-control" id="ProductPrice" name="ProductPrice" value="<?php echo $row->ProductPrice;?>"></td>
</div>
</tr>
<div class="form-group">
<td><label for="Warranty">Warranty:</label></td>
<td><input type="text" class="form-control" id="Warranty" name="Warranty" value="<?php echo $row->Warranty;?>"disabled></td>
</div>
</tr>
<div class="form-group">
<td><label for="DateRequired">Date Required:</label></td>
<td><input type="text" class="form-control" id="DateRequired" name="DateRequired" value="<?php echo $row->DateRequired;?>"disabled></td>
</div>
</tr>
</tr>
<div class="form-group">
<td><label for="QuantityNeeded">Quantity Needed:</label></td>
<td><input type="text" class="form-control" id="QuantityNeeded" name="QuantityNeeded" value="<?php echo $row->QuantityNeeded;?>"disabled></td>
</div>
</tr>


<?php
} ?>
<div class="form-group">
      <label for="select">Select order status:</label>
      <select class="form-control" id="OrderStatus" name="OrderStatus">
        <option>Confirmed</option>
        <option>Rejected</option>
        
        
      </select>

</div>
<tr>
<div class="form-group">
<td><label for="DateOfSupply"> Date of Supply:</label></td>
<td><input type="date" class="form-control" id="DateOfSupply" name="DateOfSupply" value="<?php echo set_value('DateOfSupply');?>"></td>
<?php if(form_error('DateOfSupply'))
{
echo "<span style='color:red'>".form_error('DateOfSupply')."</span>";
}
?>
</div>
</tr>
<div class="form-group">
<td><label for="QuantityAvailable">Quantity Supplied:</label></td>
<td><input type="text" class="form-control" id="QuantityAvailable" name="QuantityAvailable" value=""></td>
</div>
</tr>
<tr>

</div>
</tr>
</table>

<input type="submit" class="btn btn-info" value="Update" name="save">


</body>
</html>