<!DOCTYPE html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
<h1 align="center";> View Suppliers</h1>
<div class="container">
<table class="table table-bordered">
<tr>
<th>SupplierID</th>
<th>FirstName</th>
<th>LastName</th>
<th>SupplierName</th>
<th>Address</th>
<th>LandLine</th>
<th>MobileNo</th>
<th>E-Mail</th>
<th>Status</th>
<th>Update</th>
<th>Delete</th>

</tr>
<?php
foreach($data as $row){
echo "<tr>";
echo "<td>".$row->SupplierID."</td>";
echo "<td>".$row->FirstName."</td>";
echo "<td>".$row->LastName."</td>";
echo "<td>".$row->SupplierName."</td>";
echo "<td>".$row->Address."</td>";
echo "<td>".$row->LandLine."</td>";
echo "<td>".$row->MobileNo."</td>";
echo "<td>".$row->Email."</td>";
echo "<td>".$row->Status."</td>";
echo "<td><a href='updatedata?SupplierID=".$row->SupplierID."'>Update</a></td>";
echo "<td><a href='deletedata?Email=".$row->Email."'>Delete</a></td>";

echo "</tr>";
}
?>
</table>
</div>
</body>
</html>