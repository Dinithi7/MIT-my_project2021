<!DOCTYPE html>
<html>
<head>
<style>
table {
  width: 100%;
  border-collapse: collapse;
}

table, td, th {
  border: 1px solid black;
  padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<?php
$q = intval($_GET['EmpID']);

$con = mysqli_connect('localhost','','','antennas');
if (!$con) {
  die('Could not connect: ' . mysqli_error($con));
}

mysqli_select_db($con,"antennas");
$sql = "SELECT EmpID,DateOFRepair,StartTime,EndTime FROM visitRepairs WHERE VisitJobID=(SELECT max(VisitJobID) FROM visitrepairs WHERE EmpID='".$EmpID."'";

$result = mysqli_query($con,$sql);

echo "<table>
<tr>
<th>EmpID</th>
<th>DateOfRepair</th>
<th>StartTime</th>
<th>EndTime</th>

</tr>";
while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
  echo "<td>" . $row['EmpID'] . "</td>";
  echo "<td>" . $row['DateOfRepair'] . "</td>";
  echo "<td>" . $row['StartTime'] . "</td>";
  echo "<td>" . $row['EndTime'] . "</td>";
 
  echo "</tr>";
}
echo "</table>";
mysqli_close($con);
?>
</body>
</html>