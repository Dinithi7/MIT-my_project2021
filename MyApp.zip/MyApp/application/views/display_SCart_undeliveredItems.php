<!DOCTYPE html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>
<h6 align="left"><a href="<?= site_url('login1_Controller/enter'); ?>" > Go back to Profile Page</a></h6>
<h1 align="center";>  Shopping Cart Orders</h1>
<div class="container">
<table class="table table-bordered table-striped">
<tr>
<th>OrderID</th>
<th>Date Ordered</th>
<th>Cutomer Name</th>
<th>Address</th>
<th>Contact No</th>
<th>GrandTotal</th>
<th>Status</th>

<th>Update Order Status</th>
<th> View Invoice</th>
</tr>
<?php
foreach($data11 as $row){
    echo "<tr>";
    echo "<td>" . $row['OrderID'] . "</td>";
    echo "<td>" . $row['Created'] . "</td>";
    echo "<td>" . $row['Name'] . "</td>";
    echo "<td>" . $row['Address'] . "</td>";
    echo "<td>" . $row['ContactNo'] . "</td>";
    echo "<td>" . $row['GrandTotal'] . "</td>";

    if ($row['Status']=="Ordered")
    {
      echo "<td style='background-color:lightgreen;'>".$row['Status']."</td>"; 
    }
else if ($row['Status']=="Delivered")
{
    echo "<td style='background-color:lightblue;'>".$row['Status']."</td>";  
}

echo "<td><a href='update_shopping_delivery?OrderID=".$row['OrderID']."'>Update Order Status</a></td>";
echo "<td><a href='Invoice_delivery?OrderID=".$row['OrderID']."'>Generate Invoice</a></td>";
echo "</tr>";
}
?>
</table>
</div>
</body>
</html>