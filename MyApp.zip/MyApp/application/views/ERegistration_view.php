<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Register Employee</h1>
</head>
<body>
<div class="container">


<form method="post">
<table class="table">


<tr>
<div class="form-group">
<td><label for="FirstName">FirstName:</label></td>
<td><input type="text"  class="form-control" id="FN"name="FirstName" value="<?php echo set_value('FirstName');?>"/></td>
<?php if(form_error('FirstName'))
{
echo "<span style='color:red'>".form_error('FirstName')."</span>";
}
?>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="LastName">LastName:</label></td>
<td><input type="text" class="form-control" id="LN" name="LastName" value="<?php echo set_value('LastName');?>"/></td>
<?php if(form_error('LastName'))
{
echo "<span style='color:red'>".form_error('LastName')."</span>";
}
?>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="NIC">NIC Number:</label></td>
<td><input type="text" class="form-control" id="NICNo" name="NICNo" value="<?php echo set_value('NICNo');?>"/></td>
<?php if(form_error('NICNo'))
{
echo "<span style='color:red'>".form_error('NICNo')."</span>";
}
?>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Address">Address:</label></td>
<td><input type="text" class="form-control" id="Address" name="Address" value="<?php echo set_value('Address');?>"/></td>
<?php if(form_error('Address'))
{
echo "<span style='color:red'>".form_error('Address')."</span>";
}
?>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="ContactNo">Contact Number:</label></td>
<td><input type="text" class="form-control" id="ContactNo" name="ContactNo" value="<?php echo set_value('ContactNo');?>"/></td>
<?php if(form_error('ContactNo'))
{
echo "<span style='color:red'>".form_error('ContactNo')."</span>";
}
?>
</div>
</tr>
<tr>

<div class="form-group">
<td><label for="Gender">Gender:</label></td>
<td>
<div class="form-check form-check-inline">
<input class="form-check-input"  type="radio" name="Gender" id="Gender" value="Male" <?php echo  set_radio('Gender', 'Male', TRUE); ?> />
<label class="form-check-label" for="Gender">Male</label>
</div>

<div class="form-check form-check-inline">
<input class="form-check-input"  type="radio" name="Gender" id="Gender" value="Female" <?php echo  set_radio('Gender', 'Female'); ?> />
<label class="form-check-label" for="Gender">Female</label>
</div>
</td>

<?php if(form_error('Gender'))
{
echo "<span style='color:red'>".form_error('Gender')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="DOB">Date of Birth:</label></td>
<td><input type="date" class="form-control" id="DOB" name="DOB" value="<?php echo set_value('DOB');?>"/></td>
<?php if(form_error('DOB'))
{
echo "<span style='color:red'>".form_error('DOB')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="DateJoined">Date Joined:</label></td>
<td><input type="date" class="form-control" id="DateJoined" name="DateJoined" value="<?php echo set_value('DateJoined');?>"/></td>
<?php if(form_error('DateJoined'))
{
echo "<span style='color:red'>".form_error('DateJoined')."</span>";
}
?>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Username">E-mail:</label></td>
<td><input type="text"  class="form-control" id="UN"name="Username" value="<?php echo set_value('Username');?>"/></td>
<?php if(form_error('Username'))
{
echo "<span style='color:red'>".form_error('Username')."</span>";
}
?>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Password">Password:</label></td>
<td><input type="password"  class="form-control" id="PW"name="Password" value="<?php echo set_value('Password');?>"/></td>
<?php if(form_error('Password'))
{
echo "<span style='color:red'>".form_error('Password')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="CPassword">Re-enter Password:</label></td>
<td><input type="password"  class="form-control" id="CPW" name="ConfirmPassword" value="<?php echo set_value('ConfirmPassword');?>"/></td>
<?php if(form_error('ConfirmPassword'))
{
echo "<span style='color:red'>".form_error('ConfirmPassword')."</span>";
}
?>
</div>
</tr>
<tr>
<div class="form-group">
<label> Category</label>
<select class="form-control" name="CatID"  value= "<?php echo set_value($Cat['CatID']); ?>" required>

 <option value="">Select Category</option>'
    <?php
    foreach($groups as $Cat)
    {
     
        echo '<option value="'.$Cat['CatID'].'">'.$Cat['CatName'].'</option>';
        
    }
    ?>  
    </select> <br/>
   <?php if(form_error('CatID'))
{
echo "<span style='color:red'>".form_error('CatID')."</span>";
}
?>




</div>
</table>
<input type="submit" class="btn btn-info" value="Register" name="save">
	
	



</form>
</div>
</body>
</html>