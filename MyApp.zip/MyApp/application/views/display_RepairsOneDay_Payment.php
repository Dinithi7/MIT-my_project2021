<!DOCTYPE html>
<head>
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<body>

<div class="container">
<table class="table table-bordered">

<p><span style="color:blue;"> Payments For Shop Visits</span></p>

<tr>
<th>InvoiceNo</th>
<th>RepairID</th>
<th>FaultID</th>
<th>CustomerID</th>
<th>Date</th>
<th>Payment</th>
</tr>
</tr>
<?php
foreach($data6 as $row){
echo "<tr>";
echo "<tr>";
echo "<td>" . $row['InvoiceNo'] . "</td>";
echo "<td>" . $row['RepairID'] . "</td>";
echo "<td>" . $row['FaultID'] . "</td>";
echo "<td>" . $row['CustomerID'] . "</td>";
echo "<td>" . $row['Date'] . "</td>";
echo "<td>" . $row['Payment'] . "</td>";
echo "</tr>";
}
?>
<?php
foreach($data7 as $row){
echo "<tr>";
//echo "<td> Total Payment for Shop Repairs <td>";
echo "<td style='font-weight:bold'> Total Payment for Shop Repairs <td>";
echo "<td>";
echo "<td>";
echo "<td>";
//echo "<td>" . $row['TotalPaymentShop'] . "</td>";
echo "<td style='font-weight:bold'>" . $row['TotalPaymentShopOneDay'] . "</td>";
echo "</tr>";
}
?>
</table>
<div class="container">
<table class="table table-bordered">
<p><span style="color:blue;"> Payments for Home-Visits.</span></p>
<tr>
<th>InvoiceNo</th>
<th>VisitJobID</th>
<th>FaultID</th>
<th>CustomerID</th>
<th>Date</th>
<th>Payment</th>
</tr>
<?php
foreach($data8 as $row){
echo "<tr>";
echo "<tr>";
echo "<td>" . $row['InvoiceNo'] . "</td>";
echo "<td>" . $row['VisitJobID'] . "</td>";
echo "<td>" . $row['FaultID'] . "</td>";
echo "<td>" . $row['CustomerID'] . "</td>";
echo "<td>" . $row['Date'] . "</td>";
echo "<td>" . $row['Payment'] . "</td>";
echo "</tr>";
}
?>
<?php
foreach($data9 as $row){
echo "<tr>";
echo "<td style='font-weight:bold'> Total Payment for Home-Visit Repairs <td>";
echo "<td>";
echo "<td>";
echo "<td>";

echo "<td style='font-weight:bold'>" . $row['TotalPaymentVisitsOneDay'] . "</td>";
echo "</tr>";
}
?>
</table>
<table>
<table>
<?php
foreach($data7 as $row){
$Total1=$row['TotalPaymentShopOneDay'];
foreach($data9 as $row){
$Total2=$row['TotalPaymentVisitsOneDay'];
$Total3=$Total1+$Total2;
echo "<tr>";
echo "<td style='font-weight:bold'> Grand Total<td>";
echo "<td>";
echo "<td>";
echo "<td style='font-weight:bold'>".$Total3. "</td>";
}}
?>
</div>
</body>
</html>