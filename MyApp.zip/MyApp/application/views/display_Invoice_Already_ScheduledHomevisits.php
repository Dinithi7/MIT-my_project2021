<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
</head>
<h6 align="left"><a href="<?= site_url('login1_Controller/enter'); ?>" > Go back to Profile Page</a></h6>
<h1 align="center";> Generate Invoices </h1>
<body>
<div class="container">

<table class="table table-bordered">
<tr>
<th>Invoice No</th>
<th>VisitJobID</th>
<th>FaultID</th>
<th>Customer ID</th>
<th>Address</th>
<th>Customer E-Mail</th>
<th>Warranty</th>
<th>Payment</th>
<th>Date Of Repair</th>
<th>EmpID</th>

<th>StartTime</th>
<th>EndTime</th>

<th>Generate Invoice</th>
</tr>
<?php
foreach($data11 as $row){

    echo "<tr>";
    echo "<td>" . $row['InvoiceNo'] . "</td>";
    echo "<td>" . $row['VisitJobID'] . "</td>";
    echo "<td>" . $row['FaultID'] . "</td>";
    echo "<td>" . $row['CustomerID'] . "</td>";
    echo "<td>" . $row['Address'] . "</td>";
    echo "<td>" . $row['Email'] . "</td>";
    echo "<td>" . $row['Warranty'] . "</td>";
    echo "<td>" . $row['Payment'] . "</td>";
    echo "<td>" . $row['DateOfRepair'] . "</td>";
   
    echo "<td>" . $row['EmpID'] . "</td>";
    echo "<td>" . $row['StartTime'] . "</td>";
    echo "<td>" . $row['EndTime'] . "</td>"; 
    echo "<td><a href='viewInvoiceforALREADYscheduledHomeVisits?InvoiceNo=".$row['InvoiceNo']."'>Generate Invoice</a></td>";
}
?>
</table>
</div>
</body>
</html>