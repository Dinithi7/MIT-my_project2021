<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Register Faults</h1>
</head>
<body>
<div class="container">

<form method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="ItemName">Item Name:</label></td>
<td><input type="text"  class="form-control" id="ItemName"name="ItemName" value="<?php echo set_value('ItemName');?>"/></td>
<?php if(form_error('ItemName'))
{
echo "<span style='color:red'>".form_error('ItemName')."</span>";
}
?>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Fault">Fault:</label></td>
<td><input type="text"  class="form-control" id="Fault" name="Fault" value="<?php echo set_value('Fault');?>"/></td>
<?php if(form_error('Fault'))
{
echo "<span style='color:red'>".form_error('Fault')."</span>";
}
?>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="TotalCost"> Total Cost:</label></td>
<td><input type="text"  class="form-control" id="TotalCost" name="TotalCost" value="<?php echo set_value('TotalCost');?>"/></td>
<?php if(form_error('TotalCost'))
{
echo "<span style='color:red'>".form_error('TotalCost')."</span>";
}
?>
</div>
</tr>
</table>
<tr>
<div class="form-group">
      <label for="TimeToRepair">Select No of hours for repair:</label>
      <select class="form-control" id="TimeToRepair" name="TimeToRepair">
        <option>01:00:00.000000</option>
        <option>02:00:00.000000</option>
        <option>03:00:00.000000</option>
        <option>04:00:00.000000</option>
        <option>05:00:00.000000</option>
        <option>06:00:00.000000</option>
        <option>07:00:00.000000</option>
        <option>08:00:00.000000</option>
        <option>09:00:00.000000</option>
 </select>
<?php if(form_error('TimeToRepair'))
{
echo "<span style='color:red'>".form_error('TimeToRepair')."</span>";
}
?>
</div>
<input type="submit" class="btn btn-info" value="Add Fault" name="save">
	
</form>

</body>
</html>