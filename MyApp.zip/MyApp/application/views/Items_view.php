<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Register Items For Sale</h1>
</head>
<body>
<div class="container">


<form method="post">
<table class="table">


<tr>
<div class="form-group">
<td><label for="ModelNo">Model No:</label></td>
<td><input type="text"  class="form-control" id="ModelNo"name="ModelNo" value="<?php echo set_value('ModelNo');?>"/></td>
<?php if(form_error('ModelNo'))
{
echo "<span style='color:red'>".form_error('ModelNo')."</span>";
}
?>
</div>
</tr>



<tr>
<div class="form-group">
<td><label for="Price">Unit Price:</label></td>
<td><input type="text" class="form-control" id="Price" name="Price" value="<?php echo set_value('Price');?>"/></td>
<?php if(form_error('Price'))
{
echo "<span style='color:red'>".form_error('Price')."</span>";
}
?>
</div>
</tr>

</table>



<div class="form-group">

<label>Supplier</label>
<select class="form-control" name="SupplierID"  value= "<?php echo set_value($Supplier['SupplierID']); ?>" required>
 <option value="">Select Supplier</option>'
    <?php
    foreach($groups as $Supplier)
    {
     
        echo '<option value="'.$Supplier['SupplierID'].'">'.$Supplier['SupplierName'].'</option>';
        
    }
    ?>  
   

</select> <br/>
<?php if(form_error('SupplierID'))
{
echo "<span style='color:red'>".form_error('SupplierID')."</span>";
}
?>

<input type="submit" class="btn btn-info" value="Add Item" name="save">
	
	



</form>
</div>
</body>
</html>