

<!DOCTYPE html>
<head>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>
<h1 align="center";> Update Personal Details</h1>
</head>
<body>
<div class="container">
<?php
foreach($data1 as $row){
//?>
<form id="myForm" method="post">
<table class="table">

<tr>
<div class="form-group">
<td><label for="CustomerID">Customer ID:</label></td>
<td><input type="text" class="form-control"  id="CustomerID" name="CustomerID" value="<?php echo $row->CustomerID;?>"disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="FirstName">FirstName:</label></td>
<td><input type="text" class="form-control"  id="FN" name="FirstName" value="<?php echo $row->FirstName;?>"disabled></td>
</div>
</tr>


<tr>
<div class="form-group">
<td><label for="LastName">LastName:</label></td>
<td><input type="text" class="form-control" id="LN" name="LastName" value="<?php echo $row->LastName;?>" disabled></td>
</div>
</tr>

<tr>
<div class="form-group">
<td><label for="Address">Address:</label></td>
<td><input type="text" class="form-control" id="Address" name="Address" value="<?php echo $row->Address;?>"></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="ContactNo">ContactNo:</label></td>
<td><input type="text" class="form-control" id="ContactNo" name="ContactNo" value="<?php echo $row->ContactNo;?>"></td>
</div>
</tr>
<tr>
<div class="form-group">
<td><label for="Email">E-Mail:</label></td>
<td><input type="text"  class="form-control" id="Email" name="Email" value="<?php echo $row->Email;?>" disabled></td>
</tr>
<p> Note: If you wish to update FirstName, LastName and E-mail address please contact the Administrator </p>
</table>
	<input type="submit" class="btn btn-info" name= "update" value="Update My Details">
</tr>
</form>


<?php
} ?>

</body>
</html>
</html>