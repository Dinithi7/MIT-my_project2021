<?php

class Item_Image_Controller extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
                $this->load->database();

                $this->load->helper(array('form'));
                $this->load->library(array('form_validation'));
                $this->load->helper('url');
                $this->load->library('upload');
                $this->load->model('image_model');
        }

       public function index()

        {      
                $data['groups']=$this->image_model->getAllModels();
                //$this->load->view('upload_item_image_view',$data, array('error' => ' ' ));
                $result=array('error' => ' ' );
                $new_array = array_merge($data,$result);
                $this->load->view('upload_item_image_view',$new_array);
        }

        public function do_upload()
        {       $data['groups']=$this->image_model->getAllModels();
                //$this->load->view('upload_item_image_view',$data, array('error' => ' ' ));
               //--------------------------------------------------
               
               $this->form_validation->set_rules('Id', 'Id', 'required');
                //if($this->form_validation->run()==TRUE){
              //if($this->input->post('submit')){
                
                $fileData = array();
                $config['upload_path']          = './uploads/';
             
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);
                $this->upload->initialize($config);
              
               
                if ( ! $this->upload->do_upload('userfile'))
                {
                             
                        $error = array('error' => $this->upload->display_errors());

                        $this->load->view('upload_item_image_error',$error);
                        $this->load->view('upload_item_image_view',$data);
                        
                }
                else
                {       $Id=$this->input->post("Id");
                        //----------------------------------------------------
                        $data = $this->upload->data(); // Get the file data
                        $fileData[] = $data; // It's an array with many data
                        // Interate throught the data to work with them
                        foreach ($fileData as $file) {
                        $file_data = $file;}
                       $Image=$file_data['file_name'];
                      // $Image=$file_data['full_path'];
                        $this->image_model->update_items_image($Id,$Image);
                        /*$this->db->insert('abc', array(
                    
                               
                                'ModelNo' =>$ModelNo, 
                                
                                
                                'Image' => $file_data['file_name'],
                                
                            ));*/
   
                        $data1 = array('upload_data' => $this->upload->data());

                        $this->load->view('upload_item_image_success', $data1);
                        
                }
     
}
        //*******************************************************************************/
        public function view_image()
        {
               // $this->load->view('items_view', array('error' => ' ' ));
			   $this->load->helper('html');
				$this->load->model('image_model');
				
				//$data1= $this->image_model->getimage();
                             // $image['items'] = $this->image_model->getimage();
                             $image= $this->image_model->getimage();
				//$this->load->view('gallery', $data1);
                                $this->load->view('gallery',$image);
			
        }
        
}
?>