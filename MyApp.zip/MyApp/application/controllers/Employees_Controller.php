<?php
class Employees_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Employees_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');

}
//**************************************************************************************** */
//code below is for ADMIN save employee categories and update employee categories
public function savedataEC(){

$this->form_validation->set_rules('CatName','CatName','required');
$this->form_validation->set_rules('Salary','Salary','required');
$this->form_validation->set_rules('FullDays','FullDays','required');
$this->form_validation->set_rules('HalfDays','HalftDays','required');
$this->form_validation->set_rules('ShortLeave','ShortLeave','required');
if($this->form_validation->run()==FALSE){
$this->load->view('ECategory_view');
if($this->input->post('save')){
$CatName=$this->input->post("CatName");
$Salary=$this->input->post('Salary');
$FD=$this->input->post('FullDays');
$HD=$this->input->post('HalfDays');
$SH=$this->input->post('ShortLeave');
}}
else
{
	
$CatName=$this->input->post("CatName");
$Salary=$this->input->post('Salary');
$FD=$this->input->post('FullDays');
$HD=$this->input->post('HalfDays');
$SH=$this->input->post('ShortLeave');

$this->Employees_Model->saverecordsEC($CatName,$Salary,$FD,$HD,$SH);
echo "Records saved successfully";

}

}
public function updateEC(){

$this->load->model("Employees_Model");
$data1['groups']=$this->Employees_Model->getAllCategories();
$this->load->view('SearchEC_view',$data1);
$CatName=$this->input->post('CatName');
if($this->input->post('Search')){

    if ($CatName=="")

    { echo '<p style="color: red; text-align:center;">
        Category Selection is required
        </p>';

    }
     else{
        $result['data']=$this->Employees_Model->display_EC($CatName); 
        $this->load->view('update_ECategory',$result );  
    }
}
if($this->input->post('update')){
$CatName=$this->input->post('CatName');
$Salary=$this->input->post('Salary');
$FD=$this->input->post('FullDays');
$HD=$this->input->post('HalfDays');
$SH=$this->input->post('ShortLeave');;

$this->Employees_Model->update_EC($CatName,$Salary,$FD,$HD,$SH);
echo "The record was updated";
}

}
//************************************************************************************************* */
//code below is for ADMIN to register employees
public function savedata(){
    $this->load->model("Employees_Model");
    $data1['groups']=$this->Employees_Model->getAllCategories();

    $this->form_validation->set_rules('FirstName','FirstName','required');
    $this->form_validation->set_rules('LastName','LastName','required');
    $this->form_validation->set_rules('NICNo','NICNo','required|min_length[10]|max_length[12]');
    $this->form_validation->set_rules('Address','Address','required');
    $this->form_validation->set_rules('ContactNo','ContactNo','required|min_length[10]|max_length[10]');
    $this->form_validation->set_rules('Gender','Gender','required');
    $this->form_validation->set_rules('DOB','DOB','required');
    $this->form_validation->set_rules('DateJoined','DateJoined','required');
    $this->form_validation->set_rules(
        'Username', 'Username',
        'required|is_unique[Users.Email]|valid_email',
        
        array(
                'required'      => 'Email field is required.',
                'is_unique'     => 'There is another account with this email.Please use another e-mail address to register.'
        )
    );
  
    $this->form_validation->set_rules('CatID','CatID','required');
    
   
    
    $this->form_validation->set_rules('Password','Password','required|min_length[8]');
    $this->form_validation->set_rules('ConfirmPassword','ConfirmPassword','required|min_length[8]|matches[Password]');
    
    if($this->form_validation->run()==FALSE){
    $this->load->view('ERegistration_view',$data1);
    if($this->input->post('save')){
       
       
    $FN=$this->input->post("FirstName");
    $LN=$this->input->post('LastName');
    $NIC=$this->input->post('NICNo');
    $AD=$this->input->post('Address');
    $CN=$this->input->post('ContactNo');
    $Gender=$this->input->post('Gender');
    $DOB=$this->input->post('DOB');
    $DJ=$this->input->post('DateJoined');
    $UN=$this->input->post('Username');
    
    $CatID=$this->input->post('CatID'); 
    
    
    
    $PW=sha1($this->input->post('Password'));
    $CPW=sha1($this->input->post('ConfirmPassword'));
    //---------------------------------------------------
    //input from form is CatID, model function gets the respective CatName
    $this->load->model("Employees_Model");
    $CatName=$this->Employees_Model->getCatName($CatID);
    //-----------------------------------------------------
    
    }}
    else
    {
        $date=date('Y-m-d');
        $FN=$this->input->post("FirstName");
        $LN=$this->input->post('LastName');
        $NIC=$this->input->post('NICNo');
        $AD=$this->input->post('Address');
        $CN=$this->input->post('ContactNo');
        $Gender=$this->input->post('Gender');
        $DOB=$this->input->post('DOB');
        $DJ=$this->input->post('DateJoined');
        $UN=$this->input->post('Username');
       
        $CatID=$this->input->post('CatID');
        
    
        $PW=sha1($this->input->post('Password'));
        $CPW=sha1($this->input->post('ConfirmPassword'));
       //---------------------------------------------
       $this->load->model("Employees_Model");
       $CatName=$this->Employees_Model->getCatName($CatID);
    //--------------------------------------------------------------
        
        $Status="Activated";
        if($DJ>$date)
        {
            echo '<span style="color:blue;">Unable to save details. The Employee Joined date cannot be in the future.</span>';
    
            $this->load->view('ERegistration_view',$data1);
           
        }else if($DOB>$date){

            echo '<span style="color:blue;">Unable to save details.You have selected a day in the future as Date of Birth.</span>';
            
            $this->load->view('ERegistration_view',$data1);

        }
        else{
        $this->Employees_Model->saverecords($FN,$LN,$NIC,$AD,$CN,$Gender,$DOB,$DJ,$UN,$CatID);
        
        $this->Employees_Model->saveusers($UN,$FN,$LN,$PW,$CatName,$Status);
        echo "Records saved successfully";
        }    
       
    }
    
    }
//------------------------------------------------------------------------------------------------------
public function displaydata(){
	$result['data']=$this->Employees_Model->display_employees();
	$this->load->view('display_employees',$result);	
}
//------------------------------------------------------------------------------------
public function updatedata(){
	$EmpID=$this->input->get('EmpID');
	$result['data']=$this->Employees_Model->displayitemsbyid($EmpID);
    $this->load->model("Employees_Model");
    // code below is to display categories
    $data1['groups']=$this->Employees_Model->getAllCategories();
	
	$new_array = array_merge($result,$data1);
	
	$this->load->view('update_employees',$new_array );
    

if($this->input->post('update')){
$EmpID=$this->input->get('EmpID');
$FN=$this->input->post('FirstName');
$LN=$this->input->post('LastName');
$NIC=$this->input->post('NICNo');
$AD=$this->input->post('Address');
$CN=$this->input->post('ContactNo');
$EM=$this->input->post('Email');

$CatName=$this->input->post('CatName');
$Status=$this->input->post('Status');

$this->Employees_Model->update_employee_users($EmpID,$FN,$LN,$EM,$CatName,$Status);
//---------------------------------------------------
$this->load->model("Employees_Model");
//input from form is CatName, sentence below gets the CatID from it
//---------------------------------------------------
$CatID=$this->Employees_Model->getCatID($CatName);
//-------------------------------------------------------
$this->Employees_Model->update_employees($EmpID,$FN,$LN,$NIC,$AD,$CN,$EM,$CatID);

echo "The record was updated";
redirect("Employees_Controller/displaydata");

}
}
//----------------------------------------------------------------------
public function deletedata(){
    $Email=$this->input->get('Email');
    
    $this->Employees_Model->delete_employees($Email);
    echo "Records deleted";
    }
//---------------------------------------------------------------------
}
?>
