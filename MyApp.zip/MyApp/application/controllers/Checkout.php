<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller{
    
    function  __construct(){
        parent::__construct();
        
        // Load form library & helper
        $this->load->library('form_validation');
        $this->load->helper('form');
        $this->load->helper('url');
        
        // Load cart library
        $this->load->library('cart');
        
        // Load product model
        $this->load->model('product');
        
        $this->controller = 'checkout';
    }
    //****************************** */
    //the index function below is not in use
    function index(){
        // Redirect if the cart is empty
        if($this->cart->total_items() <= 0){
            redirect('products/');
        }
        
        
        $custData = $data = array();
        
        // If order request is submitted
        $submit = $this->input->post('placeOrder');
        if(isset($submit)){
            // Form field validation rules
            $this->form_validation->set_rules('FirstName', 'FirstName', 'required');
            $this->form_validation->set_rules('LastName', 'LastName', 'required');
            $this->form_validation->set_rules('Address', 'Address', 'required');
            $this->form_validation->set_rules('ContactNo', 'ContactNo', 'required');
            $this->form_validation->set_rules('Email', 'Email', 'required|valid_email');
            
            
            // Prepare customer data
            $custData = array(
                'FirstName'     => strip_tags($this->input->post('FirstName')),
                'LastName'     => strip_tags($this->input->post('LastName')),
                'Email'     => strip_tags($this->input->post('Email')),
                'ContactNo'     => strip_tags($this->input->post('ContactNo')),
                'Address'=> strip_tags($this->input->post('Address'))
            );
            // Validate submitted form data
            if($this->form_validation->run() == true){
                // Insert customer data
                $insert = $this->product->insertCustomer($custData);
                
                // Check customer data insert status
                if($insert){
                    // Insert order
                    $order = $this->placeOrder($insert);
                    
                    // If the order submission is successful
                    if($order){
                        $this->session->set_userdata('success_msg', 'Order placed successfully.');
                        redirect($this->controller.'/orderSuccess/'.$order);
                    }else{
                        $data['error_msg'] = 'Order submission failed, please try again.';
                    }
                }else{
                    $data['error_msg'] = 'Some problems occured, please try again.';
                }
            }
        }
        
        // Customer data
        $data['custData'] = $custData;
        // Retrieve cart data from the session
        $data['cartItems'] = $this->cart->contents();
        
        // Pass products data to the view
       // $this->load->view($this->controller.'/index', $data);
       $this->load->view($this->controller, $data);
    }
    
    function placeOrder($custID){
        // Insert order data
        $ordData = array(
            'CustomerID' => $custID,
            'GrandTotal' => $this->cart->total(),

            //.................................................by me
            'Status'=> "Ordered"
            //...............................................end by me
        );
        $insertOrder = $this->product->insertOrder($ordData);
        
        if($insertOrder){
            // Retrieve cart data from the session
            $cartItems = $this->cart->contents();
            
            // Cart items
            $ordItemData = array();
            $i=0;
            foreach($cartItems as $item){
                $ordItemData[$i]['OrderID']     = $insertOrder;
               //$ordItemData[$i]['product_id']     = $item['id'];
               $ordItemData[$i]['ProductID']     = $item['id'];
                $ordItemData[$i]['Quantity']     = $item['qty'];
               
                $ordItemData[$i]['SubTotal']     = $item["subtotal"];

                //me..........................................................
                $this->load->model("product");
                $this->product->updatequantity($item['id'],$item['qty']);
               //-------------------------------------------------------
             
               //to get warranty saved into orderitems table
                $this->load->model("Customers_Model");
                $Warranty=$this->Customers_Model->getWarrantyOfProduct($item['id']);
                if ($Warranty=="1 month")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+1 month'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }
                else if ($Warranty=="3 months")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+3 months'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }

                else if ($Warranty=="6 months")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+6 months'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }

                else if ($Warranty=="1 year")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+1 year'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }

                else if ($Warranty=="2 years")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+2 years'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }

                else if ($Warranty=="3 years")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+3 years'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }
                else if ($Warranty=="4 years")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+4 years'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }
                else if ($Warranty=="5 years")
                {
                    $WarrantyExpires=date('Y-m-d',strtotime('+5 years'));
                    $ordItemData[$i]['WarrantyExpires']=$WarrantyExpires;
                }
                //------------------------------------------------------end of me
                //..................................................................
                $i++;

                
            }
            if(!empty($ordItemData)){
            
                // Insert order items
                $insertOrderItems = $this->product->insertOrderItems($ordItemData);
                
                if($insertOrderItems){
                    // Remove items from the cart
                    $this->cart->destroy();
                    
                    // Return order ID
                    return $insertOrder;
                }
            }
        }
        return false;
    }
    
    function orderSuccess($ordID){
        // Fetch order data from the database
        $data['order'] = $this->product->getOrder($ordID);
        
        // Load order details view
      //  $this->load->view($this->controller.'/order-success', $data);
      $this->load->view('order_success', $data);
      
      //--------------------------------by me 
      /*
      if($this->input->post('save')){
        
       
          redirect('Customers_Controller/viewmyorderInvoice');
          
      }
      */
      //-------------------------------end by me
    }
    //--------------------------------------------------------------------------------
    public function CheckOutForRegisteredCustomer()
    {
        
        $varName =$this->session->userdata('Email');
        if($varName!=""){
        //****************************************************** */
        $this->load->model('product');
        $CustomerID=$this->product-> getCustomerID($varName); 
        //-----------------------------------------------------------
       
        // Redirect if the cart is empty
        if($this->cart->total_items() <= 0){
            redirect('products/');
        }
        $order = $this->placeOrder($CustomerID);
                   
        // If the order submission is successful
        if($order){
            $this->session->set_userdata('success_msg', 'Order placed successfully.');
            redirect($this->controller.'/orderSuccess/'.$order);
        }else{
            $data['error_msg'] = 'Order submission failed, please try again.';
        }
    }
        //******************************************************* */
        else if ($varName==""){
            
            
            
            $custData = $data = array();
            
            // If order request is submitted
            $submit = $this->input->post('placeOrder');
            if(isset($submit)){
                // Form field validation rules
                $this->form_validation->set_rules('FirstName', 'FirstName', 'required');
                $this->form_validation->set_rules('LastName', 'LastName', 'required');
                $this->form_validation->set_rules('Address', 'Address', 'required');
                $this->form_validation->set_rules('ContactNo', 'ContactNo', 'required');
               // $this->form_validation->set_rules('Email', 'Email', 'required|valid_email');
                //.....................by me

                $this->form_validation->set_rules(
                    'Email', 'Email',
                    'required|is_unique[Users.Email]|valid_email',
                    
                    array(
                            'required'      => 'Email field is required.',
                            'is_unique'     => 'There is another account with this email.Please use another e-mail address to register.'
                    )
                );

                //.............................end by me
                
                // Prepare customer data
                $custData = array(
                    'FirstName'     => strip_tags($this->input->post('FirstName')),
                    'LastName'     => strip_tags($this->input->post('LastName')),
                    'Email'     => strip_tags($this->input->post('Email')),
                    'ContactNo'     => strip_tags($this->input->post('ContactNo')),
                    'Address'=> strip_tags($this->input->post('Address'))
                );
                // Validate submitted form data
                if($this->form_validation->run() == true){
                    // Insert customer data
                    $insert = $this->product->insertCustomer($custData);
                    
                    // Check customer data insert status
                    if($insert){
                        // Insert order
                        $order = $this->placeOrder($insert);
                        
                        // If the order submission is successful
                        if($order){
                            $this->session->set_userdata('success_msg', 'Order placed successfully.');
                            redirect($this->controller.'/orderSuccess/'.$order);
                        }else{
                            $data['error_msg'] = 'Order submission failed, please try again.';
                        }
                    }else{
                        $data['error_msg'] = 'Some problems occured, please try again.';
                    }
                }
            }
            
            // Customer data
            $data['custData'] = $custData;
            // Retrieve cart data from the session
            $data['cartItems'] = $this->cart->contents();
            
            // Pass products data to the view
           // $this->load->view($this->controller.'/index', $data);
           $this->load->view($this->controller, $data);
        }
        //----------------------------------------------------------------------------------------
    }
    //..............................by me
// code below is to print an invoice for shopping cart payment

public function view_undelivered_shoppingitems()
{
    $this->load->model('product');
    $result11['data11']=$this->product->display_undelivered_orders();
    $this->load->view('display_SCart_undeliveredItems',$result11);
}

public function update_shopping_delivery()

{
    $OrderID=$this->input->get('OrderID');
    $this->load->model('product');
	$result12['data12']=$this->product->PageToupdateShoppingCartOrderStatus($OrderID);
    $result12['data14']=$this->product->getOrderItemsTableDetails($OrderID);
    $result12['data15']=$this->product->getGrandTotal($OrderID);
    $this->load->view('update_cart_orderstatus',$result12);
    if($this->input->post('update')){
        $OrderID=$this->input->get('OrderID');
        $Status=$this->input->post('Status');  
        $this->product->updatestatusofdelivery($OrderID);
        echo "The record was updated";
    }
}

public function Invoice_delivery()
{
    $OrderID=$this->input->get('OrderID');
    $this->load->model('product');
	$result13['data13']=$this->product->PageToupdateShoppingCartOrderStatus($OrderID);
    $result13['data14']=$this->product->getOrderItemsTableDetails($OrderID);
    $result13['data15']=$this->product->getGrandTotal($OrderID);
    $this->load->view('display_Invoice_delivery',$result13);
}
    //................................end me
       
    
}