<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Homepage_Controller extends CI_Controller
{
    public function __construct(){
        parent::__construct();
        $this->load->database();
         // Load cart library
         $this->load->library('cart');
        
         // Load product model
         $this->load->model('product');
         $this->load->model('Homepage_Model');
        $this->load->helper(array('form'));
        $this->load->library(array('form_validation'));
        $this->load->helper('url');
        $this->load->helper('email');  

 }
 public function index() { 
    
    $this->load->view('header');
    $this->load->view('homepage_view');

    //*********************************************************************************** */
    //$this->load->view('Homepage_carousels');
    //************************************************************************************ */
    $data = array();
    $this->load->model('product');
    // Fetch products from the database
    $data['products'] = $this->product->getRows();
  
    
    // Load the product list view
  //  $this->load->view('products/index', $data);
    $this->load->view('products', $data);
   
    $this->load->view('footer');
 }

 ///------------------------------------------------------------------------------
 public function SearchItemsByName()
 {
   
  if($this->input->post('Search')){
    $Search=$this->input->post("Search1");
    
    $this->load->model('Homepage_Model');
    $data1['products'] = $this->Homepage_Model->SearchProductName($Search);
    $this->load->view('Search_Products_HomePage', $data1);
    
 }
}
public function ContactUs()
{
  
    $this->form_validation->set_rules('FirstName','FirstName','required');
    $this->form_validation->set_rules('LastName','LastName','required');
    $this->form_validation->set_rules('Subject','Subject','required');
    $this->form_validation->set_rules(
      'ContactNo', 'ContactNo',
      'min_length[10]|max_length[10]');
  $this->form_validation->set_rules('Email','Email','valid_email');
    
    if($this->form_validation->run()==FALSE){
    $this->load->view('ContactUs');
    if($this->input->post('save')){
    $FirstName=$this->input->post("FirstName");
    $LastName=$this->input->post('LastName');
    $Subject=$this->input->post('Subject');
    $ContactNo=$this->input->post('ContactNo');
    $Email=$this->input->post('Email'); 
    $date=date('Y-m-d');  
    }}
    else
    {
      $FirstName=$this->input->post("FirstName");
      $LastName=$this->input->post('LastName');
      $Subject=$this->input->post('Subject');
      $ContactNo=$this->input->post('ContactNo');
      $Email=$this->input->post('Email');
    $date=date('Y-m-d'); 
       
    $this->Homepage_Model->saveContactMessages($FirstName,$LastName,$Subject,$ContactNo,$Email,$date);
    echo "Records saved successfully";
    redirect('Homepage_Controller/');
       
    }
    

}
public function AboutUsPage()
{
  $this->load->view('display_about_us_details');
}


}

 ?>



 
  
