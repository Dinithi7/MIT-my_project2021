<?php  
 defined('BASEPATH') OR exit('No direct script access allowed');  
 class login1_controller extends CI_Controller {  
     public function __construct(){
          parent::__construct();
          $this->load->database();
          $this->load->model("Login1_Model");
          $this->load->helper(array('form'));
          $this->load->library(array('form_validation'));
          $this->load->helper('url');
          $this->load->library('session');
     } 
      function login()  
      {  
           
           $data['title'] = 'Log In';  
           $this->load->view("login1_view",$data);  
      }  
     function login_validation()  
      {  
           $this->load->library('form_validation'); 
           
           
           $this->form_validation->set_rules('Email', 'Email', 'required');  
           $this->form_validation->set_rules('Password', 'Password', 'required');  
          // $this->form_validation->set_rules('Category','Category','required');
           
           if($this->form_validation->run())  
           { 
               if($this->input->post('Login')) {
                //true  
                $username = $this->input->post('Email');  
                $password = sha1($this->input->post('Password'));
               // $category = $this->input->post('Category');
           
                //model function  
                $this->load->model('login1_model');
               
              /*
              -----------------------------------------
               $user_data = $this->login1_model->can_login($username,$FirstName,$LastName,$password,$category);
                if ($user_data) {
                    $session_data = array(
                        'Email' => $username,
                        'FirstName' => $user_data->FirstName,  // This value from DB
                        'LastName' => $user_data->LastName,   // This value from DB
                        'Category'     =>     $category
                 );
        
                $this->session->set_userdata($session_data);  
                ------------------------------------------------------*/
                
                if($this->login1_model->can_login($username, $password,$category))  
                {  
                     $session_data = array(  
                          'Email'     =>     $username,
                          'Password'  =>     $password
                          
                          
                     );  
                     $this->session->set_userdata($session_data); 

                     redirect('login1_controller/enter'); 
    
                }  
                else  
                {  
                     $this->session->set_flashdata('error', 'Invalid Log in details'); 
                     redirect('login1_controller/login_validation');  
                }  
               }
               
           }  
           else  
           {  
                //false  
                $this->login();  
           }  
      }  

      
      function enter(){ 
          $varName =$this->session->userdata('Email');
          $password =$this->session->userdata('Password');
          $this->load->model('login1_Model');
          $result['data']=$this->login1_Model->display_names($varName,$password);
          $this->load->view('loginnames_view',$result);
         
          $varName =$this->session->userdata('Email'); 
          $password =$this->session->userdata('Password');
          $this->load->model('login1_Model');
        
      
       $Cat=$this->login1_Model->getCategory($varName,$password);
       $Status=$this->login1_Model->getStatus($varName,$password);
      if ($Status=="Activated")
      {  
        if($Cat == "DEO"){
                    
        $this->load->view("ProfilePage_DEO_view");
      } else if ($Cat == "Technician"){
         
        $this->load->view("ProfilePage_Technician_view");
      }  
        else if  ($Cat == "Administrator"){
         
        $this->load->view("ProfilePage_Admin_view");
     }
     else if ($Cat== "Customer")
     {
         $this->load->view("ProfilePage_Customer_view");
     }
     else if ($Cat== "Supplier")
     {
         $this->load->view("ProfilePage_Supplier_view");
     } 
     else if ($Cat== "Manager")
     {
         $this->load->view("ProfilePage_Manager_view");
     }
      
     else {

          redirect('login1_controlller/login_validation');
     }}
     //--------------------------------------------------------------------
      //-----------------------------------------------------------------------
  else if ( ($Status=="Deactivated") && ($Cat == "DEO") ||($Cat == "Technician") ||($Cat == "Manager"))
  {
     echo '<span style="color:blue;">Your Account has been deactivated by the Administrator </span>';
  }
  //-----------------------------------------------------------------------
     //-------------------------------------------------------------------
     else if ($Cat== "Supplier" && $Status=="Requested")
     {
         
         echo '<span style="color:blue;">Your Supplier Account has not been activated</span>';
     }
     //----------------------------------------------------------------
    /* else if ($Cat== "Supplier" && $Status=="Deactivated")
     {
         
         echo '<span style="color:blue;">Your Supplier Account has been Deactivated</span>';
     }*/
     //----------------------------------------------------------------
     else
     {
          $this->load->view("deactivatedAccount_view",$result);
          // this page calls the reactivate function
     }
     //----------------------------------------------------------
      
         
   }  
   public function logout()  
   {  
        $this->session->unset_userdata('Email');  
        $this->session->sess_destroy();
        redirect('login1_Controller/login_validation');
       
        
   } 

//------------------------------------------------------------------
// code below is to reactivate a deactivated user
//the user is directed to the profile page upon activation
public function Reactivate(){
     $varName =$this->session->userdata('Email');
     $password =$this->session->userdata('Password');
     $this->load->model('login1_Model');
     
     
     $this->load->model('login1_Model');
     $this->login1_Model->reactivate($varName,$password); 
    
    //echo '<span style="color:blue;">Your Account is now re-activated</span>';
    
     
     $result['data']=$this->login1_Model->display_names($varName,$password);
     $this->load->view('loginnames_view',$result);
    
    $Cat=$this->login1_Model->getCategory($varName,$password);
    $Status=$this->login1_Model->getStatus($varName,$password);
   if ($Status=="Activated")
   {  
     if($Cat == "DEO"){
               
     $this->load->view("ProfilePage_DEO_view");
   } else if ($Cat == "Technician"){
      
     $this->load->view("ProfilePage_Technician_view");
   }  
     else if  ($Cat == "Administrator"){
      
     $this->load->view("ProfilePage_Admin_view");
  }
  else if ($Cat== "Customer")
  {
      $this->load->view("ProfilePage_Customer_view");
  }
  else if ($Cat== "Supplier")
  {
      $this->load->view("ProfilePage_Supplier_view");
  } 
  else if ($Cat== "Manager")
  {
      $this->load->view("ProfilePage_Manager_view");
  } 
  else {

       redirect('login1_controlller/login_validation');
  }}
 
  else
  {
       $this->load->view("deactivatedAccount_view",$result);
    
  }
    
}
//----------------------------------------------------------------------------------------------------
// the code below is to deactivate an account, this is ONLY for customers and suppliers
public function DeactivateAccount()
{
     $varName =$this->session->userdata('Email');
     $password =$this->session->userdata('Password');
     $this->load->model('login1_Model');

     $this->load->model('login1_Model');
     $this->login1_Model->deactivate_C_and_S($varName,$password); 
    
    echo '<span style="color:blue;">Your Account is now de-activated.</span>';
    echo "&nbsp";
    echo '<span style="color:blue;">If you wish to reactivate, log in again and activate your account</span>'; 
    
    
}
//--------------------------------------------------------------------------------------------------------  
// the code below lets the CUSTOMER update his/her details through the profile page
public function UpdateCustomerDetails_C(){
     $varName =$this->session->userdata('Email');
     $password =$this->session->userdata('Password');
     $this->load->model('login1_Model');
     //$result['data']=$this->login1_Model->display_names($varName,$password);
     $result1['data1']=$this->login1_Model->displayCustomerDetails_C($varName,$password);
     
     $this->load->view('update_Customer_C',$result1);
    // $this->form_validation->set_rules('Address','Address','required');
    // $this->form_validation->set_rules('ContactNo','ContactNo','required|min_length[10]|max_length[10]');
   
     //if($this->form_validation->run()==TRUE){
     if($this->input->post('update')){
         
          
          $CustomerID=$this->input->get('CustomerID');
          $FN=$this->input->post('FirstName');
          $LN=$this->input->post('LastName');
          $AD=$this->input->post('Address');
          $CN=$this->input->post('ContactNo');
          $EM=$this->input->post('Email');
          
         // $this->login1_Model->update_customers_users($CustomerID,$FN,$LN,$EM,$varName);
          $this->login1_Model->update_customers($CustomerID,$FN,$LN,$AD,$CN,$EM,$varName);
 //}
          redirect("login1_controller/UpdateSuccessfulMessage");   
                     
}
}
//-----------------------------------------------------------------------------------------------
// the function below can be used to display that any query about personal details was successfully updated
public function UpdateSuccessfulMessage()
{
     $this->load->view('update_message_after_query'); 
 
}
//------------------------------------------------------------------------------------------------
//********************************************************************************************* */ 
//code below is to let the EMPLOYEE update personal details
public function UpdateEmployeeDetails_E(){
     $varName =$this->session->userdata('Email');
     $password =$this->session->userdata('Password');
     $this->load->model('login1_Model');
     //$result['data']=$this->login1_Model->display_names($varName,$password);
     $result['data2']=$this->login1_Model->displayEmployeeDetails_E($varName,$password);
     
     $this->load->view('update_Employee_E',$result);
    // $this->form_validation->set_rules('Address','Address','required');
    // $this->form_validation->set_rules('ContactNo','ContactNo','required|min_length[10]|max_length[10]');
   
     //if($this->form_validation->run()==TRUE){
     if($this->input->post('update')){
         
          
          $EmpID=$this->input->get('EmpID');
          $FN=$this->input->post('FirstName');
          $LN=$this->input->post('LastName');
          $NIC=$this->input->post('NICNo');
          $AD=$this->input->post('Address');
          $CN=$this->input->post('ContactNo');
          $EM=$this->input->post('Email');
          
         // $this->login1_Model->update_customers_users($CustomerID,$FN,$LN,$EM,$varName);
          $this->login1_Model->update_employees($EmpID,$FN,$LN,$NIC,$AD,$CN,$EM,$varName);
 //}
          redirect("login1_controller/UpdateSuccessfulMessage");   
                     
}
}
//********************************************************************************************** */
function change_password()  
{  
     $this->load->library('form_validation'); 
     
     
     $this->form_validation->set_rules('ExistingPassword', 'ExistingPassword', 'required');  
     $this->form_validation->set_rules('NewPassword', 'NewPassword', 'required|min_length[8]'); 
     $this->form_validation->set_rules('ConfirmPassword','ConfirmPassword','required|min_length[8]|matches[NewPassword]');

     if($this->form_validation->run()==FALSE){
          $this->load->view('change_password_view');
          
          if($this->input->post('Update')){
          $ExistingPassword=sha1($this->input->post("ExistingPassword"));
          $NewPassword=sha1($this->input->post("NewPassword"));
          
          
          }}
          else
          {  
          $ExistingPassword=sha1($this->input->post("ExistingPassword"));    
          $NewPassword=sha1($this->input->post("NewPassword"));
          
          $varName =$this->session->userdata('Email');
          $password =$this->session->userdata('Password');
          if($ExistingPassword==$password)
          {
          $this->load->model("login1_Model");
          $this->login1_Model->change_password($NewPassword,$varName,$password);
          echo '<span style="color:blue;">Your password was changed.</span>';
          }
          else{
               echo '<span style="color:red;">You have not entered your existing password correctly.</span>';
          }
          
          }
     }
//********************************************************************************************** */ 
// code below is to let each Technician view his/her repairs
public function TechnicianViewRepairs(){
     $varName =$this->session->userdata('Email');
     
     $this->load->model('login1_Model');
     
     $result2['data3']=$this->login1_Model->viewTechnicianJobs($varName);
     
     $this->load->view('display_repairs_Technician_view',$result2);
 }
 //--------------------------------------------------------
 //code below lets each Technician Update his/her Repairs
 public function updatedata(){
	$RepairID=$this->input->get('RepairID');
     $this->load->model('Repairs_Model');
	$result['data']=$this->Repairs_Model->displayitemsbyid($RepairID);
	
	$FaultID=$this->Repairs_Model->getFaultIDToUpdatePage($RepairID);
	$result['data1']=$this->Repairs_Model->getFaultNameToUpdatePage($FaultID);
	$result['data2']=$this->Repairs_Model->getEmailToUpdatePage($RepairID);
	
	$this->load->view('update_repairs_shop',$result);

if($this->input->post('update')){
$RepairID=$this->input->get('RepairID');
//$CustomerID=$this->input->post('CustomerID');

$ID=$this->input->post('Description');
//$Fault=$this->input->post('Fault');
$CN=$this->input->post('ContactNo');
$AD=$this->input->post('AcceptDate');
$RD=$this->input->post('ReturnDate');
$cost=$this->input->post('TotalCost');
$paid=$this->input->post('AdvancePaid');
$Balance=$this->input->post('Balance');
$Status=$this->input->post('Status');
$date=date('Y-m-d');
$this->load->model('login1_model');
//$this->login1_model->update_repairs($RepairID,$RD,$Status);
//------------------------------------------------------------------------

if($RD<$date){
	echo '<span style="color:blue;">Return date is in the past. Unable to Update Job.</span>';
	
	}
//------------------------------------------------------------------
else {
     $this->login1_model->update_repairs($RepairID,$RD,$Status);
//------------------------------------------------------------------------
 if ($Status=="Ready")
{
// E-MAIL code comes here
/*
function send()
       { 
         $this->load->library('email'); 
         $this->load->config('email');
         

         $from = $this->config->item('smtp_user');
	   // $from_email ="mymitproject2021@gmail.com"; 
         $to_email ="dinadee8877@gmail.com";  
         $this->email->from($from); 
         $this->email->to($to_email);
         $this->email->subject('Email Test'); 
         $this->email->message('Testing the email class.'); 
		 
         //Send mail
          
        /* if($this->email->send()) 
         $this->session->set_flashdata("email_sent","Email sent successfully."); 
         else 
         $this->session->set_flashdata("email_sent","Error in sending Email.");
         */
        /*
         if ($this->email->send()) {
            echo 'Your Email has successfully been sent.';
        } else {
            show_error($this->email->print_debugger());
        }
     }
     */

}
//---------------------------------------------------------------------------
else if ($Status=="Delayed")
{
// E-MAIL code comes here

}
else  if ($Status=="Delivered")

{   $this->load->model('Repairs_Model');
	$CustomerID=$this->Repairs_Model->getCustomerIDtoSaveWhenBalanceIsPaid($RepairID);
	$Balance=$this->Repairs_Model->getBalancetoSaveWhenBalanceIsPaid($RepairID);
     //...........................................

     $varName =$this->session->userdata('Email');
	$password =$this->session->userdata('Password');
	$this->load->model('Repairs_Model');
	$UserID=$this->Repairs_Model->getUserIDTosaveinshoprepairpayments($varName,$password);
     //...........................................
	$this->Repairs_Model->saverecordsToShopRepairPaymentsAfterDelivery($RepairID,$FaultID,$Balance,$CustomerID,$date,$UserID);
	$this->login1_model->update_repairs($RepairID,$RD,$Status);
}
//---------------------------------------------------------------------------
//------------------------------------------------------------------------
echo "The record was updated";
//redirect('login1_Controller/TechnicianViewRepairs');
}
}
}
//--------------------------------------
//code below allows each Technician to delete records: Not allowed!
//echo "<td><a href='deletedata?RepairID=".$row->RepairID."'>Delete</a></td>"; In display_repairs_Technician_view
public function deletedata(){
     $RepairID=$this->input->get('RepairID');
     $this->load->model('Repairs_Model');
     $this->Repairs_Model->delete_users($RepairID);
     echo "Record was deleted";
 
}
//--------------------------------------------------------
//*********************************************************************************** */
// code below is to allow a customer to view the status of Repair Items Handed-Over to the shop
public function ViewHandedOverJobStatusToCustomer()
{
     $varName =$this->session->userdata('Email');
     $this->load->model('login1_model');
    
     $result4['data4']=$this->login1_model->getViewHandedOverJobStatusToCustomer($varName);
     
     $this->load->view('display_status_accepted_repairs_C',$result4);
}



//----------------------------------------------------------------------------------------
//code below is to allow a customer to view the status of HomeVisit Requests
public function ViewHomeVisitRequestScheduleStatus()
{
     $varName =$this->session->userdata('Email');
     $this->load->model('login1_model');
     $result5['data3']=$this->login1_model->viewHomeVisitRequestScheduleStatus($varName);
	$this->load->view('display_HomeVisit_ScheduleStatus_C',$result5);
    
}
//code below is to let the TECHNICIAN view his/her HomeVisits
public function ViewHomeVisitsScheduledForTechnician()
{
$varName =$this->session->userdata('Email');
     $this->load->model('login1_model');
     $result6['data5']=$this->login1_model->viewHomeVisitRepairsScheduledToTechnician($varName);
	$this->load->view('display_HomeVisitScheduled_T',$result6);
}
// if needed to let Technician update status to "completed", copy updateScheduledHomeVisitSchedules() in Repairs_Controller and do the modifications so that status is only updatable
 //-----------------------------------------------------------
 


 //************************************************************************************ */
 //*********************************************************************************** */
//code below is for SUPPLIER to see requests
public function ViewRequestsForItemsToSupplier()
{
     $varName =$this->session->userdata('Email');
     $this->load->model('login1_model');
     $result7['data6']=$this->login1_model->viewRequestsForItemsToSupplier($varName);
	$this->load->view('display_SupplyRequests_S',$result7);

}
public function ConfirmRequests()

{ 
    $RequestID=$this->input->get('RequestID');
    $this->load->model('Supplies_Model');
    $result2['data2']=$this->Supplies_Model->displayItemsRequestedToSupplierPAGE($RequestID);
    $this->load->view('confirm_supplies',$result2);

    if($this->input->post('save')){
    
     $SupplierID=$this->Supplies_Model->getSupplierIDToSaveInPurchasePaymentsTable($RequestID);
     $DateOfSupply=$this->input->post('DateOfSupply');
     $QuantityAvailable=$this->input->post('QuantityAvailable');
     $UnitPrice=$this->input->post('ProductPrice');
     $RequestStatus=$this->input->post('OrderStatus');
     $date=date('Y-m-d');
     $TotalCost=$QuantityAvailable*$UnitPrice;
     if($RequestStatus!="Rejected")
 {
    if(($DateOfSupply=="") || ($QuantityAvailable=="")||($UnitPrice==""))
    {
     echo '<span style="color:red;"> Please fill all fields if you are not rejecting the order.</span>';
    }
    else if($DateOfSupply<$date)
    {
     echo '<span style="color:red;">Date of Supply selected should be in the future.</span>';
    }


    

    else {
    $this->load->model('Supplies_Model');
    $ModelNo=$this->Supplies_Model->getModelNoFromSuppliesrequestedTable($RequestID);
    
    $this->Supplies_Model->updateConfirmingOfOrders($RequestID,$DateOfSupply,$QuantityAvailable,$UnitPrice,$RequestStatus);
    $this->Supplies_Model->updateUnitPrice($ModelNo,$UnitPrice);
   
    $this->Supplies_Model->setItemStateToRequested($ModelNo,$RequestStatus);
    // code below saves the confirmed order in the purchasepayments table
    $this->Supplies_Model->saveinPurchasePayments($RequestID,$SupplierID,$TotalCost,$date);
    echo '<span style="color:blue;">Request was confirmed successfully.</span>';
    }
}
else
{
     $this->load->model('Supplies_Model');
     $ModelNo=$this->Supplies_Model->getModelNoFromSuppliesrequestedTable($RequestID);
     
     $this->Supplies_Model->updateConfirmingOfOrders($RequestID,$DateOfSupply,$QuantityAvailable,$UnitPrice,$RequestStatus);
     $this->Supplies_Model->updateUnitPrice($ModelNo,$UnitPrice);
    
     $this->Supplies_Model->setItemStateToRequested($ModelNo,$RequestStatus);
    
     echo '<span style="color:blue;">Request was confirmed successfully.</span>';
}

}

}
//// the code below lets the SUPPLIER update his/her details through the profile page
public function UpdateSupplierDetails_C(){
     $varName =$this->session->userdata('Email');
     $password =$this->session->userdata('Password');
     $this->load->model('login1_Model');
     //$result['data']=$this->login1_Model->display_names($varName,$password);
     $result3['data7']=$this->login1_Model->displaySupplierDetails_C($varName,$password);
     
     $this->load->view('update_supplier_S',$result3);
    // $this->form_validation->set_rules('Address','Address','required');
    // $this->form_validation->set_rules('ContactNo','ContactNo','required|min_length[10]|max_length[10]');
   
     //if($this->form_validation->run()==TRUE){
     if($this->input->post('update')){
         
          
$SupplierID=$this->input->get('SupplierID');
$FN=$this->input->post("FirstName");
    $LN=$this->input->post('LastName');
    $SN=$this->input->post('SupplierName');
    $AD=$this->input->post('Address');
    $LL=$this->input->post('LandLine');
    $MN=$this->input->post('MobileNo');
    $EM=$this->input->post('Email');
          
         // $this->login1_Model->update_customers_users($CustomerID,$FN,$LN,$EM,$varName);
          $this->login1_Model-> update_suppliers($SupplierID,$FN,$LN,$SN,$AD,$LL,$MN,$EM,$varName);
 //}
          redirect("login1_controller/UpdateSuccessfulMessage");   
                     
}
}




 
 }