<?php  
 defined('BASEPATH') OR exit('No direct script access allowed');
class Supplies_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Supplies_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->helper('email');

}
public function displayItemsAtReorderLevelToManager(){

    
    $result['data']=$this->Supplies_Model->displayItemsAtReorderLevel();
   
	$this->load->view('display_ReorderLevelItems_M',$result);
    
}

public function sendRequests()
{
    $ID=$this->input->get('ID');
   
   $SupplierID=$this->Supplies_Model->getSupplierIDToSaveInSuppliesrequestedTable($ID);
   
   $result1['data1']=$this->Supplies_Model->displayItemsAtReorderLevelByModuleNoToPage($ID);
   $this->load->view('request_supplies',$result1);
  
    if($this->input->post('save')){
    

    $ID=$this->input->get('ID');
    $SupplierID=$this->Supplies_Model->getSupplierIDToSaveInSuppliesrequestedTable($ID);
    $ModelNo=$this->Supplies_Model->getModelNoToSaveInSuppliesrequestedTable($ID);
    $DateRequired=$this->input->post("DateRequired");
    $DateOfSupply="";
    $QuantityNeeded=$this->input->post('QuantityNeeded');
    $QuantityAvailable="";
    $UnitPrice="";
    $RequestStatus="Requested";
    $date=date('Y-m-d');

    if (($DateRequired=="") ||($QuantityNeeded==""))
    {
        echo '<span style="color:red;"> Please fill all fields.</span>';

    }
    else if($DateRequired<$date)
    {
        echo '<span style="color:red;"> The date the order is required should be in the future.</span>';
    }
     
     else { 
   
    $this->Supplies_Model->saverequests($ModelNo,$SupplierID,$DateRequired,$DateOfSupply,$QuantityNeeded,$QuantityAvailable,$UnitPrice,$RequestStatus);
        
    //code below updates item table RequestStatus
    $ID=$this->input->get('ID');
    $RequestStatus="Requested";
    $this->Supplies_Model->setItemStateToRequested($ID,$RequestStatus);
    echo '<span style="color:blue;">Request was saved successfully.</span>';
   
     }
    }
}
//the confirming of requests for supplies is in login1_Controller
public function ViewConfirmedSupplyOrders()
{ 
     $this->load->model('Supplies_Model');
     $result['data1']=$this->Supplies_Model->displayItemsAtReorderLevelConfirmed();
     $this->load->view('display_ReorderLevelConfirmed_M',$result); 
}
//--------------------------------------------------------------------------------------------
//***********************************************************************************8 */
//invoice generted should be here  when row is clicked in confirmed order page
public function sendInvoice()

{ //E_MAIL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    $RequestID=$this->input->get('RequestID');
    $result3['data3']=$this->Supplies_Model->getDataToInvoiceForConfirmedSupplies($RequestID);
    $result3['data4']=$this->Supplies_Model->getTotalCostToInvoiceForConfirmedSupplies($RequestID);
    $this->load->view('display_Invoice_Confirmed_Supplies',$result3);
    //code below is to update the Products Table Quantity
    $QuantityAvailable=$this->Supplies_Model->getQuantityAvailableFROMSuppliesrequestedTable($RequestID);
    $ModelNo=$this->Supplies_Model->getModelNoSuppliesrequestedTable($RequestID);
    $this->Supplies_Model->updateQuantity($QuantityAvailable,$ModelNo);
    $this->Supplies_Model->updateInvoiceSentStatus($RequestID);
    $SupplierID=$this->Supplies_Model->getSupplierIDfromSuppliesOrderedtable($RequestID);
    $this->Supplies_Model->updateRequestStatusinItemstable($ModelNo,$SupplierID);

    
}

}