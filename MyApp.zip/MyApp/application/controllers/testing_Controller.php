<?php  
 defined('BASEPATH') OR exit('No direct script access allowed');
class testing_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Test_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->helper('email');

}

public function slider()
{
    $this->load->view('slider');
    if($this->input->post('Search')){
        $min=$this->input->post("minimum_range");
        $max=$this->input->post("maximum_range");
   // $min=$_POST['min'];
   // $max=$_POST['max'];

    //$mins = ( int ) str_replace( ',', '', $min );
    //$maxs = ( int ) str_replace( ',', '', $max ); 
  $data['result']=$this->Test_Model->selectbyrange($min,$max);
  $this->load->view('slider2', $data);
    }
}


public function test()
{
  $this->load->view('test');
}

}
