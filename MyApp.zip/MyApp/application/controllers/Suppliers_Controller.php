<?php
class Suppliers_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Suppliers_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->helper('email');

}
public function savedata(){

$this->form_validation->set_rules('FirstName','FirstName','required');
$this->form_validation->set_rules('LastName','LastName','required');
$this->form_validation->set_rules('SupplierName','SupplierName','required');
$this->form_validation->set_rules('Address','Address','required');
$this->form_validation->set_rules(
	'LandLine', 'LandLine',
	'required|min_length[10]|max_length[10]',
    
	array(
			'required'      => 'LandLine is required.'
            
			
	)
	
);
$this->form_validation->set_rules(
	'MobileNo', 'MobileNo',
	'required|min_length[10]|max_length[10]',
    
	array(
			'required'      => 'MobileNo is required.'
            
			
	)
	
);

$this->form_validation->set_rules(
	'Username', 'Username',
	'required|is_unique[Users.Email]|valid_email',
    
	array(
			'required'      => 'Email field is required.',
			'is_unique'     => 'There is another account with this email.Please use another e-mail address to register.'
	)
);
$this->form_validation->set_rules('Password','Password','required|min_length[8]');
$this->form_validation->set_rules('ConfirmPassword','ConfirmPassword','required|min_length[8]|matches[Password]');

if($this->form_validation->run()==FALSE){
$this->load->view('SupplierRegistration');
if($this->input->post('save')){
$FN=$this->input->post("FirstName");
$LN=$this->input->post('LastName');
$SN=$this->input->post('SupplierName');
$AD=$this->input->post('Address');
$LL=$this->input->post('LandLine');
$MN=$this->input->post('MobileNo');


//$password = sha1($this->input->post('password'));
$UN=$this->input->post('Username');
$PW=sha1($this->input->post('Password'));
$CPW=sha1($this->input->post('ConfirmPassword'));
$CG="Supplier";



}}
else
{
    $FN=$this->input->post("FirstName");
    $LN=$this->input->post('LastName');
    $SN=$this->input->post('SupplierName');
    $AD=$this->input->post('Address');
    $LL=$this->input->post('LandLine');
    $MN=$this->input->post('MobileNo');
    
    $UN=$this->input->post('Username');
    $PW=sha1($this->input->post('Password'));
    $CPW=sha1($this->input->post('ConfirmPassword'));
    $CG="Supplier";
    $Status="Requested";
   
    $this->Suppliers_Model->saverecords($FN,$LN,$SN,$AD,$LL,$MN,$UN);
    $this->Suppliers_Model->saveusers($UN,$FN,$LN,$PW,$CG,$Status);
    echo "Records saved successfully";
    redirect('login1_controller/login_validation');
    
   
}
}
//-------------------------------------------------------------------------------------------------------
public function displaySuppliers(){
	$result1['data']=$this->Suppliers_Model->display_suppliers();
	$this->load->view('display_suppliers',$result1);	
}
//-----------------------------------------------------------------------------------
public function deletedata(){
    $Email=$this->input->get('Email');
    
    $this->Suppliers_Model->delete_suppliers($Email);
    echo "Records deleted";
    }
///----------------------------------------------------------------------------------
public function updatedata(){
	$SupplierID=$this->input->get('SupplierID');
	$result2['data2']=$this->Suppliers_Model->displayitemsbyid($SupplierID);
	$this->load->view('update_suppliers',$result2);
    

if($this->input->post('update')){
$SupplierID=$this->input->get('SupplierID');
$FN=$this->input->post("FirstName");
    $LN=$this->input->post('LastName');
    $SN=$this->input->post('SupplierName');
    $AD=$this->input->post('Address');
    $LL=$this->input->post('LandLine');
    $MN=$this->input->post('MobileNo');
    $EM=$this->input->post('Email');
    $Status=$this->input->post('Status');

$this->Suppliers_Model->update_supplier_users($SupplierID,$FN,$LN,$EM,$Status);
$this->Suppliers_Model->update_suppliers($SupplierID,$FN,$LN,$SN,$AD,$LL,$MN,$EM);

echo "The record was updated";
redirect("Suppliers_Controller/displaySuppliers");


}
}
//************************************************************************************************* */

public function savePendingRequests(){
	
    	


$this->form_validation->set_rules('Id','Id','required');   
$this->form_validation->set_rules('ItemName','ItemName','required');
$this->form_validation->set_rules('Brand','Brand','required');
$this->form_validation->set_rules('Price','Price','required');
$this->form_validation->set_rules('Quantity','Quantity','required');
$this->form_validation->set_rules('Warranty','Warranty','required');


if($this->form_validation->run()==FALSE){
$this->load->view('Items_PendingSuppliers');




if($this->input->post('save')){
$ModelNo=$this->input->post("Id");
$ItemName=$this->input->post('ItemName');
$Brand=$this->input->post('Brand');
$Price=$this->input->post('Price');
$Quantity=$this->input->post('Quantity');
$this->load->model("login1_model");
    $varName =$this->session->userdata('Email');
    $this->load->model("Suppliers_Model");
    $SupplierID=$this->Suppliers_Model->getSupplierID($varName);

$Warranty=$this->input->post('Warranty');
$Image="";
$RequestStatus="Pending";


}}
else
{
	
$ModelNo=$this->input->post("Id");
$ItemName=$this->input->post('ItemName');
$Brand=$this->input->post('Brand');
$Price=$this->input->post('Price');
$Quantity=$this->input->post('Quantity');

$varName =$this->session->userdata('Email');
    $this->load->model("Suppliers_Model");
    $SupplierID=$this->Suppliers_Model->getSupplierID($varName);
$Warranty=$this->input->post('Warranty');
$Image="";
$RequestStatus="Pending";
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
$this->load->model("Items_Model");
$ID=$this->Items_Model->CheckIfRowwithModelNoANDSupplierIDEXISTS($ModelNo,$SupplierID);
if($ID!="")
{
    echo '<span style="color:red;">You have already requested to/is registered to supply ModelNo:"'.$ModelNo.'".</span>';
   
}
else
{

$this->load->model("Suppliers_Model");
$this->Suppliers_Model->savePendingItems($ModelNo,$Price,$SupplierID,$RequestStatus);
//$this->Suppliers_Model->savePendingItems($ModelNo,$ItemName,$Brand,$Price,$Quantity,$SupplierID,$Warranty,$Image,$RequestStatus);
echo "Records saved successfully";
$Id=$this->Suppliers_Model->CheckIfRowwithIdEXISTSinProductsTable($ModelNo);
if($Id=="")
{
    $ProductName=$this->input->post('ItemName');
    $ProductBrand=$this->input->post('Brand');
    $ProductPrice=$this->input->post('Price');
    $Status="Pending";
    $this->load->model("Product_Item_Model");
    $this->Product_Item_Model->saverecords($ModelNo,$ProductName,$ProductBrand,$ProductPrice,$Quantity,$Warranty,$Image,$Status);
    //echo "Records saved successfully";
}

}
}

}


//********************************************************************************** */
//code below displays pending items to Manager
public function displayPendingItemsToManager(){
	$result['data']=$this->Suppliers_Model->display_Pending_items();
	$this->load->view('display_Pending_items',$result);	
}
public function UpdatePendingRecordStatusInItemsTable()

{
    $ID=$this->input->get('ID');
    $this->Suppliers_Model->updateRequestStatusToRegisteredINItemsTable($ID);
    $ModelNo=$this->Suppliers_Model->getModelNo($ID);
    $this->Suppliers_Model->updateRequestStatusToRegisteredINProductsTable($ModelNo);
    echo "Records updated successfully"; 
}

public function DeletePendingInItemsTable()
{
    $ID=$this->input->get('ID');
    $this->Suppliers_Model-> delete_pendingItems($ID);
    echo "Record deleted successfully";
}

}

?>