<?php
class Repairs_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Repairs_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');

}

public function displaydata(){
$result['data']=$this->Repairs_Model->display_items();
$this->load->view('display_repairs',$result);	
}
public function deletedata(){
$RepairID=$this->input->get('RepairID');
$this->Repairs_Model->delete_users($RepairID);
echo "Record was deleted";
}
public function updatedata(){
	$RepairID=$this->input->get('RepairID');
	$result['data']=$this->Repairs_Model->displayitemsbyid($RepairID);
	
	$FaultID=$this->Repairs_Model->getFaultIDToUpdatePage($RepairID);
	$result['data1']=$this->Repairs_Model->getFaultNameToUpdatePage($FaultID);
	$result['data2']=$this->Repairs_Model->getEmailToUpdatePage($RepairID);
	$result['groups']=$this->Repairs_Model->listTechnicians();
	
	$this->load->view('update_repairs_shop',$result);

if($this->input->post('update')){
$RepairID=$this->input->get('RepairID');
//$CustomerID=$this->input->post('CustomerID');

$ID=$this->input->post('Description');
//$Fault=$this->input->post('Fault');
$CN=$this->input->post('ContactNo');
$AD=$this->input->post('AcceptDate');
$RD=$this->input->post('ReturnDate');
$cost=$this->input->post('TotalCost');
$paid=$this->input->post('AdvancePaid');
$Balance=$this->input->post('Balance');
$EmpID=$this->input->post('Technician');
$Status=$this->input->post('Status');
$date=date('Y-m-d');

if($RD<$date){
	echo '<span style="color:blue;">Return date is in the past. Unable to Update Job.</span>';
	
	}
//------------------------------------------------------------------
else {
//---------------------------------------------------------------------------
$this->Repairs_Model->update_repairs($RepairID,$RD,$EmpID,$Status);
if ($Status=="Ready")
{
//*********************************************


//--------------------------------------------

//Load email library 
/*
$this->load->library('email'); 
		$from_email ="mymitproject2021@gmail.com"; 
         $to_email ="dinadee8877@gmail.com";  
         $this->email->from($from_email, 'Dini'); 
         $this->email->to($to_email);
         $this->email->subject('Email Test'); 
         $this->email->message('Testing the email class.'); 
		 
         //Send mail 
         if($this->email->send()) 
         $this->session->set_flashdata("email_sent","Email sent successfully."); 
         else 
         $this->session->set_flashdata("email_sent","Error in sending Email."); 
        
//********************************************** */

 // E-Mail code as well as in login1_controller
}
//---------------------------------------------------------------------------
else if ($Status=="Delayed")
{
	// E-Mail code as well as in login1_controller
}
else  if ($Status=="Delivered")

{   
	$CustomerID=$this->Repairs_Model->getCustomerIDtoSaveWhenBalanceIsPaid($RepairID);
	$Balance=$this->Repairs_Model->getBalancetoSaveWhenBalanceIsPaid($RepairID);
	//-----------------------------------------------------------------------------
	//code below is to save the name of the DEO who accepts the item
	$varName =$this->session->userdata('Email');
	$password =$this->session->userdata('Password');
	$this->load->model('Repairs_Model');
	$UserID=$this->Repairs_Model->getUserIDTosaveinshoprepairpayments($varName,$password);
				//-----------------------------------------------------------------------------------
	$this->Repairs_Model->saverecordsToShopRepairPaymentsAfterDelivery($RepairID,$FaultID,$Balance,$CustomerID,$date,$UserID);
	redirect('Repairs_Controller/generateInvoiceForRepairsAcceptedAtShopOnReturn');
}
//---------------------------------------------------------------------------

//$this->Repairs_Model->update_repairs($RepairID,$RD,$EmpID,$Status);
echo "The record was updated";
//redirect('Repairs_Controller/displaydata');
}//
}
}

 
 //************************************************************************************ */
 // Code below is to display faults to accept repair

 public function displayfaults(){
	$result1['data']=$this->Repairs_Model->display_faults_shop();
	$this->load->view('display_faults_shop_view',$result1);	
}



public function AddJob(){
	$data['groups']=$this->Repairs_Model->listTechnicians();
	$data['ContactNo']=$this->Repairs_Model->listContactNo();
	
	$this->load->helper(array('form', 'url'));
	$this->load->library('form_validation');
	$this->form_validation->set_rules('Description','Description','required');
	$this->form_validation->set_rules('ContactNo','ContactNo','required');
	$this->form_validation->set_rules('AcceptDate','AcceptDate','required');
	$this->form_validation->set_rules('ReturnDate','ReturnDate','required');
	$this->form_validation->set_rules('TotalCost','TotalCost','required');
	$this->form_validation->set_rules('AdvancePaid','AdvancePaid','required');
	$this->form_validation->set_rules('EmpID','EmpID','required');
	$this->form_validation->set_rules('select','select','required');

	
	$FaultID=$this->input->get('FaultID');
	$TotalCost=$this->Repairs_Model->getTotalCost($FaultID);
	//$TotalCost=$this->input->get('TotalCost');
	$data['data1']=$this->Repairs_Model->displayfaultsbyid($FaultID);
	//$this->load->view('display_fault_in_accept_repairs',$data1);
	$this->load->view('repairs_view',$data);
//if($this->form_validation->run()==FALSE){
/*
$this->load->view('repairs_view',$data);
if($this->input->post('save')){
$TotalCost=$this->Repairs_Model->getTotalCost($FaultID);
$ID=$this->input->post('Description');
$CN=$this->input->post('ContactNo');
$AD=$this->input->post('AcceptDate');
$RD=$this->input->post('ReturnDate');

$paid=$this->input->post('AdvancePaid');
//$Balance= $TotalCost-$paid;
$Technician=$this->input->post('Technician');
$Status=$this->input->post('select');
}
}
else
{   */
	
	if($this->input->post('save')){
	$FaultID=$this->input->get('FaultID');
	
    $TotalCost=$this->Repairs_Model->getTotalCost($FaultID);
	$ID=$this->input->post('Description');
	
	$CN=$this->input->post('ContactNo');
	$CustomerID=$this->Repairs_Model->getCustomerID($CN);
	
	$AD=$this->input->post('AcceptDate');
	$RD=$this->input->post('ReturnDate');
	$Warranty=$this->input->post('Warranty');

	$paid=$this->input->post('AdvancePaid');
	$Balance= 0;
	$Technician=$this->input->post('EmpID');
	$Status=$this->input->post('select');
	$date=date('Y-m-d');
	
	if (($ID =="")||($CN=="")||($AD=="")||($RD=="")||($paid=="")||($Technician=="")||($Status=="")||($Warranty==""))
	{
		echo '<span style="color:red;"> Unable to Add Job.Please fill all fields.</span>';
	}

	
	//------------------------------------------------------------------------------
	/*
	if($ID=="") 
	{
		echo '<span style="color:red;">Description is required. Unable to Add Job.</span>';
	}

	else if ($CN=="")
	{
		echo '<span style="color:red;">ContactNo is required. Unable to Add Job.</span>';
	}

	else if ($AD=="")
	{
		echo '<span style="color:red;">Accept Date is required. Unable to Add Job.</span>';
	}
	else if ($RD=="")
	{
		echo '<span style="color:red;">Return Date is required. Unable to Add Job.</span>';
	}
	else if ($paid=="")
	{
		echo '<span style="color:red;">Advance Paid is required. Unable to Add Job.</span>';
	}
	else if ($Technician=="")
	{
		echo '<span style="color:red;">Selection of a Technician is required. Unable to Add Job.</span>';
	}
	else if ($Status=="")
	{
		echo '<span style="color:red;">Selection of a Status is required. Unable to Add Job.</span>';
	}
	*/
	//------------------------------------------------------------------------------------------
	else  if ($paid>$TotalCost)
	{   echo '<span style="color:blue;">Advance paid is greater than Total Cost. Unable to Add Repair Job.</span>';
		
	}	
		else if($RD<$date){
		echo '<span style="color:blue;">The Return Date should be in the future.Unable to Add Job.</span>';
		
		}
		else if($AD!=$date){
			echo '<span style="color:blue;">Accepted date should be today. Unable to Add Job.</span>';
			
			}
			
		else{

			//--------------------------------------------
			if ($Warranty=="Yes")
			{
				$TotalCost=0;
				$Balance=0;
				$paid=0;
				
				$this->Repairs_Model->saverecords($CustomerID,$FaultID,$ID,$CN,$AD,$RD,$Warranty,$TotalCost,$paid,$Balance,$Technician,$Status);
				
				$RepairID=$this->Repairs_Model->getLastSavedRepairID();
				//-----------------------------------------------------------------------------
				//code below is to save the name of the DEO who accepts the item
				$varName =$this->session->userdata('Email');
				$password =$this->session->userdata('Password');
				$this->load->model('Repairs_Model');
				$UserID=$this->Repairs_Model->getUserIDTosaveinshoprepairpayments($varName ,$password);
				//-----------------------------------------------------------------------------------
		        $this->Repairs_Model->saverecordsToShopRepairPayments($RepairID,$FaultID,$paid,$CustomerID,$date,$UserID);
				echo "Records saved successfully";
				//redirect('Repairs_Controller/displaydata');
				redirect('Repairs_Controller/generateInvoiceForRepairsAcceptedAtShopOnAccepting');
			}
			else
			{
			//--------------------------------------------
	    		$this->Repairs_Model->saverecords($CustomerID,$FaultID,$ID,$CN,$AD,$RD,$Warranty,$TotalCost,$paid,$Balance,$Technician,$Status);
		
       			 $RepairID=$this->Repairs_Model->getLastSavedRepairID();
				//-----------------------------------------------------------------------------
				//code below is to save the name of the DEO who accepts the item
				$varName =$this->session->userdata('Email');
				$password =$this->session->userdata('Password');
				$this->load->model('Repairs_Model');
				$UserID=$this->Repairs_Model->getUserIDTosaveinshoprepairpayments($varName,$password);
				//-----------------------------------------------------------------------------------

		$this->Repairs_Model->saverecordsToShopRepairPayments($RepairID,$FaultID,$paid,$CustomerID,$date,$UserID);
		echo "Records saved successfully";
		redirect('Repairs_Controller/generateInvoiceForRepairsAcceptedAtShopOnAccepting');
		//redirect('Repairs_Controller/displaydata');
			}
	}
	}


}

//********************************************************************************************* */
//********************************************************************************************* */
//Section below deals with SCHEDULING HOME-VISIT Repairs
public function displayfaultsToHomeVisits(){
	$result1['data']=$this->Repairs_Model->display_faults_shop();
	$this->load->view('display_faults_for_homevisit_C',$result1);	
}

public function ScheduleHomeVisitRepairs()

{   //$this->form_validation->set_rules('CustomerID','CustomerID','required');
	$this->form_validation->set_rules('Warranty','Warranty','required');
	$this->form_validation->set_rules('ScheduledDate','ScheduledDate','required');
	
	


	 $FaultID=$this->input->get('FaultID');
	$data['data1']=$this->Repairs_Model->displayfaultsbyid($FaultID);
	$this->load->view('repair_schedule_homevisit_view',$data);

		if($this->input->post('save')){
		
			$FaultID=$this->input->get('FaultID');
			//$CustomerID=$this->input->post("CustomerID");
			$varName =$this->session->userdata('Email');
			$CustomerID=$this->Repairs_Model->getCustomerIDtoHomeVisitRepairs($varName);
			$Warranty=$this->input->post('Warranty');
			$DateOfRepair=$this->input->post('ScheduledDate');
			
			$EmpID=0;
			$StartTime="";
			$EndTime="";
			$ScheduleStatus="Requested";
			$date=date('Y-m-d');
			
			//if (($CustomerID =="")||($DateOfRepair=="")||($Warranty==""))
			if (($DateOfRepair=="")||($Warranty==""))
			{
				echo '<span style="color:red;"> Unable to Schedule Job.Please fill all fields.</span>';
			}
			else if($DateOfRepair<$date)
			{
				echo '<span style="color:blue;"> Unable to Schedule Job. Selected Date for Repair is in the past.</span>';
			}
			
			else{
		$this->Repairs_Model->saveHomeVisitRepair($FaultID,$CustomerID,$Warranty,$DateOfRepair,$EmpID,$StartTime,$EndTime,$ScheduleStatus);
		echo '<span style="color:blue;"> Your request has been saved successfully.</span>';
		
			}
}

}
//-----------------------------------------------------------------------------------------------
// code below displays requested schedules when DEO logs in
public function viewHomeVisitRequests()
{
	$this->load->model("Repairs_Model");
	$result2['data3']=$this->Repairs_Model->viewHomeVisitRequeststoSchedule();
	$this->load->view('display_job_requests_D',$result2);

}
// when the DEO clicks a certain record on the above page, scheduled and un-scheduled repairs FOR that DATE are listed from coding below
public function displaySchedules()
{
	$DateOfRepair=$this->input->get('DateOfRepair');
	
	$result3['data4']=$this->Repairs_Model->getScheduledHomeVisitsByDate($DateOfRepair);
	$result3['data5']=$this->Repairs_Model->getUnscheduledHomeVisitsByDate($DateOfRepair);
	$this->load->view('display_homevisit_schedules_by_date',$result3);
}
//-----------------------------------------------------------------------------------------------
public function updateScheduledHomeVisitSchedules()
{
	
	$VisitJobID=$this->input->get('VisitJobID');
	$result4['data6']=$this->Repairs_Model->getDataToUpdateScheduledHomeVisitsPage($VisitJobID);
	$this->load->model("Repairs_Model");
	$result4['groups']=$this->Repairs_Model->listTechnicians();
	$this->load->view('update_homevisit_scheduled_DEO',$result4);

	if($this->input->post('update')){
		$VisitJobID=$this->input->get('VisitJobID');
		
		/*
		$DateOfRepair=$this->input->post('DateOfRepair');
		$StartTime=$this->input->post('StartTime');
		$EndTime=$this->input->post('EndTime');
		$EmpID=$this->input->post('Technician');*/
		$ScheduleStatus=$this->input->post('ScheduleStatus');
		
		//-------------------------------------------------------------------
		//if(($DateOfRepair=="") ||($StartTime=="")||($EndTime=="") ||($ScheduleStatus==""))
		if($ScheduleStatus=="")
		{
		echo '<span style="color:red;">Please select schedule status.</span>';
		
		}
		
		else {
		$this->Repairs_Model->updateScheduledHomeVisit($VisitJobID,$DateOfRepair,$StartTime,$EndTime,$EmpID,$ScheduleStatus);
		if ($ScheduleStatus=="Cancelled") 
		{
		 // E-Mail code
		 //delete record from payment table
		 
		}
		//---------------------------------------------------------------------------
		else if ($ScheduleStatus=="Completed")
		{
			$date=date('Y-m-d');
			$this->Repairs_Model->updateDatePaymentWasReceivedHomeVisitRepair($date,$VisitJobID);
		}
		
		//---------------------------------------------------------------------------
		//$this->Repairs_Model->updateScheduledHomeVisit($VisitJobID,$DateOfRepair,$StartTime,$EndTime,$EmpID,$ScheduleStatus);
		
		echo "The record was updated";
		redirect('Repairs_Controller/viewHomeVisitRequests');
		}//
		}
	
}

//----------------------------------------------------------------------------------------------

public function updateUnScheduledHomeVisitSchedules()
{
	$result5['groups']=$this->Repairs_Model->listTechnicians();
	$VisitJobID=$this->input->get('VisitJobID');
	$DateOfRepair=$this->Repairs_Model->getDateOfRepairToUseInTechEndTimeDisplay($VisitJobID);
	$FaultID=$this->Repairs_Model->getFaultIDToUseInTechEndTimeDisplay($VisitJobID);
	$TimeToRepair=$this->Repairs_Model->getTimeToRepairFROMFaultIDToUseInTechEndTimeDisplay($FaultID);
	$this->load->view('Search_TechnicianToSchedule',$result5);
	if($this->input->post('Search')){
		$EmpID=$this->input->post('EmpID');
		if ($EmpID=="")

		{ echo '<p style="color: red; text-align:center;">
			Please select a Technician
			</p>';
	
		}
		 else{
			$result5['data8']=$this->Repairs_Model->getLastEndTimeFOrAnEmployeeWithDateSelected($EmpID,$DateOfRepair); 
			$result5['data7']=$this->Repairs_Model->getDataToUpdateUnScheduledHomeVisitsPage($VisitJobID);

			$this->load->model("Repairs_Model");
			$result5['groups']=$this->Repairs_Model->listTechnicians();
			
			
			$this->load->view('update_homevisit_UNscheduled_DEO',$result5); 
			
		
		 }
		}
	
	
	// cannot use update page for scheduled home visits because the technician is selected in getDataToUpdateUnScheduledHomeVisitsPage

	if($this->input->post('update')){
		//-------------------------------------
		$EmpID=$this->input->post('EmpID');
		$result5['data8']=$this->Repairs_Model->getLastEndTimeFOrAnEmployeeWithDateSelected($EmpID,$DateOfRepair); 
			$result5['data7']=$this->Repairs_Model->getDataToUpdateUnScheduledHomeVisitsPage($VisitJobID);

			$this->load->model("Repairs_Model");
			$result5['groups']=$this->Repairs_Model->listTechnicians();
			
		$this->load->view('update_homevisit_UNscheduled_DEO',$result5); 

		
		
		$VisitJobID=$this->input->get('VisitJobID');
		
		//$StartTime=$this->input->post('StartTime');
		//-------------------------------------
		
		$EndTimeL=$this->Repairs_Model->getEndTimeToScheduleByaddingtwoHours($EmpID,$DateOfRepair);
		/*
		$StartTime=date('Y-m-d H:i',strtotime('+2 hours',strtotime($EndTimeL)));
		//$EndTime=date('Y-m-d H:i',strtotime($StartTime)+strtotime($TimeToRepair));
		$secs=strtotime($TimeToRepair)-strtotime("00:00:00");
		$EndTime= date("Y-m-d H:i:s",strtotime($StartTime)+$secs);
		
		//echo date('Y-m-d H:i',strtotime($StartTime)+strtotime($TimeToRepair));*/
		//-------------------------------------------------
		//$EndTime=$this->input->post('EndTime');
		$EmpID=$this->input->post('EmpID');
		$SStatus=$this->input->post('SStatus');

		//------------------------------------------------------------------
	
		//--------------------------------------------------------------------
		
		
		$FaultID=$this->Repairs_Model->getFaultIDtoSaveInHomeVisitPayments($VisitJobID);
		// code function in line 61 (Repairs_Model) was reused, to get the TotalCost to to save in visitrepairpayments
		$TotalCost=$this->Repairs_Model->getTotalCost($FaultID);
		$CustomerID=$this->Repairs_Model->getCustomerIDtoSaveInHomeVisitPayments($VisitJobID);
		$Warranty=$this->Repairs_Model->getWarranty($VisitJobID);
		$date="";
		$SStartime='09:00:00.000000';
		$SEndTime='18:00:00.000000';

		

		if(($EmpID=="")||($SStatus=="") AND ($SStatus!="Rejected"))
		{
			echo '<span style="color:red;"> Unable to Add Job. Please fill all fields</span>';
		}
		//-----------------------------------------------------------------------------
		
		//-------------------------------------------------------------------------------

		else {
	
		if(($EndTimeL=="")  && ($SStatus=="Scheduled") )
		{
			
	// E-MAIL CODE *************************************************
			$StartTime='09:00:00.000000';
			$secs=strtotime($TimeToRepair)-strtotime("00:00:00");
			$EndTime= date("Y-m-d H:i:s",strtotime($StartTime)+$secs);
		$this->Repairs_Model->updateUnScheduledHomeVisit($VisitJobID,$StartTime,$EndTime,$EmpID,$SStatus);
		//---------------------------------------------------------------
		if($Warranty=="Yes")
		{
			$TotalCost=0;
			$this->Repairs_Model->saverecordsToVisitRepairPayments($VisitJobID,$FaultID,$CustomerID,$EmpID,$TotalCost,$date);
			echo "The record was updated";
			redirect('Repairs_Controller/generateInvoiceForHomeVisitsONschedule');
		}
	   else {
		$this->Repairs_Model->saverecordsToVisitRepairPayments($VisitJobID,$FaultID,$CustomerID,$EmpID,$TotalCost,$date);
		echo "The record was updated";
		redirect('Repairs_Controller/generateInvoiceForHomeVisitsONschedule');
	   }
		//-----------------------------------------------------------------------------------
		//echo "The record was updated";
		//redirect('Repairs_Controller/viewHomeVisitRequests'); 
		
		}
		else if(($EndTimeL<'18:00:00.000000') && ($SStatus=="Scheduled") )
		{
		$StartTime=date('Y-m-d H:i',strtotime('+2 hours',strtotime($EndTimeL)));
		$secs=strtotime($TimeToRepair)-strtotime("00:00:00");
		$EndTime= date("Y-m-d H:i:s",strtotime($StartTime)+$secs);
		$this->Repairs_Model->updateUnScheduledHomeVisit($VisitJobID,$StartTime,$EndTime,$EmpID,$SStatus);
		//---------------------------------------------------------------
		if($Warranty=="Yes")
		{
			$TotalCost=0;
			$this->Repairs_Model->saverecordsToVisitRepairPayments($VisitJobID,$FaultID,$CustomerID,$EmpID,$TotalCost,$date);
		
			
			echo "The record was updated";
			redirect('Repairs_Controller/generateInvoiceForHomeVisitsONschedule');
		}
	   else if($Warranty=="No"){
		$this->Repairs_Model->saverecordsToVisitRepairPayments($VisitJobID,$FaultID,$CustomerID,$EmpID,$TotalCost,$date);
		
		
		echo "The record was updated";
		redirect('Repairs_Controller/generateInvoiceForHomeVisitsONschedule');
	   }
		//-----------------------------------------------------------------------------------
		//echo "The record was updated";
		

		}
		else if(($EndTimeL>'18:00:00.000000') && ($SStatus=="Scheduled") ){
			echo '<span style="color:red;">Time slots for the selected technician are full. </span>';
			
		}
		else if($SStatus=="Rejected")
		{
			// EMAIL code *************************************
			$StartTime='00:00:00.000000';
			$EndTime='00:00:00.000000';
			$EmpID=0;
			$this->Repairs_Model->updateUnScheduledHomeVisit($VisitJobID,$StartTime,$EndTime,$EmpID,$SStatus);
		}
		}
		
//*
	}
}
// code below is to display schedules with in a period
public function displaySchedulesWithinPeriod()
{
	$this->load->view('Search_Schedules_InPeriod');
	$StartDate=$this->input->post('StartDate');
		
		$EndDate=$this->input->post('EndDate');

	
	if($this->input->post('Search')){
		
		if (($StartDate=="") || ($EndDate==""))

		{ echo '<p style="color: red; text-align:center;">
			Two dates should be selected
			</p>';
	
		}

		else{

		$this->load->model("Repairs_Model");
		$result6['data9']=$this->Repairs_Model->viewAllHomeVisitsWithinPeriod($StartDate,$EndDate);
		$this->load->view('display_Period_jobRequests__D',$result6);

		}

}

}
//******************************************************************************************** */
// code below generates invoice ON Scheduling Home Visit Repars
public function generateInvoiceForHomeVisitsONschedule()

{
	$InvoiceNo=$this->Repairs_Model->getInvoiceNo();
	$result7['data10']=$this->Repairs_Model->getScheduleDetailstoInvoiceOnSchedule($InvoiceNo);
		
	$this->load->view('display_Invoice_HomeVisits_D',$result7);
}
//code below is to generate invoices AFTER HomeVisit Repairs have been scheduled FOR TECHNICIAN reference
public function viewScheduledRepairsTogetInvoice()
	{

		$result11['data11']=$this->Repairs_Model->viewallScheduledRepairstogenerateInvoiceAfterScheduled();
		$this->load->view('display_Invoice_Already_ScheduledHomevisits',$result11);
	}

public function viewInvoiceforALREADYscheduledHomeVisits()
{
	$InvoiceNo=$this->input->get('InvoiceNo');
	$result7['data10']=$this->Repairs_Model->getScheduleDetailstoInvoiceOnSchedule($InvoiceNo);
		
	$this->load->view('display_Invoice_HomeVisits_D',$result7);
}
//*********************************************************************************** */
//code below is to generate invoice when accepting repairs to the shop

public function generateInvoiceForRepairsAcceptedAtShopOnAccepting()
{
//code below is to the name of the DEO who accepts the item
		  
	$InvoiceNo=$this->Repairs_Model->getInvoiceNoForshoprepairs();
	$result12['data12']=$this->Repairs_Model->getdetailstoInvoiceOnShopRepairAcceptance($InvoiceNo);
		
	$this->load->view('display_Invoice_RepairAcceptance',$result12);
}
//code below is to generate invoice when accepted repairs are delivered

public function generateInvoiceForRepairsAcceptedAtShopOnReturn()
{
	$InvoiceNo=$this->Repairs_Model->getInvoiceNoForshoprepairs();
	$result13['data13']=$this->Repairs_Model->getdetailstoInvoiceOnShopRepairDelivered($InvoiceNo);
	$this->load->view('display_Invoice_RepairReturn',$result13);
}





}
	
?>
