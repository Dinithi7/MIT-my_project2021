<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller{
    
    function  __construct(){
        parent::__construct();
        $this->load->helper('url');
        
        // Load cart library
        $this->load->library('cart');
        
        // Load product model
        $this->load->model('product');
    }
    function index(){
        $data = array();
        
        // Fetch products from the database
        $data['products'] = $this->product->getRows();
        
        // Load the product list view
      //  $this->load->view('products/index', $data);

       
        $this->load->view('products', $data);
    }
    function addToCart($proID){
      
        // Fetch specific product by ID
        $product = $this->product->getRows($proID);
        
        
        // Add product to the cart
         
    
        $data = array(
            'id'    => $product['Id'],
            
           'qty'    => 1,
           //'qty'    => $_POST["Quantity"],
            'price'    => $product['ProductPrice'],
            'name'    => $product['ProductName'],
            'image' => $product['Image']
        );
    
        $this->cart->insert($data);
        
        
        // Redirect to the cart page
        redirect('Cart/');
      
       
    }
    
}