<?php
class Items_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Items_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->model('items_model');
$this->load->library('upload');

}

public function savedata(){
	$data['groups']=$this->items_model->getAllGroups();
	

// the code below checks if the ModelNo exists in the items table because it is the PK
$this->form_validation->set_rules('ModelNo','ModelNo','required');
$this->form_validation->set_rules('Price','Price','required');
$this->form_validation->set_rules('SupplierID','SupplierID','required');


if($this->form_validation->run()==FALSE){
//$this->load->view('Items_view');
$this->load->view('items_view',$data);
if($this->input->post('save')){
$ModelNo=$this->input->post("ModelNo");
$Price=$this->input->post('Price');
$SupplierID=$this->input->post('SupplierID');
$RequestStatus="Registered";

}}
else
{
	
$ModelNo=$this->input->post("ModelNo");
$Price=$this->input->post('Price');
$SupplierID=$this->input->post('SupplierID');
$RequestStatus="Registered";


//-------------------------------------------------------------------------------------------------
$ID=$this->Items_Model->CheckIfRowwithModelNoANDSupplierIDEXISTS($ModelNo,$SupplierID);

if($ID!="")
{
	echo '<span style="color:red;">The Supplier you chose has requested to or is already registered to supply ModelNo:"'.$ModelNo.'".</span>';
	
}
else 
{
$this->Items_Model->saverecords($ModelNo,$Price,$SupplierID,$RequestStatus);
echo "Records saved successfully";
}
//-----------------------------------------------------------------------------------------------------
}

}

public function displaydata(){
	$result['data']=$this->Items_Model->display_items();
	$this->load->view('display_items',$result);	
}
public function deletedata(){
$ID=$this->input->get('ID');

$this->Items_Model->delete_users($ID);
echo "Record was deleted";
}
public function updatedata(){


	$ID=$this->input->get('ID');

	$result['data']=$this->Items_Model->displayitemsbyid($ID);
// this code is to display supplier details on update form
	$data['groups']=$this->items_model->getAllGroups();
	// this code is to display the suppliers
	$new_array = array_merge($result,$data);
	$this->load->view('update_items',$new_array );
	
	

if($this->input->post('update')){
$ID=$this->input->get('ID');
$ModelNo=$this->input->post('ModelNo');

$ProductPrice=$this->input->post('ProductPrice');

$SupplierID=$this->input->post('SupplierID');


$this->Items_Model->update_items($ID,$ModelNo,$ProductPrice,$SupplierID);
echo "The records were updated";
redirect('items_controller/displaydata');
}
}
//******************************************************************************************
//----------------------------------------------------------------------------------------
public function view_image()
        {
               // $this->load->view('items_view', array('error' => ' ' ));
			   $this->load->helper('html');
				$this->load->model('items_model');
				
				$data1['items'] = $this->items_model->getimage();
				$this->load->view('gallery', $data1);
			
        }
//----------------------------------------------------------------------------------------

//*******************************************************************************************
}
?>