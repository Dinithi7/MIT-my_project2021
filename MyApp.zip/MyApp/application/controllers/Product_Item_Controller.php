<?php
class Product_Item_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Product_Item_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->model('Product_Item_Model');
$this->load->library('upload');

}
public function savedata(){
	
	

// the code below checks if the ModelNo exists in the items table because it is the PK
$this->form_validation->set_rules(
	'ModelNo', 'ModelNo',
	'required|is_unique[items.ModelNo]',
	array(
			'required'      => 'ModelNo is required.',
			'is_unique'     => 'This ModelNo exists.'
	)
	
);
$this->form_validation->set_rules('ProductName','ProductName','required');
$this->form_validation->set_rules('ProductBrand','ProductBrand','required');
$this->form_validation->set_rules('ProductPrice','ProductPrice','required');
$this->form_validation->set_rules('Quantity','Quantity','required');
$this->form_validation->set_rules('Warranty','Warranty','required');



if($this->form_validation->run()==FALSE){

$this->load->view('product_items_view');
if($this->input->post('save')){
$ModelNo=$this->input->post("ModelNo");
$ProductName=$this->input->post('ProductName');
$ProductBrand=$this->input->post('ProductBrand');
$ProductPrice=$this->input->post('ProductPrice');
$Quantity=$this->input->post('Quantity');
$Warranty=$this->input->post('Warranty');
$Image="";


}}
else
{
	
    $ModelNo=$this->input->post("ModelNo");
    $ProductName=$this->input->post('ProductName');
    $ProductBrand=$this->input->post('ProductBrand');
    $ProductPrice=$this->input->post('ProductPrice');
    $Quantity=$this->input->post('Quantity');
    $Warranty=$this->input->post('Warranty');
    $Image="";
	$Status="Registered";



$this->Product_Item_Model->saverecords($ModelNo,$ProductName,$ProductBrand,$ProductPrice,$Quantity,$Warranty,$Image,$Status);
echo "Records saved successfully";

}

}
public function displaydata(){
	$result['data']=$this->Product_Item_Model->display_items();
	$this->load->view('display_product_items',$result);	
}
public function deletedata(){
$Id=$this->input->get('Id');

$this->Product_Item_Model->delete_users($Id);
echo "Record was deleted";
}
//-------------------------------------------------------------
public function updatedata(){


	$Id=$this->input->get('Id');

	$result['data']=$this->Product_Item_Model->displayitemsbyid($Id);

	$this->load->view('update_items_products',$result);
	
	

if($this->input->post('update')){
$Id=$this->input->get('Id');
$ProductName=$this->input->post('ProductName');
$ProductBrand=$this->input->post('ProductBrand');
$ProductPrice=$this->input->post('ProductPrice');
$Quantity=$this->input->post('Quantity');
$Warranty=$this->input->post('Warranty');

$this->Product_Item_Model->update_items($Id,$ProductName,$ProductBrand,$ProductPrice,$Quantity,$Warranty);
echo "The records were updated";
redirect('Product_Item_controller/displaydata');
}
}
}