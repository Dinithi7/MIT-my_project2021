<?php
class Reports_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Reports_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->helper('email');

}

public function viewRepairPayments()

{
    $this->load->view('Search_Payments_M');
	$StartDate=$this->input->post('StartDate');
		
		$EndDate=$this->input->post('EndDate');

	
	if($this->input->post('Search')){
		
		if (($StartDate=="") || ($EndDate==""))

    { echo '<p style="color: red; text-align:center;">
        Two dates should be selected
        </p>';

    }	
	else
	{

		$this->load->model("Reports_Model");
		$result['data']=$this->Reports_Model->getPaymentsBETWEENtwoDaysforsShopVisitPayments($StartDate,$EndDate);
        $result['data1']=$this->Reports_Model->getTotalPaymentforsShopVisitPayments($StartDate,$EndDate);
        $result['data2']=$this->Reports_Model->getPaymentsBETWEENtwoDaysforVisitRepairPayments($StartDate,$EndDate);
        $result['data3']=$this->Reports_Model->getTotalPaymentforVisitRepairPayments($StartDate,$EndDate);
		$this->load->view('display_repair_payments',$result);
	}
}
}

//-----------------------------------------------------------------------------------------------------
public function viewPurchasePayments()

{
	$this->load->view('Search_Payments_M');
	$StartDate=$this->input->post('StartDate');
		
		$EndDate=$this->input->post('EndDate');

	
	if($this->input->post('Search')){

		if (($StartDate=="") || ($EndDate==""))

		{ echo '<p style="color: red; text-align:center;">
			Two dates should be selected
			</p>';
	
		}
		
		else {
		$this->load->model("Reports_Model");
		$result1['data4']=$this->Reports_Model->getPurchasePayments($StartDate,$EndDate);
        $result1['data5']=$this->Reports_Model->getTotalPaymentforPurchasePayments($StartDate,$EndDate);
        
		$this->load->view('display_purchase_payments',$result1);
		}
}

}

public function viewRepairsOneDay()
{
	$this->load->view('Search_Payments_Oneday_M');
	$ChosenDate=$this->input->post('ChosenDate');
		
	if($this->input->post('Search')){
		
		if ($ChosenDate=="")

    { echo '<p style="color: red; text-align:center;">
        Select a day
        </p>';

    }

	else{
		$this->load->model("Reports_Model");
		$result2['data6']=$this->Reports_Model->getPaymentsONEDAYforsShopVisitPayments($ChosenDate);




        $result2['data7']=$this->Reports_Model->getTotalPaymentforONEDAYShopVisitPayments($ChosenDate);
		
        $result2['data8']=$this->Reports_Model->getPaymentsONEDAYforVisitRepairPayments($ChosenDate);
        $result2['data9']=$this->Reports_Model->getTotalPaymentforONEDAYVisitRepairPayments($ChosenDate);
		$this->load->view('display_RepairsOneDay_Payment',$result2);
	}
}
}
public function viewSalesIncomeBETWEENTwoDays()
{
	$this->load->view('Search_SalesIncome_TwoDays');
	$StartDate=$this->input->post('StartDate');
		
	$EndDate=$this->input->post('EndDate');
	if($this->input->post('Search')){

		if (($StartDate=="") || ($EndDate==""))

		{ echo '<p style="color: red; text-align:center;">
			Two dates should be selected
			</p>';
	
		}
		
		else {
		$this->load->model("Reports_Model");
		$result3['data10']=$this->Reports_Model->getIncomeBetweenTwoDays($StartDate,$EndDate);
        $result3['data11']=$this->Reports_Model->getTotalIncomeBetweenTwoDays($StartDate,$EndDate);
        
		$this->load->view('display_salesTwoDays',$result3);
		}
}
}
//-----------------------------------------------------------------
public function viewSalesIncomeForONEDAY()
	{

$this->load->view('Search_SalesIncome_OneDay_M');
	$ChosenDate=$this->input->post('ChosenDate');
		
	if($this->input->post('Search')){
		
		if ($ChosenDate=="")

    { echo '<p style="color: red; text-align:center;">
        Select a day
        </p>';

    }
	else{
		// 
		$this->load->model("Reports_Model");
		$result4['data12']=$this->Reports_Model->getIncomeforONEDAY($ChosenDate);
        $result4['data13']=$this->Reports_Model->getTotalIncomeforONEDAY($ChosenDate);
        
		$this->load->view('display_salesOneDay',$result4);

	}


	}

}
//--------------------------------------------------------
public function ViewProductWithQuantity()
{
	
	
	
	$result5['data15']=$this->Reports_Model->getallProductID();
	$this->load->view('display_product_quantity',$result5);
	$ProductID=$this->input->post('Id');
	if($this->input->post('Search')){
	$result6['data16']=$this->Reports_Model->getquantity($ProductID);
	$this->load->view('display_product_quanity_result',$result6 );
	}

}

}
?>