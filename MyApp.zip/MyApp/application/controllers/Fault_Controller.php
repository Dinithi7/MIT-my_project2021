<?php
class Fault_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Fault_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->helper('email');

}
public function savedata(){

    $this->form_validation->set_rules('ItemName','ItemName','required');
    $this->form_validation->set_rules('Fault','Fault','required');
    $this->form_validation->set_rules('TotalCost','TotalCost','required');
    $this->form_validation->set_rules('TimeToRepair','TimeToRepair','required');
    if($this->form_validation->run()==FALSE){
        $this->load->view('Register_Fault');
        if($this->input->post('save')){
        $ItemName=$this->input->post("ItemName");
        $Fault=$this->input->post('Fault');
        $TotalCost=$this->input->post('TotalCost');
        $TimeToRepair=$this->input->post('TimeToRepair');
    }}
    else
    {
        $ItemName=$this->input->post("ItemName");
        $Fault=$this->input->post('Fault');
        $TotalCost=$this->input->post('TotalCost');
        $TimeToRepair=$this->input->post('TimeToRepair');
        $this->Fault_Model->saverecords($ItemName,$Fault,$TotalCost,$TimeToRepair);
        echo "Records saved successfully";
       
    }
    
    }
//---------------------------------------------------------
public function displaydata(){
	$result['data']=$this->Fault_Model->display_faults();
	$this->load->view('display_faults_registered',$result);	
}
//------------------------------------------------
public function deletefaults()

{
    $FaultID=$this->input->get('FaultID');
    $this->Fault_Model->delete_faults($FaultID);
    echo "Records deleted";

}
///------------------------------------------
public function updatefaults()
{
    $FaultID=$this->input->get('FaultID');
    $this->load->model("Fault_Model");
	$result1['data1']=$this->Fault_Model->displayitemsbyid($FaultID);
	$this->load->view('update_faults',$result1);
    

if($this->input->post('update')){
$FaultID=$this->input->get('FaultID');
$TotalCost=$this->input->post('TotalCost');
$TimeToRepair=$this->input->post('TimeToRepair');
$this->Fault_Model->update_faults_of_items($FaultID,$TotalCost,$TimeToRepair);
echo "The record was updated";
redirect('Fault_Controller/displaydata');

}

}

}