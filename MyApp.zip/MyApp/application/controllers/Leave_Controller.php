<?php
class Leave_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Leave_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->model('items_model');
$this->load->library('upload');

}

public function savedata()
    {
        

            $this->form_validation->set_rules('LeaveType','LeaveType','required');
            $this->form_validation->set_rules('Reason','Reason','required');
            $this->form_validation->set_rules('LeaveDate','LeaveDate','required');
            if($this->form_validation->run()==FALSE){
                $this->load->view('Request_Leave');
                if($this->input->post('save')){
                $LeaveType=$this->input->post("LeaveType");
                $Reason=$this->input->post("Reason");
                $LeaveDate=$this->input->post("LeaveDate");
                $DurationSL=$this->input->post("DurationSL");
                $DurationHL=$this->input->post("DurationHL");
                $Date=date('Y-m-d');
                $Year = date ( "Y" );
                $Status="Available";
                

            }}
            else
            {
                $LeaveType=$this->input->post("LeaveType");
                $Reason=$this->input->post("Reason");
                $LeaveDate=$this->input->post("LeaveDate");
                $DurationSL=$this->input->post("DurationSL");
                $DurationHL=$this->input->post("DurationHL");
                $Year = date ( "Y" );
               
                $Status="Available";
                $varName =$this->session->userdata('Email');
                $EmpID=$this->Leave_Model->getEmpIDtosaveinLeaveDetails($varName);
                //------------------------------------------------------------------
                $CatID=$this->Leave_Model->getCatID($EmpID);
                $HalfDays=$this->Leave_Model->getNoOfHalfDaysFROMemployeecategories($CatID);
                $ShortLeave=$this->Leave_Model->getNoOfShortLeaveFROMemployeecategories($CatID);
                $FullDays=$this->Leave_Model->getNoOfFullDaysFROMemployeecategories($CatID);
                $EmpShortLeave=$this->Leave_Model->getNoShortLeaveofAnEmployees($EmpID,$Year);
                $EmpHalfDays=$this->Leave_Model->getNoHalfDaysofAnEmployees($EmpID,$Year);
                $EmpFullDays=$this->Leave_Model->getNoFullDaysofAnEmployees($EmpID,$Year);
                $Date=date('Y-m-d');
                $LeaveID=$this->Leave_Model->checkifrecordExistsforaDateAndEmployee($EmpID,$LeaveDate);
                if(($LeaveID=="") && ($Reason=="Casual"))
                {
                //-----------------------------------------------------------------------
                if (($LeaveType=="Short Leave") &&( $DurationSL!="") && ($EmpShortLeave<$ShortLeave) && ($Reason=="Casual"))
                {
                    $Duration=$DurationSL;
                //----------------------------------------------------------------------
                $this->Leave_Model->saverecords($EmpID,$LeaveDate,$LeaveType,$Duration,$Reason,$Year,$Status,$Date);
                
                echo '<span style="color:blue;">You have leave available.Please await approval by the Administrator</span>';
                }
                

                else if(($LeaveType=="Half Day") &&( $DurationHL!="") &&($EmpHalfDays<$HalfDays) && ($Reason=="Casual"))
               {
                $Duration=$DurationHL;
                //----------------------------------------------------------------------
                $this->Leave_Model->saverecords($EmpID,$LeaveDate,$LeaveType,$Duration,$Reason,$Year,$Status,$Date);
                echo '<span style="color:blue;">You have leave available.Please await approval by the Administrator</span>';
               }
               

              else  if (($LeaveType=="Full Day") && ($EmpFullDays<$FullDays)&& ($Reason=="Casual"))
               {
                   $Duration= "9.00 A.M -6.00 P.M";
                   $this->Leave_Model->saverecords($EmpID,$LeaveDate,$LeaveType,$Duration,$Reason,$Year,$Status,$Date);
                   echo '<span style="color:blue;">You have leave available.Please await approval by the Administrator</span>';

               }
               else {
                echo '<span style="color:red;">Sorry! The leave you requested is unavailable..</span>';
            }
        }
        //---------------------------------------------------------------
       else if(($LeaveID=="") && ($Reason=="Medical")){

            //------------------------------------------
            if (($LeaveType=="Short Leave") &&( $DurationSL!="") && ($Reason=="Medical"))
                {
                    $Duration=$DurationSL;
                    $Reason="Medical";
                    $Status="Requested";
                //----------------------------------------------------------------------
                $this->Leave_Model->saverecords($EmpID,$LeaveDate,$LeaveType,$Duration,$Reason,$Year,$Status,$Date);
                
                echo '<span style="color:blue;">Your request for Medical Leave has been recorded.</span>';
                echo '<span style="color:blue;">Please await approval by the Administrator.</span>';
                }
                

                else if(($LeaveType=="Half Day") &&( $DurationHL!="") && ($Reason=="Medical"))
               {
                $Duration=$DurationHL;
                $Reason="Medical";
                $Status="Requested";
                //----------------------------------------------------------------------
                $this->Leave_Model->saverecords($EmpID,$LeaveDate,$LeaveType,$Duration,$Reason,$Year,$Status,$Date);
                echo '<span style="color:blue;">Your request for Medical Leave has been recorded.</span>';
                echo '<span style="color:blue;">Please await approval by the Administrator.</span>';
               }
               

              else  if (($LeaveType=="Full Day") &&  ($Reason=="Medical"))
               {
                   $Duration= "9.00 A.M - 6.00 P.M";
                   $Reason="Medical";
                   $Status="Requested";
                   $this->Leave_Model->saverecords($EmpID,$LeaveDate,$LeaveType,$Duration,$Reason,$Year,$Status,$Date);
                   echo '<span style="color:blue;">Your request for Medical Leave has been recorded.</span>';
                   echo '<span style="color:blue;">Please await approval by the Administrator.</span>';
               }
           

        }
        //-------------------------------------------------------------------

            else{

                echo '<span style="color:blue;">You have already requested leave on this date.</span>';
            }
               
            }
        
    }
public function ShowLeaveHistoryToEmployee()
{
    $varName =$this->session->userdata('Email'); 
    $result['data']=$this->Leave_Model->showLeaveHistoryToEmployee($varName);
    $this->load->view('display_LeaveHistory_E',$result);
}

public function ShowLeaveHistoryToAdmin()
{
    
    $result1['data1']=$this->Leave_Model->showLeaveRequeststoAdmin();
    $this->load->view('display_LeaveHistory_A',$result1);

}
public function approverequest()
{
    $LeaveID=$this->input->get('LeaveID');
    $this->Leave_Model->updateApproval($LeaveID);
    echo '<span style="color:blue;">Leave request was approved.</span>';
}
//the function below is not in use
public function rejectrequest()
{
    $LeaveID=$this->input->get('LeaveID');
    $this->Leave_Model->updateNonApproval($LeaveID);
    echo '<span style="color:blue;">Leave request was rejected.</span>';
}



}
?>