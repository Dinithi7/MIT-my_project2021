<?php
class Customers_Controller extends CI_Controller
{
public function __construct(){
parent::__construct();
$this->load->database();
$this->load->model("Customers_Model");
$this->load->helper(array('form'));
$this->load->library(array('form_validation'));
$this->load->helper('url');
$this->load->helper('email');

}
public function savedata(){

$this->form_validation->set_rules('FirstName','FirstName','required');
$this->form_validation->set_rules('LastName','LastName','required');
$this->form_validation->set_rules('Address','Address','required');
$this->form_validation->set_rules(
	'ContactNo', 'ContactNo',
	'required|is_unique[Customers.ContactNo]|min_length[10]|max_length[10]',
    
	array(
			'required'      => 'ContactNo is required.',
            
			'is_unique'     => 'This ContactNo is being used by another Customer.Please use another Contact No.'
	)
	
);

$this->form_validation->set_rules(
	'Username', 'Username',
	'required|is_unique[Users.Email]|valid_email',
    
	array(
			'required'      => 'Email field is required.',
			'is_unique'     => 'There is another account with this email.Please use another e-mail address to register.'
	)
);
$this->form_validation->set_rules('Password','Password','required|min_length[8]');
$this->form_validation->set_rules('ConfirmPassword','ConfirmPassword','required|min_length[8]|matches[Password]');

if($this->form_validation->run()==FALSE){
$this->load->view('customers_view');
if($this->input->post('save')){
$FN=$this->input->post("FirstName");
$LN=$this->input->post('LastName');
$AD=$this->input->post('Address');
$CN=$this->input->post('ContactNo');

//$password = sha1($this->input->post('password'));
$UN=$this->input->post('Username');
$PW=sha1($this->input->post('Password'));
$CPW=sha1($this->input->post('ConfirmPassword'));
$CG=$this->input->post('Customer');



}}
else
{
    $FN=$this->input->post("FirstName");
    $LN=$this->input->post('LastName');
    $AD=$this->input->post('Address');
    $CN=$this->input->post('ContactNo');
    

    $UN=$this->input->post('Username');
    $PW=sha1($this->input->post('Password'));
    $CPW=sha1($this->input->post('ConfirmPassword'));
    $CG="Customer";
    $Status="Activated";
	//$Created=date ( "Y" );
	$Created=date('Y-m-d');
	$Modified=date('Y-m-d');
   
    $this->Customers_Model->saverecords($FN,$LN,$AD,$CN,$UN,$Created,$Modified);
    $this->Customers_Model->saveusers($UN,$FN,$LN,$PW,$CG,$Status);
    echo "Records saved successfully";
	redirect('login1_controller/login_validation');
	
   
}

}
public function displaydata(){
	$result['data']=$this->Customers_Model->display_customers();
	$this->load->view('display_customers',$result);	
}
public function deletedata(){
$Email=$this->input->get('Email');

$this->Customers_Model->delete_users($Email);
echo "Records deleted";
}

public function updatedata(){
	$CustomerID=$this->input->get('CustomerID');
	$result['data']=$this->Customers_Model->displayitemsbyid($CustomerID);
	$this->load->view('update_customers',$result);
    

if($this->input->post('update')){
$CustomerID=$this->input->get('CustomerID');
$FN=$this->input->post('FirstName');
$LN=$this->input->post('LastName');
$AD=$this->input->post('Address');
$CN=$this->input->post('ContactNo');
$EM=$this->input->post('Email');

$this->Customers_Model->update_customers_users($CustomerID,$FN,$LN,$EM);
$this->Customers_Model->update_customers($CustomerID,$FN,$LN,$AD,$CN,$EM);

echo "The record was updated";
redirect("Customers_Controller/displaydata");


}
}
//************************************************************************************** */
//code below is for DEO to register a customer
//similar CUSTOMER online registration page but EMAIL is NOT REQUIRED
public function saveCustomerAtShop(){

	$this->form_validation->set_rules('FirstName','FirstName','required');
	$this->form_validation->set_rules('LastName','LastName','required');
	$this->form_validation->set_rules('Address','Address','required');
	$this->form_validation->set_rules(
		'ContactNo', 'ContactNo',
		'required|is_unique[Customers.ContactNo]|min_length[10]|max_length[10]',
		
		array(
				'required'      => 'ContactNo is required.',
				
				'is_unique'     => 'This ContactNo is being used by another Customer.Please use another Contact No.'
		)
		
	);
	$this->form_validation->set_rules('Password','Password','required|min_length[8]');
	$this->form_validation->set_rules('ConfirmPassword','ConfirmPassword','required|min_length[8]|matches[Password]');	
	if($this->form_validation->run()==FALSE){
	$this->load->view('customers_view');
	if($this->input->post('save')){
		$FN=$this->input->post("FirstName");
		$LN=$this->input->post('LastName');
		$AD=$this->input->post('Address');
		$CN=$this->input->post('ContactNo');
		
		
		$UN=$this->input->post('Username');
		$PW=sha1($this->input->post('Password'));
		$CPW=sha1($this->input->post('ConfirmPassword'));
		$CG=$this->input->post('Customer');
	
	
	
	}}
	else
	{
	$FN=$this->input->post("FirstName");
    $LN=$this->input->post('LastName');
    $AD=$this->input->post('Address');
    $CN=$this->input->post('ContactNo');
    

    $UN=$this->input->post('Username');
    $PW=sha1($this->input->post('Password'));
    $CPW=sha1($this->input->post('ConfirmPassword'));
    $CG="Customer";
    $Status="Activated";
	$Created=date('Y-m-d');
	$Modified=date('Y-m-d');
	//$Created=date ( "Y" );
	//$Modified=date ( "Y" );
		
	   
		$this->Customers_Model->saverecords($FN,$LN,$AD,$CN,$UN,$Created,$Modified);
		$this->Customers_Model->saveusers($UN,$FN,$LN,$PW,$CG,$Status);
		echo "Records saved successfully";
	   
	}
	
	}
//---------------------------------------------------------------------------------------
public function viewWarrantyExpires()
{ 	
	$varName =$this->session->userdata('Email');
	$date=date('Y-m-d');
	$this->load->model("Customers_Model");
	$result['data']=$this->Customers_Model->display_expired_warranty($varName,$date);
	$result['data1']=$this->Customers_Model->display_nonexpired_warranty($varName,$date);
	$this->load->model("Customers_Model");
	$WarrantyExpires=$this->Customers_Model->warrantydate($varName);
	//$this->load->view('display_warranty_alerts',$result);

	
	if ($WarrantyExpires<=$date)
{
	$this->load->view('display_warranty_alerts',$result);

}
else{
	echo "The Items you have purchased have not yet expired";
}


}
//------------------------------------------------------------------------------------
public function ViewOrderHistory()
{
	$varName =$this->session->userdata('Email');
	$CustomerID=$this->Customers_Model->getCustomerID($varName);
	$result1['data2']=$this->Customers_Model->getAllOrders($CustomerID);
	$this->load->view('display_shoppingorders_C',$result1);

}
public function viewmyordersdetails()

{
	$OrderID=$this->input->get('OrderID');
    $this->load->model("Customers_Model");
	
	$result12['data12']=$this->Customers_Model->getCustomerDetailsToOrderDetailsPage($OrderID);
	
    $result12['data14']=$this->Customers_Model->getOrderItemsTableDetails($OrderID);
    $result12['data15']=$this->Customers_Model->getGrandTotal($OrderID);
	$result12['data16']=$this->Customers_Model->getOrderedate($OrderID);
    $this->load->view('display_shoppingorder_details',$result12);
	
}

public function viewmyorderInvoice()

{
	$OrderID=$this->input->get('OrderID');
    $this->load->model("Customers_Model");
	$result13['data13']=$this->Customers_Model->getCustomerDetailsToOrderDetailsPage($OrderID);
    $result13['data14']=$this->Customers_Model->getOrderItemsTableDetails($OrderID);
    $result13['data15']=$this->Customers_Model->getGrandTotal($OrderID);
	$result13['data12']=$this->Customers_Model->getOrderedate($OrderID);
	$this->load->view('display_Invoice_SCart_C',$result13);	
	
}

//---------------------------------------------------------------------------------------
}
?>