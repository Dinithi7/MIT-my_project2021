<?php
class Product_Item_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }   
function saverecords($ModelNo,$ProductName,$ProductBrand,$ProductPrice,$Quantity,$Warranty,$Image,$Status){
$query="Insert into Products values('$ModelNo','$ProductName','$ProductBrand','$ProductPrice','$Quantity','$Warranty','','$Status')";
$this->db->query($query);
}
public function display_items(){
    
    $query=$this->db->query('SELECT * from Products');
    
    return $query->result();
    }
//------------------------------------------------------------------------------
public function delete_users($Id){
$this->db->query("delete from Products where Id='".$Id."' ");
    }
//--------------------------------------------------------------------------
public function displayitemsbyid($Id){
$query=$this->db->query("select * from products where Id='".$Id."'");

return $query->result();
}
//-------------------------------------------------------------------------------------------

public function update_items($Id,$ProductName,$ProductBrand,$ProductPrice,$Quantity,$Warranty){

$query=$this->db->query("update products SET ProductName='$ProductName',ProductBrand='$ProductBrand',ProductPrice='$ProductPrice',Quantity=Quantity+'$Quantity',Warranty='$Warranty' WHERE  Id='".$Id."'");
    
    
    
    }

}