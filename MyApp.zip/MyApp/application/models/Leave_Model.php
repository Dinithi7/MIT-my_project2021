<?php
class Leave_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }

function saverecords($EmpID,$LeaveDate,$LeaveType,$Duration,$Reason,$Year,$Status,$Date){
$query="Insert into LeaveDetails values('','$EmpID','$LeaveDate','$LeaveType','$Duration','$Reason','$Year','$Status','$Date')";
 $this->db->query($query);
        }
//------------------------------------------------------------
public function getEmpIDtosaveinLeaveDetails($username){
    $query=$this->db->query("SELECT EmpID FROM Employees WHERE Email ='".$username."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $EmpID= $row->EmpID;

               return $EmpID;    
        }   
   }
    
}
//-------------------------------------------------------------------
public function getCatID($EmpID){
    $query=$this->db->query("SELECT CatID FROM employees WHERE EmpID='".$EmpID."'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $CatID= $row->CatID;

               return $CatID;    
        }   
   }
    
}
public function getNoOfHalfDaysFROMemployeecategories($CatID)
{
    $query=$this->db->query("SELECT HalfDays FROM employeecategories WHERE CatID='".$CatID."'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $HalfDays= $row->HalfDays;

               return $HalfDays;    
        }   
   }

}
public function getNoOfShortLeaveFROMemployeecategories($CatID)
{
    $query=$this->db->query("SELECT ShortLeave FROM employeecategories WHERE CatID='".$CatID."'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $ShortLeave= $row->ShortLeave;

               return $ShortLeave;    
        }   
   }

}

public function getNoOfFullDaysFROMemployeecategories($CatID)
{
    $query=$this->db->query("SELECT FullDays FROM employeecategories WHERE CatID='".$CatID."'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $FullDays= $row->FullDays;

               return $FullDays;    
        }   
   }

}
//---------------------------------------------------------------
//code below is to get each employee's leave details

public function getNoShortLeaveofAnEmployees($EmpID,$Year)
{
    $query=$this->db->query("SELECT count(LeaveID)as EmpShortLeave FROM leavedetails WHERE EmpID='".$EmpID."' AND Year='".$Year."'AND LeaveType='Short Leave' AND Status='Approved'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $EmpShortLeave= $row->EmpShortLeave;

               return $EmpShortLeave;    
        }   
   }

}
public function getNoHalfDaysofAnEmployees($EmpID,$Year)
{
    $query=$this->db->query("SELECT count(LeaveID)as EmpHalfDays FROM leavedetails WHERE EmpID='".$EmpID."' AND Year='".$Year."'AND LeaveType='Half Days' AND Status='Approved'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $EmpHalfDays= $row->EmpHalfDays;

               return $EmpHalfDays;    
        }   
   }

}

public function getNoFullDaysofAnEmployees($EmpID,$Year)
{
    $query=$this->db->query("SELECT count(LeaveID)as EmpFullDays FROM leavedetails WHERE EmpID='".$EmpID."' AND Year='".$Year."'AND LeaveType='Full Days' AND Status='Approved'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $EmpFullDays= $row->EmpFullDays;

               return $EmpFullDays;    
        }   
   }

}
//code below is to see if the same date and same empid record exists

public function checkifrecordExistsforaDateAndEmployee($EmpID,$LeaveDate)
{

    $query=$this->db->query("SELECT LeaveID FROM leavedetails WHERE EmpID='".$EmpID."'AND LeaveDate='".$LeaveDate."'");
    
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $LeaveID= $row->LeaveID;

               return $LeaveID;    
        }   
   }

}

//---------------------------------------------------------------------------------------------
//code below is to display leave history to the Employee
public function showLeaveHistoryToEmployee($username)
{
    $query=$this->db->query("SELECT l.LeaveID,l.LeaveDate,l.LeaveType,l.Duration,l.Reason,l.Year,l.Status,l.Date FROM leavedetails l, employees e WHERE l.EmpID=e.EmpID AND e.email='".$username."'");
    return $query->result_array();
}
//code below is to show the Leave Requests to ADMIN

public function showLeaveRequeststoAdmin()
{
    $query=$this->db->query("SELECT l.LeaveID,l.EmpID,CONCAT(e.FirstName,'',e.LastName) as EmployeeName, c.CatName,l.LeaveDate,l.LeaveType,l.Duration,l.Reason,l.Year,l.Status,l.Date FROM leavedetails l, employees e, employeecategories c WHERE l.EmpID=e.EmpID AND e.CatID=c.CatID");
    return $query->result_array();
}
//code below is for ADMIN to update Approve/Reject Leave Requests

public function updateApproval($LeaveID){

    $query=$this->db->query("update leavedetails SET Status='Approved' WHERE  LeaveID='".$LeaveID."'");
    
    
}
//function below isn't in use
public function updateNonApproval($LeaveID){

    $query=$this->db->query("update leavedetails SET Status='Rejected' WHERE  LeaveID='".$LeaveID."'");
    
    }
}
