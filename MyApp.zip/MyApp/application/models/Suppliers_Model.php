<?php
class Suppliers_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }   
function saverecords($FirstName,$LastName,$SupplierName,$Address,$LandLine,$MobileNo,$Email){
$query="Insert into Suppliers values('','$FirstName','$LastName','$SupplierName','$Address','$LandLine','$MobileNo','$Email')";
$this->db->query($query);
}

function saveusers($Username,$FirstName,$LastName,$Password,$Category,$Status){
    $query="Insert into Users values('','$Username','$FirstName','$LastName','$Password','$Category','$Status')";
    $this->db->query($query);
    }

public function display_suppliers(){
        $query=$this->db->query('SELECT s.SupplierID,s.FirstName,s.LastName,s.SupplierName,s.Address,s.LandLine,s.MobileNo,s.Email,u.Status FROM suppliers s,users u WHERE u.Email=s.Email');
        return $query->result();
        
        }

public function delete_suppliers($Email){
            $this->db->query("delete from Suppliers where Email='".$Email."'");
            $this->db->query("delete from Users where Email='".$Email."'");
}
public function displayitemsbyid($SupplierID){
    $query=$this->db->query("SELECT s.SupplierID,s.FirstName,s.LastName,s.SupplierName,s.Address,s.LandLine,s.MobileNo,s.Email,u.Status FROM suppliers s,users u WHERE u.Email=s.Email AND SupplierID='".$SupplierID."'");
    return $query->result();
    }
//------------------------------------------------------------------------------------
public function update_suppliers($SupplierID,$FirstName,$LastName,$SupplierName,$Address,$LandLine,$MobileNo,$Email){

    $this->db->query("update Suppliers SET FirstName='$FirstName',LastName='$LastName',SupplierName='$SupplierName',Address='$Address',LandLine='$LandLine',MobileNo='$MobileNo',Email='$Email' where SupplierID='".$SupplierID."'");   
     
    }
    public function update_supplier_users($SupplierID,$FirstName,$LastName,$Email,$Status)
    {
    $this->db->query("update users u, suppliers s SET u.FirstName='$FirstName',u.LastName='$LastName',u.Email='".$Email."',u.Status='".$Status."' WHERE u.Email= s.Email AND s.SupplierID='".$SupplierID."'"); 
    }


//*********************************************************************************************** */
function savePendingItems($ModelNo,$Price,$SupplierID,$RequestStatus){
        $query="Insert into Items values('','$ModelNo','$Price','$SupplierID','$RequestStatus')";
        $this->db->query($query);
        }



public function display_Pending_items(){
            
//$query=$this->db->query('SELECT i.ID,i.ModelNo,i.ItemName,i.Brand,i.Price,i.Quantity,s.SupplierName,i.Warranty FROM items i, suppliers s WHERE i.SupplierID=s.SupplierID AND i.RequestStatus="Pending"');
$query=$this->db->query('SELECT i.ID,p.Id,p.ProductName,p.ProductBrand,p.ProductPrice,s.SupplierName,p.Warranty FROM items i,products p ,suppliers s WHERE i.SupplierID=s.SupplierID AND p.Id=i.ModelNo AND i.RequestStatus="Pending";');           
            return $query->result();
}

public function updateRequestStatusToRegisteredINItemsTable($ID){

    $query=$this->db->query("UPDATE items SET RequestStatus='Registered' where ID='".$ID."'");
    }
//-------------------------------------------------
//-----------------------------------------------
public function delete_pendingItems($ID){
        $this->db->query("delete from items where ID='".$ID."'");
        }
public function CheckIfRowwithIdEXISTSinProductsTable($ModelNo)
        {
            /*
            $query=$this->db->query("SELECT EXISTS (SELECT * from Items WHERE ModelNo='".$ModelNo."' AND SupplierID='".$SupplierID."')");
            if($query->num_rows() == 1){
                return true;
            }else{
                return false;
            } */
            //---------------------------------------------------------------------------------
            $query=$this->db->query("SELECT Id from products WHERE Id='".$ModelNo."'");
            if($query->num_rows() === 1){
                foreach ($query->result() as $row)
                {
                       
                       $Id= $row->Id;
        
                       return $Id;    
                }   
           }
        }
//---------------------------------------------------------
public function getSupplierID($username){
    $query=$this->db->query("SELECT SupplierID FROM Suppliers WHERE Email ='".$username."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $SupplierID = $row->SupplierID;

                return $SupplierID;    
         }   
    } 
    
}
//-------------------------------------------------------------------------------------
public function getModelNo($ID){
    $query=$this->db->query("SELECT ModelNo FROM Items WHERE ID ='".$ID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $ModelNo = $row->ModelNo;

                return $ModelNo;    
         }   
    } 
    
}
//---------------------------------------------------
public function updateRequestStatusToRegisteredINProductsTable($ModelNo){

    $query=$this->db->query("UPDATE products SET Status='Registered' where Id='".$ModelNo."'");
    }




}
    ?>