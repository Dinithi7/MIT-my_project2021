<?php
class Reports_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    } 
//----------------------------------------------
//code below is to get Repair Payments(Both Shop & Home-visit )between two dates

public function getPaymentsBETWEENtwoDaysforsShopVisitPayments($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT InvoiceNo,RepairID,FaultID,CustomerID,Payment,Date FROM shoprepairpayments WHERE Date BETWEEN '".$StartDate."' AND '".$EndDate."'");
    return $query->result_array();
}
public function getTotalPaymentforsShopVisitPayments($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT sum(payment)as TotalPaymentShop FROM shoprepairpayments WHERE Date BETWEEN '".$StartDate."' AND '".$EndDate."'");
    return $query->result_array();
}

public function getPaymentsBETWEENtwoDaysforVisitRepairPayments($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT InvoiceNo,VisitJobID,FaultID,CustomerID,Payment,Date FROM visitrepairpayments WHERE Date  BETWEEN '".$StartDate."' AND '".$EndDate."'");
    return $query->result_array();
}
public function getTotalPaymentforVisitRepairPayments($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT sum(payment)as TotalPaymentVisits FROM visitrepairpayments WHERE Date BETWEEN '".$StartDate."' AND '".$EndDate."'");
    return $query->result_array();
}

//--------------------------------------------------------------------------------------------
//code below is to get Purchase Payments
public function getPurchasePayments($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT p.InvoiceNo,p.RequestID,r.ModelNo,p.SupplierID,s.SupplierName,p.TotalCost,p.Date FROM purchasepayments p, suppliers s,suppliesrequested r WHERE p.RequestID=r.RequestID AND p.SupplierID=s.SupplierID AND p.Date BETWEEN  '".$StartDate."' AND '".$EndDate."'");
    return $query->result_array();
}
//------------------------------------------------------------------------------------------------
public function getTotalPaymentforPurchasePayments($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT sum(TotalCost) as TotalPurchasePayment FROM purchasepayments WHERE Date BETWEEN '".$StartDate."' AND '".$EndDate."'");
    return $query->result_array();
}


//----------------------------------------------------------------------------------------------
//code below is to get Repair Payments on a selected day
public function getPaymentsONEDAYforsShopVisitPayments($ChosenDate)
{
    $query = $this->db->query("SELECT InvoiceNo,RepairID,FaultID,CustomerID,Payment,Date FROM shoprepairpayments WHERE Date='".$ChosenDate."'");
    return $query->result_array();
}

public function getTotalPaymentforONEDAYShopVisitPayments($ChosenDate)
{
    $query = $this->db->query("SELECT sum(payment)as TotalPaymentShopOneDay FROM shoprepairpayments WHERE Date='".$ChosenDate."'");
    return $query->result_array();
}
public function getPaymentsONEDAYforVisitRepairPayments($ChosenDate)
{
    $query = $this->db->query("SELECT InvoiceNo,VisitJobID,FaultID,CustomerID,Payment,Date FROM visitrepairpayments WHERE Date='".$ChosenDate."'");
    return $query->result_array();
}
public function getTotalPaymentforONEDAYVisitRepairPayments($ChosenDate)
{
    $query = $this->db->query("SELECT sum(payment)as TotalPaymentVisitsOneDay FROM visitrepairpayments WHERE Date='".$ChosenDate."'");
    return $query->result_array();
}


//----------------------------------------------------------------------------------------------
//code below is for sales income
public function getIncomeBetweenTwoDays($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT o.OrderID,o.CustomerID,t.ProductID,t.Quantity,t.SubTotal,o.Created  FROM orders o, orderitems t WHERE o.OrderID=t.OrderID AND o.Created BETWEEN '".$StartDate."' AND '".$EndDate."' AND o.Status='Delivered'");
    return $query->result_array();
    
}
public function getTotalIncomeBetweenTwoDays($StartDate,$EndDate)
{
    $query = $this->db->query("SELECT sum(GrandTotal) as Income FROM orders WHERE Created BETWEEN '".$StartDate."' AND '".$EndDate."'AND Status='Delivered'");
    return $query->result_array();
}

public function getIncomeforONEDAY($ChosenDate)
{
    $query = $this->db->query("SELECT o.OrderID,o.CustomerID,t.ProductID,t.Quantity,t.SubTotal,o.Created  FROM orders o, orderitems t WHERE o.OrderID=t.OrderID AND o.Created='".$ChosenDate."' AND o.Status='Delivered'");
    return $query->result_array();

}

public function getTotalIncomeforONEDAY($ChosenDate)
{
    $query = $this->db->query("SELECT sum(GrandTotal) as Income FROM orders WHERE Created='".$ChosenDate."'AND Status='Delivered'");
    return $query->result_array();

}
public function getquantity($ProductID)
{
    $query = $this->db->query("SELECT p.ProductName,COUNT(OrderID)as ItemCount FROM orderitems o,products p WHERE p.Id= o.ProductID AND o.ProductID='".$ProductID."'");
    return $query->result_array();
}

public function getallProductID()
{
    $query = $this->db->query("SELECT Id FROM products ");
    return $query->result_array();
}
public function getresult()
{
    $query = $this->db->query("SELECT p.ProductName,count(OrderID)as ItemCount FROM orderitems o,products p WHERE p. Id= o.ProductID GROUP BY ProductID");
    return $query->result_array();
}


}