<?php  
 class login1_model extends CI_Model  
 {  
      function can_login($username,$password,$category)  
      {  
           $this->db->where('Email', $username);
           $this->db->where('Password', $password);  
           //$this->db->where('Category', $category); 
           // if the above line is not there , if the correct username and password are given, users will be directed
           //to any profile page, even if they are not registered under that category
           $query = $this->db->get('users');  
           //SELECT * FROM users WHERE username = '$username' AND password = '$password'
           //---------------------------------------------------------  
           if($query->num_rows() > 0)
          
           {  
                return true;  
           }  
           else  
           {  
                return false;       
           } 
 
      }
 
public function display_names($username,$password){
     $query=$this->db->query("SELECT FirstName,LastName FROM Users WHERE Email ='".$username."' AND PASSWORD='".$password."'");
     return $query->result();
     
}
//----------------------------------------------------------------------------------------
// the code below is to get the category and status to direct the user to the respective profile pages
public function getCategory($username,$password){
     $query=$this->db->query("SELECT Category FROM Users WHERE Email ='".$username."' AND PASSWORD='".$password."'");
 
    if($query->num_rows() === 1){
          foreach ($query->result() as $row)
          {
                 
                 $Cat = $row->Category;

                 return $Cat;    
          }   
     } 
     
}

public function getStatus($username,$password){
     $query=$this->db->query("SELECT Status FROM Users WHERE Email ='".$username."' AND PASSWORD='".$password."'");
 
    if($query->num_rows() === 1){
          foreach ($query->result() as $row)
          {
                 
                 $Status = $row->Status;

                 return $Status;    
          }   
     } 
     
}
//--------------------------------------------------------------------------------
public function reactivate($username,$password)
{
$this->db->query("update users SET Status='Activated' WHERE Email ='".$username."' AND PASSWORD='".$password."'"); 

}
//the code below is to deactivate Customers and Suppliers ONLY
public function deactivate_C_and_S($username,$password)
{
$this->db->query("update users SET Status='Deactivated' WHERE Email ='".$username."' AND PASSWORD='".$password."'"); 

}
//************************************************************************************** */
//the code below displays customer details to be update by the CUSTOMER

public function displayCustomerDetails_C($username,$password){
$query=$this->db->query("SELECT CustomerID,FirstName,LastName,Address,ContactNo,Email FROM customers WHERE Email ='".$username."'");
return $query->result();

}
//code below does the updation to both user and customer tables,user table updation was commented 
//FirstName, LastName were removed from query because they were disabled
public function update_customers($CustomerID,$FirstName,$LastName,$Address,$ContactNo,$Email,$username){

//$this->db->query("update Customers SET FirstName='$FirstName',LastName='$LastName',Address='$Address',ContactNo='$ContactNo',Email='$Email' where CustomerID='".$CustomerID."'");   
$this->db->query("update Customers SET Address='$Address',ContactNo='$ContactNo' where Email='".$username."'");     
}
//---------------------------------------------------------------------------------------------------
// The function below was commented because FirstName and LastName were disabled to update.
/*
public function update_customers_users($CustomerID,$FirstName,$LastName,$Email,$username)
{
//$this->db->query("update users u,customers c SET u.FirstName='$FirstName',u.LastName='$LastName',u.Email='".$Email."', c.Email='".$Email."'WHERE u.Email= c.Email AND c.CustomerID='".$CustomerID."'"); 
$this->db->query("update users u,customers c SET u.FirstName='$FirstName',u.LastName='$LastName' WHERE u.Email= c.Email AND c.Email='".$username."'"); 

} */
// Note: If they ask  to make Customer Email updatable , try to get Customer ID from a query, assign it to CustomerID variable and try the two queries in green above
//***************************************************************************************************** */
//the code below displays employee details to be update by the EMPLOYEE

public function displayEmployeeDetails_E($username,$password){
     $query=$this->db->query("SELECT EmpID,FirstName,LastName,NIC,Address,ContactNo,Gender,DateOfBirth,DateJoined,Email FROM employees WHERE Email ='".$username."'");
     return $query->result();
     
     }
//FirstName, LastName,Gender,DOB,DateJoined were removed from query because they were disabled
public function update_employees($EmpID,$FirstName,$LastName,$NIC,$Address,$ContactNo,$Email,$username){

     
 $this->db->query("update employees SET  NIC='$NIC',Address='$Address',ContactNo='$ContactNo' where Email='".$username."'");     
     }
//******************************************************************************************************** */
public function change_password($NewPassword,$username,$password){

 $query=$this->db->query("update users SET password='$NewPassword' where Email='".$username."' AND Password='".$password."'");

 }   
 //***************************************************************************************************** */
 public function viewTechnicianJobs($username)
 { //r.Status!="Delivered"  : ONLY jobs not delivered are listed
     $query=$this->db->query("SELECT r.RepairID,r.CustomerID,CONCAT(c.FirstName,' ',c.LastName)as CustomerName,c.Email,f.ItemName,r.Description,f.Fault,r.ContactNo,r.AcceptDate,r.ReturnDate,r.Warranty,r.TotalCost,r.AdvancePaid,r.Balance,CONCAT(e.FirstName,'',e.LastName) as Technician,r.Status FROM repairitems r,customers c,repairfaults f, employees e WHERE c.CustomerID=r.CustomerID AND r.FaultID=f.FaultID AND e.EmpID=r.EmpID AND r.Status!='Delivered' AND e.Email='".$username."'ORDER BY r.RepairID DESC"); 
     return $query->result();
 }
 public function update_repairs($RepairID,$RD,$Status){
     $query=$this->db->query("update RepairItems SET ReturnDate='$RD',Status='$Status' where RepairID='".$RepairID."'");
     }
//-----------------------------------------------------------------------------
//code below is to let the customer view the status of a handed-over to shop repair
public function getViewHandedOverJobStatusToCustomer($username){

     $query=$this->db->query("SELECT r.RepairID,f.FaultID,f.ItemName,f.Fault,r.Description,r.AcceptDate,r.ReturnDate,r.Warranty,r.TotalCost,r.AdvancePaid,r.Balance, CONCAT(e.FirstName,'  ',e.LastName) as Technician,r.Status FROM repairitems r, employees e, customers c, repairfaults f WHERE r.EmpID=e.EmpID AND f.FaultID=r.FaultID AND c.CustomerID= r.CustomerID AND c.Email='".$username."'ORDER BY r.RepairID DESC"); 
     return $query->result();
}

//-------------------------------------------------------------------------
public function viewHomeVisitRequestScheduleStatus($username)
{
    $query = $this->db->query("SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,(v.EmpID) as Technician,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c WHERE v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND c.Email='".$username."' ORDER BY DateOfRepair ASC");
    return $query->result();
}
//---------------------------------------------------------------------------
public function viewHomeVisitRepairsScheduledToTechnician($username)
{
     $query = $this->db->query("SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,CONCAT(e.FirstName,'',e.LastName) as Technician,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c, employees e WHERE v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND v.EmpID=e.EmpID AND v.ScheduleStatus='Scheduled' AND e.Email='".$username."'  ORDER BY DateOfRepair ASC");
     return $query->result();
}

//----------------------------------------------------------------------------
//************************************************************************** */
//*************************************************************************** */
// code below is for SUPPLIER to view requests
// RequestStatus was taken as !=Pending because of the Update option displayed respective to each row as suppliers should not be able to do anything to "pending".

public function viewRequestsForItemsToSupplier($username)
{
     //$query = $this->db->query("SELECT r.RequestID,r.ModelNo,i.ItemName,i.Brand,(i.Price) as UnitPrice, i.Warranty,r.DateRequired,r.QuantityNeeded,i.RequestStatus FROM suppliesrequested r , items i,suppliers s WHERE r.ModelNo=i.ModelNo AND r.SupplierID=s.SupplierID and s.Email='".$username."' AND i.RequestStatus!='Pending' ORDER BY DateRequired ASC");
     $query = $this->db->query("SELECT r.RequestID,r.ModelNo,p.ProductName,p.ProductBrand,p.ProductPrice,p.Warranty,r.DateRequired,r.QuantityNeeded,r.RequestStatus FROM suppliesrequested r,products p, suppliers s WHERE p.Id=r.ModelNo AND r.SupplierID=s.SupplierID AND s.Email='".$username."' ORDER BY DateRequired ASC;");
     return $query->result(); 
}
//--------------------------------------------------------------------------------------------------
//code to let SUPPLIER update profile
public function displaySupplierDetails_C($username,$password){
     $query=$this->db->query("SELECT * FROM Suppliers WHERE Email ='".$username."'");
     return $query->result();
     
     }
public function update_suppliers($SupplierID,$FirstName,$LastName,$SupplierName,$Address,$LandLine,$MobileNo,$Email,$username){

          //$this->db->query("update Customers SET FirstName='$FirstName',LastName='$LastName',Address='$Address',ContactNo='$ContactNo',Email='$Email' where CustomerID='".$CustomerID."'");   
          $this->db->query("update Suppliers SET Address='$Address',LandLine='$LandLine',MobileNo='$MobileNo' where Email='".$username."'");     
          }

}