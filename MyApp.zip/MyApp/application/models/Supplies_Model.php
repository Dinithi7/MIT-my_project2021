<?php
class Supplies_Model extends CI_Model
{public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    } 

public function displayItemsAtReorderLevel(){

    //$query=$this->db->query("SELECT i.ModelNo,i.ItemName,i.Brand,i.Price,i.Quantity,i.SupplierID,s.SupplierName,i.Warranty,i.RequestStatus FROM items i, suppliers s WHERE i.SupplierID=s.SupplierID AND i.RequestStatus!='Pending' AND Quantity<15");
    $query=$this->db->query("SELECT i.ID,p.Id as ModelNo,p.ProductName,p.ProductBrand,p.ProductPrice,p.Quantity,i.SupplierID,s.SupplierName,p.Warranty,i.RequestStatus FROM products p, suppliers s,items i WHERE p.Id=i.ModelNo AND i.SupplierID=s.SupplierID AND p.Quantity<15 AND i.RequestStatus!='Pending'");
    return $query->result();
}
//-----------------------------------------------------------------------------------
public function displayItemsAtReorderLevelConfirmed(){

    //$query=$this->db->query("SELECT r.RequestID,r.ModelNo,i.ItemName,i.Brand,r.SupplierID,s.SupplierName,r.DateRequired,r.DateOfSupply,r.QuantityNeeded,r.QuantityAvailable,r.UnitPrice,r.RequestStatus FROM suppliesrequested r , items i, suppliers s WHERE r.ModelNo=i.ModelNo AND r.SupplierID=s.SupplierID AND r.RequestStatus='Confirmed'");
    $query=$this->db->query("SELECT r.RequestID,r.ModelNo,p.ProductName,p.ProductBrand,r.SupplierID,s.SupplierName,r.DateRequired,r.DateOfSupply,r.QuantityNeeded,r.QuantityAvailable,r.UnitPrice,r.RequestStatus FROM suppliesrequested r,products p,suppliers s WHERE p.Id=r.ModelNo AND r.SupplierID=s.SupplierID AND r.RequestStatus='Confirmed';");
    return $query->result();
}
//-----------------------------------------------------------------------------------
public function displayItemsAtReorderLevelByModuleNoToPage($ID){

    $query=$this->db->query("SELECT p.Id,p.ProductName,p.ProductBrand,p.ProductPrice,p.Quantity,i.SupplierID,s.SupplierName,p.Warranty,i.RequestStatus FROM products p, suppliers s,items i WHERE p.Id=i.ModelNo AND i.SupplierID=s.SupplierID AND p.Quantity<15 AND i.ID='".$ID."'");
    return $query->result();
}
//-----------------------------------------------------------------------------------
public function setItemStateToRequested($ID,$RequestStatus)

{
    $query=$this->db->query("UPDATE items SET RequestStatus='$RequestStatus' where ID='".$ID."'");
    
}

public function getSupplierIDToSaveInSuppliesrequestedTable($ID){
    $query=$this->db->query("SELECT i.SupplierID FROM items i,products p WHERE i.ModelNo=p.id AND i.ID='".$ID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $SupplierID = $row->SupplierID;

                return $SupplierID;    
         }   
    } 
    
}
//----------------------------------------------------------------------------------------------------------


public function saverequests($ModelNo,$SupplierID,$DateRequired,$DateOfSupply,$QuantityNeeded,$QuantityAvailable,$UnitPrice,$RequestStatus)
{
    $query="Insert into suppliesrequested values(' ','$ModelNo','$SupplierID','$DateRequired','$DateOfSupply','$QuantityNeeded','$QuantityAvailable','$UnitPrice','$RequestStatus')";
    $this->db->query($query);
}

//----------------------------------------------------------------------------------------------------
public function displayItemsRequestedToSupplierPAGE($RequestID)
{
    //$query=$this->db->query("SELECT r.RequestID,r.ModelNo,i.ItemName,i.Brand,i.Price,i.Warranty,r.DateRequired,r.QuantityNeeded FROM suppliesrequested r, items i WHERE r.ModelNo=i.ModelNo and r.RequestID='".$RequestID."'");
    $query=$this->db->query("SELECT r.RequestID,r.ModelNo,p.ProductName,p.ProductBrand,p.ProductPrice,p.Warranty,r.DateRequired,r.QuantityNeeded FROM suppliesrequested r,products p  WHERE r.ModelNo=p.Id AND r.RequestID='".$RequestID."'");
    return $query->result();
}

public function updateConfirmingOfOrders($RequestID,$DateOfSupply,$QuantityAvailable,$UnitPrice,$RequestStatus)
{
    $query=$this->db->query(" UPDATE suppliesrequested SET DateOfSupply='$DateOfSupply',QuantityAvailable='$QuantityAvailable',UnitPrice='$UnitPrice',RequestStatus='$RequestStatus' WHERE RequestID='".$RequestID."'");
    //$query=$this->db->query(" UPDATE suppliesrequested SET DateOfSupply='$DateOfSupply' WHERE RequestID='".$RequestID."'");
}
public function getModelNoFromSuppliesrequestedTable($RequestID){
    $query=$this->db->query("SELECT ModelNo FROM suppliesrequested WHERE RequestID='".$RequestID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $ModelNo= $row->ModelNo;

                return $ModelNo;    
         }   
    } 
    
}
public function updateUnitPrice($ModelNo,$UnitPrice)
{
    $query=$this->db->query(" UPDATE items SET Price='$UnitPrice' WHERE ModelNo='".$ModelNo."'");
    
}


public function saveinPurchasePayments($RequestID,$SupplierID,$TotalCost,$date)
{
    $query="Insert into purchasepayments values(' ','$RequestID','$SupplierID','$TotalCost','$date')";
    $this->db->query($query);
}

public function getSupplierIDToSaveInPurchasePaymentsTable($RequestID){
    $query=$this->db->query("SELECT SupplierID FROM suppliesrequested WHERE RequestID='".$RequestID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $SupplierID = $row->SupplierID;

                return $SupplierID;    
         }   
    } 
    
}
//--------------------------------------------------------------------------------------
//code below is to get data to view the INVOICE
public function getDataToInvoiceForConfirmedSupplies($RequestID)
{
    $query=$this->db->query("SELECT p.InvoiceNo,r.RequestID,r.ModelNo,r.SupplierID,s.SupplierName,s.Email,r.DateOfSupply,r.QuantityAvailable as Quantity,r.UnitPrice FROM suppliesrequested r,Suppliers s, purchasepayments p WHERE s.SupplierID=r.SupplierID AND p.RequestID=r.RequestID AND r.RequestID='".$RequestID."'");
    return $query->result_array();
}
public function getTotalCostToInvoiceForConfirmedSupplies($RequestID)
{
    $query=$this->db->query("SELECT (QuantityAvailable *UnitPrice)as TotalPrice FROM suppliesrequested WHERE RequestID='".$RequestID."'");
    return $query->result_array();
}
//===============================================================
public function getModelNoToSaveInSuppliesrequestedTable($ID){
    $query=$this->db->query("SELECT i.ModelNo FROM items i,products p WHERE i.ModelNo=p.id AND i.ID='".$ID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $ModelNo = $row->ModelNo;

                return $ModelNo;    
         }   
    } 
    
}
//------------------------------------------------------------------------------------------------

public function getQuantityAvailableFROMSuppliesrequestedTable($RequestID){
    $query=$this->db->query("SELECT QuantityAvailable FROM suppliesrequested WHERE RequestID='".$RequestID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $QuantityAvailable = $row->QuantityAvailable;

                return $QuantityAvailable;    
         }   
    } 
    
}
//code below is to get the ModelNo from Suppliesrequested table
public function getModelNoSuppliesrequestedTable($RequestID){
    $query=$this->db->query("SELECT ModelNo FROM suppliesrequested WHERE RequestID='".$RequestID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $ModelNo = $row->ModelNo;

                return $ModelNo;    
         }   
    } 
    
}
public function updateQuantity($QuantityAvailable,$ModelNo)
{
    $query=$this->db->query(" UPDATE products SET Quantity=Quantity+'$QuantityAvailable' WHERE Id='".$ModelNo."'");
    
}
//-----------------------------------------------------------------------
//code below was added later to update status in suppliesrequested table

public function updateInvoiceSentStatus($RequestID)

{
    $query=$this->db->query(" UPDATE suppliesrequested SET RequestStatus='InvoiceSent' WHERE RequestID='".$RequestID."'");
}
//code below was added later to update requeststatus in items table after invoice is sent

public function getSupplierIDfromSuppliesOrderedtable($RequestID)
{

    $query=$this->db->query("SELECT SupplierID FROM suppliesrequested WHERE RequestID='".$RequestID."'");

   if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $SupplierID = $row->SupplierID;

                return $SupplierID;    
         }   
    } 
}
public function updateRequestStatusinItemstable($ModelNo,$SupplierID)
{
    $query=$this->db->query(" UPDATE items SET RequestStatus='Registered' WHERE ModelNo='".$ModelNo."' AND SupplierID='".$SupplierID."'");
}

//-----------------------------------------------------------------


}