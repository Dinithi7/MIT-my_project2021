<?php
class Homepage_Model extends CI_Model
{  public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    } 
public function SearchProductName($Search)
{

$query=$this->db->query("SELECT * FROM products WHERE ProductName LIKE '%$Search%'");
return $query->result_array();

}
function saveContactMessages($FirstName,$LastName,$Subject,$ContactNo,$Email,$date){
    $query="Insert into contactmessages values('','$FirstName','$LastName','$Subject','$ContactNo','$Email','$date')";
    $this->db->query($query);
    }


//---------------------------------------------------------------------------

 
}
?>