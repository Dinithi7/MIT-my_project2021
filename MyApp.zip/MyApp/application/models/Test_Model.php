<?php
class Test_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }   
    public function selectbyrange($min,$max)
    {
        $query = $this->db->query("SELECT * FROM products WHERE ProductPrice BETWEEN '".$min."' AND '".$max."'");
        return $query->result_array();
    }

 
}
