<?php
class Employees_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }
//****************************************************************************************** */
//code below is for ADMIN to save and update employee categories
function saverecordsEC($CatName,$Salary,$FD,$HD,$SL){
$query="Insert into EmployeeCategories values('','$CatName','$Salary','$FD','$HD','$SL')";
$this->db->query($query);
}
public function display_EC($CatName){
$query=$this->db->query("select * from EmployeeCategories where CatName='".$CatName."'");
return $query->result();
 }
 public function update_EC($CatName,$Salary,$FD,$HD,$SH){

$query=$this->db->query("update EmployeeCategories SET CatName='$CatName',Salary='$Salary',FullDays='$FD',HalfDays='$HD',ShortLeave='$SH' where CatName='".$CatName."'");

    }
public function getAllCategories(){
$query = $this->db->query('SELECT CatID,CatName FROM EmployeeCategories');
return $query->result_array();
        
    }
/******************************************************************************************** */
//getAllCategories model from above is used below again
//code below is for ADMIN to register employees : saved to both UsersTable and EmployeeTable
function saverecords($FirstName,$LastName,$NIC,$Address,$ContactNo,$Gender,$DOB,$DateJoined,$Email,$CatID){
    $query="Insert into Employees values('','$FirstName','$LastName','$NIC','$Address','$ContactNo','$Gender','$DOB','$DateJoined','$Email','$CatID')";
    $this->db->query($query);
    }
    
function saveusers($Username,$FirstName,$LastName,$Password,$Category,$Status){
    $query="Insert into Users values('','$Username','$FirstName','$LastName','$Password','$Category','$Status')";
    $this->db->query($query);
    }
// getCatName function is to save CatName to UsersTable: input from form is CatID
function getCatName($CatID){
$query = $this->db->query("SELECT CatName FROM EmployeeCategories WHERE CatID='".$CatID."'");
if($query->num_rows() === 1){
    foreach ($query->result() as $row)
    {
           
           $CatName = $row->CatName;

           return $CatName;    
    }   
}  
}
//-----------------------------------------------------------------------------------------------------
public function display_employees(){
   
   $query=$this->db->query('SELECT e.EmpID,e.FirstName,e.LastName,e.NIC,e.Address,e.ContactNo,e.Gender,e.DateOfBirth,e.DateJoined,e.Email,u.Category,u.Status FROM employees e,users u WHERE  u.Email=e.Email');
    return $query->result();
}
//--------------------------------------------------------------------------------------------
public function displayitemsbyid($EmpID){
    $query=$this->db->query("SELECT e.EmpID,e.FirstName,e.LastName,e.NIC,e.Address,e.ContactNo,e.Gender,e.DateOfBirth,e.DateJoined,e.Email,u.Category,u.Status FROM employees e, users u WHERE u.Email=e.Email AND e.EmpID='".$EmpID."'");
    return $query->result();
    }
//-------------------------------------------------------------------------------------------
public function update_employees($EmpID,$FirstName,$LastName,$NIC,$Address,$ContactNo,$Email,$CatID){

    $this->db->query("update employees SET FirstName='$FirstName',LastName='$LastName',NIC='$NIC',Address='$Address',ContactNo='$ContactNo',Email='$Email',CatID='$CatID' where EmpID='".$EmpID."'");   
     
    }
    public function update_employee_users($EmpID,$FirstName,$LastName,$Email,$CatName,$Status)
    {
    $this->db->query("update users u,employees e, employeecategories c  SET u.FirstName='$FirstName',u.LastName='$LastName',u.Email='".$Email."',u.Category='".$CatName."',u.Status='".$Status."', e.Email='".$Email."'WHERE u.Email= e.Email AND c.CatID=e.CatID AND e.EmpID='".$EmpID."'");  
    }
//--------------------------------------------------------------------------------------------
function getCatID($CatName){
    $query = $this->db->query("SELECT CatID FROM EmployeeCategories WHERE CatName='".$CatName."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $CatID = $row->CatID;
    
               return $CatID;    
        }   
    }  
    }
//----------------------------------------------------------------------------------------------
public function delete_employees($Email){
    $this->db->query("delete from employees where Email='".$Email."'");
    $this->db->query("delete from Users where Email='".$Email."'");
    }
//----------------------------------------------------------------------------------------------
}
 