<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product extends CI_Model{
    
    function __construct() {
       $this->proTable = 'products';
        $this->custTable = 'customers';
        $this->ordTable = 'orders';
        $this->ordItemsTable = 'orderitems';
        
    }
     /*
     * Fetch products data from the database
     * @param id returns a single record if specified, otherwise all records
     */
        public function getRows($Id = ''){
        $this->db->select('*');
        $this->db->from($this->proTable);
        $this->db->where('Status', 'Registered');
         
        if($Id){
            $this->db->where('Id', $Id);
            $query = $this->db->get();
            $result = $query->row_array();
        }else{
            $this->db->order_by('ProductName', 'asc');
            $query = $this->db->get();
            $result = $query->result_array();
        }
        
        // Return fetched data
        return !empty($result)?$result:false;
    }
     /*
     * Fetch order data from the database
     * @param id returns a single record of the specified ID
     */
    public function getOrder($Id){
        $this->db->select('o.*, c.FirstName,c.LastName, c.Address, c.ContactNo, c.Email');
        $this->db->from($this->ordTable.' as o');
        $this->db->join($this->custTable.' as c', 'c.CustomerID = o.CustomerID', 'left');
        $this->db->where('o.OrderID', $Id);
        $query = $this->db->get();
        $result = $query->row_array();
        
        // Get order items
        $this->db->select('i.*, p.Id,p.ProductName, p.ProductPrice, p.Image');
        $this->db->from($this->ordItemsTable.' as i');
        $this->db->join($this->proTable.' as p', 'p.Id = i.ProductID', 'left');
        $this->db->where('i.OrderID', $Id);
        $query2 = $this->db->get();
        $result['items'] = ($query2->num_rows() > 0)?$query2->result_array():array();
        
        // Return fetched data
        return !empty($result)?$result:false;
    }
     /*
     * Insert customer data in the database
     * @param data array
     */
    public function insertCustomer($data){
        // Add created and modified date if not included
        //-------------------------------------------------
        
        if(!array_key_exists("created", $data)){
            $data['created'] = date("Y-m-d H:i:s");
        }
        if(!array_key_exists("modified", $data)){
            $data['modified'] = date("Y-m-d H:i:s");
        }
        //--------------------------------------------------
        // Insert customer data
        $insert = $this->db->insert($this->custTable, $data);

        // Return the status
        return $insert?$this->db->insert_id():false;
    }
     /*
     * Insert order data in the database
     * @param data array
     */
    
    public function insertOrder($data){
        // Add created and modified date if not included
        if(!array_key_exists("created", $data)){
            $data['created'] = date('Y-m-d');
        }
        if(!array_key_exists("modified", $data)){
            $data['modified'] = date('Y-m-d');
        }
        
        // Insert order data
        $insert = $this->db->insert($this->ordTable, $data);

        // Return the status
        return $insert?$this->db->insert_id():false;
    }
    
    /*
     * Insert order items data in the database
     * @param data array
     */
    public function insertOrderItems($data = array()) {
        
        // Insert order items
        $insert = $this->db->insert_batch($this->ordItemsTable, $data);

        // Return the status
        return $insert?true:false;
    }
//code written
//code below is to get customerid
public function getCustomerID($username){
    $query=$this->db->query("SELECT CustomerID FROM Customers WHERE Email ='".$username."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $CustomerID= $row->CustomerID;

               return $CustomerID;    
        }   
   }
    
}
//by me-------------------------------------------------------------------------
//code to deduct sold quantity from exiting quantity
public function updatequantity($Id,$Quantity){

    $query=$this->db->query("update products SET Quantity=Quantity-'$Quantity' WHERE  Id='".$Id."'");
        
        
        
        }

//-------------------------------------------------------
//by me 
//code to generate invoice for shopping cart for delivery to DEO

public function display_undelivered_orders()
{
    $query=$this->db->query("SELECT o.OrderID,o.Created,CONCAT(c.FirstName,'',c.LastName) as Name,c.Address,c.ContactNo,o.GrandTotal,o.Status FROM orders o, customers c WHERE c.CustomerID=o.CustomerID ORDER BY O.OrderID DESC");
    return $query->result_array();
}

//---------------------------------------------------------
public function PageToupdateShoppingCartOrderStatus($OrderID)

{
    $query=$this->db->query("SELECT o.OrderID,o.Created,CONCAT(c.FirstName,'',c.LastName) as Name,c.Address,c.ContactNo,o.GrandTotal,o.Status FROM orders o, customers c WHERE c.CustomerID=o.CustomerID and OrderID='".$OrderID."'");
    return $query->result_array();
}
public function updatestatusofdelivery($OrderID)
{
    $this->db->query("update orders SET Status='Delivered' where OrderID='".$OrderID."'");   
}

public function getOrderItemsTableDetails($OrderID)
{
    $query=$this->db->query("SELECT o.OrderID,o.ProductID,p.ProductName,p.ProductPrice,o.Quantity,o.SubTotal,o.WarrantyExpires FROM orderitems o,products p WHERE p.Id=o.ProductID and o.OrderID='".$OrderID."'");
    return $query->result_array();
}

public function getGrandTotal($OrderID)
{
    $query=$this->db->query("SELECT GrandTotal FROM orders WHERE OrderID='".$OrderID."'");
    return $query->result_array();
}

//------------------------------------
//code to check if quantity requeted is available
public function getAvailableQuantity($ProductID)

{
$query=$this->db->query("SELECT Quantity FROM products WHERE Id='".$ProductID."'");
return $query->result();
}


}