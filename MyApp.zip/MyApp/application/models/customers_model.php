<?php
class Customers_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }   
function saverecords($FirstName,$LastName,$Address,$ContactNo,$Email,$Created,$Modified){
$query="Insert into Customers values('','$FirstName','$LastName','$Address','$ContactNo','$Email','$Created','$Modified')";
$this->db->query($query);
}

function saveusers($Username,$FirstName,$LastName,$Password,$Category,$Status){
    $query="Insert into Users values('','$Username','$FirstName','$LastName','$Password','$Category','$Status')";
    $this->db->query($query);
    }


public function display_customers(){
$query=$this->db->query('select * from Customers');
return $query->result();

}
public function delete_users($Email){
$this->db->query("delete from Customers where Email='".$Email."'");
$this->db->query("delete from Users where Email='".$Email."'");
}

public function displayitemsbyid($CustomerID){
$query=$this->db->query("select * from Customers where CustomerID='".$CustomerID."'");
return $query->result();
}

public function update_customers($CustomerID,$FirstName,$LastName,$Address,$ContactNo,$Email){

$this->db->query("update Customers SET FirstName='$FirstName',LastName='$LastName',Address='$Address',ContactNo='$ContactNo',Email='$Email' where CustomerID='".$CustomerID."'");   
 
}
public function update_customers_users($CustomerID,$FirstName,$LastName,$Email)
{
$this->db->query("update users u,customers c SET u.FirstName='$FirstName',u.LastName='$LastName',u.Email='".$Email."', c.Email='".$Email."'WHERE u.Email= c.Email AND c.CustomerID='".$CustomerID."'"); 
}





function getAllGroups(){
  
    $query = $this->db->query('SELECT SupplierID,SupplierName FROM suppliers');
    return $query->result_array();

}
//--------------------------------------------------------------------------
//code below is for warranty management
public function warrantydate($username){
    $query=$this->db->query("SELECT t.WarrantyExpires FROM orders o,orderitems t, customers c,users u WHERE o.orderID=t.OrderID AND c.CustomerID=o.CustomerID AND c.Email=u.Email AND u.Email='".$username."'");
    if($query->num_rows()>0 ){
        foreach ($query->result() as $row)
        {
               
               $WarrantyExpires= $row->WarrantyExpires;

               return $WarrantyExpires;    
        }   
   }
    
}
//code to get expired warranties
public function display_expired_warranty($username,$date)

{
    $query = $this->db->query("SELECT o.CustomerID,t.ProductID,p.ProductName,t.WarrantyExpires,p.Warranty FROM products p,orders o,orderitems t, customers c,users u WHERE p.Id=t.ProductID and o.orderID=t.OrderID and c.CustomerID=o.CustomerID AND c.Email=u.Email AND u.Email='".$username."' AND t.WarrantyExpires<='".$date."'");
     return $query->result_array();

}

//code below is to get the warranty from products table
public function getWarrantyOfProduct($Id){
    $query=$this->db->query("SELECT Warranty FROM products WHERE Id='".$Id."'");
    if($query->num_rows()==1 ){
        foreach ($query->result() as $row)
        {
               
               $Warranty= $row->Warranty;

               return $Warranty;    
        }   
   }
    
}
//code to get non-expired warranties
public function display_nonexpired_warranty($username,$date)

{
    $query = $this->db->query("SELECT o.CustomerID,t.ProductID,p.ProductName,t.WarrantyExpires,p.Warranty FROM products p,orders o,orderitems t, customers c,users u WHERE p.Id=t.ProductID and o.orderID=t.OrderID and c.CustomerID=o.CustomerID AND c.Email=u.Email AND u.Email='".$username."' AND t.WarrantyExpires>'".$date."'");
     return $query->result_array();

}

//---------------------------------------------------------------------------
//code below is for a Customer to view his/her order history
public function getCustomerID($username)
{
    $query=$this->db->query("SELECT CustomerID FROM customers WHERE Email='".$username."'");
    if($query->num_rows()==1 ){
        foreach ($query->result() as $row)
        {
               
               $CustomerID= $row->CustomerID;

               return $CustomerID;    
        }   
   }


}

public function getAllOrders($CustomerID)
{
    $query=$this->db->query("select * from orders where CustomerID='".$CustomerID."'");
    return $query->result_array();
}
//--------------------------------------------------------------------------------------

public function getCustomerDetailsToOrderDetailsPage($OrderID)

{
    $query=$this->db->query("SELECT o.OrderID,CONCAT(c.FirstName,'',c.LastName) as Name,c.Address,c.ContactNo,o.GrandTotal,o.Status FROM orders o, customers c WHERE c.CustomerID=o.CustomerID and OrderID='".$OrderID."'");
    return $query->result_array();
}


public function getOrderItemsTableDetails($OrderID)
{
    $query=$this->db->query("SELECT o.OrderID,o.ProductID,p.ProductName,p.ProductPrice,o.Quantity,o.SubTotal,o.WarrantyExpires FROM orderitems o,products p WHERE p.Id=o.ProductID and o.OrderID='".$OrderID."'");
    return $query->result_array();
}

public function getGrandTotal($OrderID)
{
    $query=$this->db->query("SELECT GrandTotal FROM orders WHERE OrderID='".$OrderID."'");
    return $query->result_array();
}

public function getOrderedate($OrderID)
{
    $query=$this->db->query("SELECT Created FROM orders WHERE OrderID='".$OrderID."'");
    return $query->result_array();

}
//------------------------------------------------------------------------------------
}