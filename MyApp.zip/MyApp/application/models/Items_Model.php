<?php
class Items_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }   
function saverecords($ModelNo,$Price,$SupplierID,$RequestStatus){
$query="Insert into Items values('','$ModelNo','$Price','$SupplierID','$RequestStatus')";
$this->db->query($query);
}
public function display_items(){
//$query=$this->db->query('select * from items');
//$query=$this->db->query('SELECT i.ID,i.ModelNo,i.ItemName,i.Brand,i.Price,i.Quantity,i.SupplierID,s.SupplierName,i.Warranty FROM items i, suppliers s WHERE i.RequestStatus!="Pending" AND i.SupplierID=s.SupplierID');
$query=$this->db->query('SELECT p.Id as ModelNo ,i.ID,p.ProductName,p.ProductBrand,p.ProductPrice,p.Warranty,i.SupplierID,s.SupplierName,i.RequestStatus FROM items i, products p,suppliers s WHERE i.SupplierID=s.SupplierID AND p.Id=i.ModelNo AND i.RequestStatus!="Pending"');
return $query->result();
}
public function delete_users($ID){
$this->db->query("delete from items where ID='".$ID."' ");
}

public function displayitemsbyid($ID){
//$query=$this->db->query("select * from items where ModelNo='".$ModelNo."'");
//$query=$this->db->query(" SELECT i.ID,i.ModelNo,i.ItemName,i.Brand,i.Price,i.Quantity,s.SupplierName,i.Warranty FROM items i, suppliers s WHERE  i.SupplierID=s.SupplierID AND ID='".$ID."'");
//SELECT i.ID,p.Id as ModelNo,p.ProductName,p.ProductBrand,p.ProductPrice,p.Warranty,s.SupplierName,FROM items i, products p, suppliers s WHERE i.SupplierID=s.SupplierID AND p.Id=i.ModelNo AND ID='".$ID."'");
$query=$this->db->query("SELECT i.ID,p.Id as ModelNo,p.ProductPrice,s.SupplierName FROM items i, products p, suppliers s WHERE i.SupplierID=s.SupplierID AND p.Id=i.ModelNo AND i.ID='".$ID."'");
return $query->result();
}

public function update_items($ID,$ModelNo,$ProductPrice,$SupplierID){

$query=$this->db->query("update items SET Price='$ProductPrice',SupplierID='$SupplierID' WHERE  ID='".$ID."'");



}
function getAllGroups(){
  
    
    $query = $this->db->query('SELECT SupplierID,SupplierName FROM Suppliers');
    return $query->result_array();
    
}
public function update_items_supplier($ID,$SupplierID){

    $query=$this->db->query("update items SET SupplierID='$SupplierID' where ID='".$ID."'");
}
function getAllModels(){
  
    
    $query = $this->db->query('SELECT ModelNo FROM items');
    return $query->result_array();
}
//************************************************************************************************
function update_dp($ModelNo, $file_name) {
    $this->db->set("image", $file_name);
    $this->db->where("ModelNo", $ModelNo);
    $this->db->update("items");
    $row = $this->db->affected_rows();

    if ($row) {
        return $image_path;
    } else{
        return FALSE;
    }
}
//********************************************************************************************
public function getimage() {
    //$this->db->select('*');
    //$this->db->from('items');
    //$query = $this->db->get();
    $query = $this->db->query('SELECT image FROM items WHERE ModelNo=1234');

    if($query->num_rows() != 0){
        return $query->result_array();
    }else{
        return false;
    }
}
//************************************************************************************** */
public function CheckIfRowwithModelNoANDSupplierIDEXISTS($ModelNo,$SupplierID)
{
    /*
    $query=$this->db->query("SELECT EXISTS (SELECT * from Items WHERE ModelNo='".$ModelNo."' AND SupplierID='".$SupplierID."')");
    if($query->num_rows() == 1){
        return true;
    }else{
        return false;
    } */
    //---------------------------------------------------------------------------------
    $query=$this->db->query("SELECT ID from Items WHERE ModelNo='".$ModelNo."' AND SupplierID='".$SupplierID."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $ID= $row->ID;

               return $ID;    
        }   
   }
    //-------------------------------------------------------------------------------

}

}

