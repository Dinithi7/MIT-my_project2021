<?php
class Fault_Model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }   
function saverecords($ItemName,$Fault,$TotalCost,$TimeToRepair){
$query="Insert into repairfaults values('','$ItemName','$Fault','$TotalCost','$TimeToRepair')";
$this->db->query($query);
}

public function display_faults(){
    $query=$this->db->query('select * from repairfaults');
    return $query->result();
    
    }
    //------------------------------------------------------
public function delete_faults($FaultID){
    $this->db->query("delete from repairfaults where FaultID='".$FaultID."' ");
        }
//-----------------------------------------------
public function displayitemsbyid($FaultID){
    $query=$this->db->query("select * from repairfaults where FaultID='".$FaultID."' "); 
    return $query->result();
    }
//---------------------------------------------------------------------
public function update_faults_of_items($FaultID,$TotalCost,$TimeToRepair){
    $this->db->query("update repairfaults SET TotalCost='$TotalCost',TimeToRepair='$TimeToRepair' where FaultID='".$FaultID."'");   
     
    }
}
