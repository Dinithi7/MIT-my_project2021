<?php
class Repairs_Model extends CI_Model
{
function saverecords($CustomerID,$FaultID,$ID,$CN,$AD,$RD,$Warranty,$TotalCost,$paid,$Balance,$Technician,$Status){
$Balance= $TotalCost-$paid;
$query="Insert into RepairItems values('','$CustomerID','$FaultID','$ID','$CN','$AD','$RD','$Warranty','$TotalCost','$paid','$Balance','$Technician','$Status')";
$this->db->query($query);
}
public function display_items(){
$query=$this->db->query('SELECT r.RepairID,r.CustomerID,CONCAT(c.FirstName,"",c.LastName)as CustomerName,c.Email,f.ItemName,r.Description,f.Fault,r.ContactNo,r.AcceptDate,r.ReturnDate,r.Warranty,r.TotalCost,r.AdvancePaid,r.Balance,CONCAT(e.FirstName,"",e.LastName)as Technician,r.Status FROM repairitems r,customers c,repairfaults f,employees e WHERE c.CustomerID=r.CustomerID AND r.FaultID=f.FaultID AND r.EmpID=e.EmpID ORDER BY r.RepairID DESC');
return $query->result();

}
public function delete_users($RepairID){
$this->db->query("delete from RepairItems where RepairID='".$RepairID."'");
}
/*
public function displayitemsbyid($RepairID){
$query=$this->db->query("select * from RepairItems where RepairID='".$RepairID."'");
return $query->result();

}*/
public function displayitemsbyid($RepairID){
    $query=$this->db->query("SELECT r.RepairID,r.CustomerID,CONCAT(c.FirstName,'',c.LastName)as CustomerName,c.Email,r.Description,f.Fault,r.ContactNo,r.AcceptDate,r.ReturnDate,r.Warranty,r.TotalCost,r.AdvancePaid,r.Balance,r.EmpID,CONCAT(e.FirstName,'',e.LastName) as Technician,r.Status FROM repairitems r,customers c,repairfaults f, employees e WHERE c.CustomerID=r.CustomerID AND r.FaultID=f.FaultID AND e.EmpID=r.EmpID AND r.RepairID='".$RepairID."'");
    return $query->result();
}

//--------------------------------------------------------------------------------
public function update_repairs($RepairID,$RD,$EmpID,$Status){
$query=$this->db->query("update RepairItems SET ReturnDate='$RD',EmpID='$EmpID',Status='$Status' where RepairID='".$RepairID."'");
}
public function listTechnicians(){
  
    //$query = $this->db->query('SELECT CONCAT(FirstName," ",LastName)as Technician FROM Users WHERE Category="Technician"');
    $query = $this->db->query('SELECT EmpID,CONCAT(e.FirstName," ",e.LastName)as Technician FROM employees e, users u WHERE u.Status="Activated" AND e.Email=u.Email AND CatID=2');

    return $query->result_array();
    
}
function listContactNo(){
  
    
    $query = $this->db->query('SELECT ContactNo FROM Customers');

    return $query->result_array();
    
}

//********************************************************************************* */
//code below deals with the Listing of faults and then adding a job.
//---------------------------------------------------------------------------------------
 public function display_faults_shop(){
    $query=$this->db->query('select * from repairfaults');
    return $query->result();
    
    }
public function displayfaultsbyid($FaultID){
    $query=$this->db->query("select * from repairfaults where FaultID='".$FaultID."'");
    return $query->result();
     }
public function getTotalCost($FaultID){
        $query=$this->db->query("SELECT TotalCost FROM repairfaults WHERE FaultID='".$FaultID."'");
    
       if($query->num_rows() === 1){
             foreach ($query->result() as $row)
             {
                    
                    $TotalCost = $row->TotalCost;
   
                    return $TotalCost;    
             }   
        } 
        
   }
//code below is to get the CustomerID to the RepairItems table with ContactNo as input from form
public function getCustomerID($CN)
    {
        $query=$this->db->query("select CustomerID from Customers where ContactNo='".$CN."'");
        
        if($query->num_rows() === 1){
            foreach ($query->result() as $row)
            {
                   
                   $CustomerID = $row->CustomerID;
  
                   return $CustomerID;    
            }   
       } 
    }
//code below displays Fault and Customer Email to Update Repair Items Page
public function getFaultIDToUpdatePage($RepairID)
    {
        $query=$this->db->query("SELECT FaultID from repairitems where RepairID='".$RepairID."'");
        if($query->num_rows() === 1){
            foreach ($query->result() as $row)
            {
                   
                   $FaultID= $row->FaultID;
    
                   return $FaultID;    
            }   
       }
    }
public function getFaultNameToUpdatePage($FaultID)
{
    $query=$this->db->query("select ItemName, Fault from repairfaults where FaultID='".$FaultID."'");
    return $query->result(); 
     
}
public function getEmailToUpdatePage($RepairID)
{
    $query=$this->db->query("select c.CustomerID,c.Email from Customers c, repairitems r where c.CustomerID= r.CustomerID AND RepairID='".$RepairID."'");
    return $query->result(); 
     
}
//************************************************************************************************ */
 //code to get Last saved RepairID and amountpaid to save ShopRepairPayments table
 public function getLastSavedRepairID()
    {
        $query=$this->db->query('SELECT RepairID FROM repairitems WHERE RepairID=(SELECT max(RepairID) FROM repairitems)');
        if($query->num_rows() === 1){
            foreach ($query->result() as $row)
            {
                   
                   $RepairID= $row->RepairID;
    
                   return $RepairID;    
            }   
       }
    }
    
    //----------------------------------------------------------------------------
    //code below is to save records to ShopRepairPayments Table when item is being accepted for Repair
    // and  an advance has been paid
   public function saverecordsToShopRepairPayments($RepairID,$FaultID,$paid,$CustomerID,$date,$UserID){
        
        $query="Insert into shoprepairpayments values('','$RepairID','$FaultID','$paid','$CustomerID','$date','$UserID')";
        $this->db->query($query);
        }
    //---------------------------------------------------------------------------------------
    // code below is to save records to ShopRepairPayments Table when item is delivered and the balance is paid
   public function saverecordsToShopRepairPaymentsAfterDelivery($RepairID,$FaultID,$Balance,$CustomerID,$date,$UserID){
        
        $query="Insert into shoprepairpayments values('','$RepairID','$FaultID','$Balance','$CustomerID','$date','$UserID')";
        $this->db->query($query);
        }
// code below is to get the CustomerID to ShopRepairPayments Table when balance is paid
public function getCustomerIDtoSaveWhenBalanceIsPaid($RepairID)
    {
        $query=$this->db->query("select CustomerID from repairitems where RepairID='".$RepairID."'");
        
        if($query->num_rows() === 1){
            foreach ($query->result() as $row)
            {
                   
                   $CustomerID = $row->CustomerID;
  
                   return $CustomerID;    
            }   
       } 
    }
//code below is to get the Balance from repairitems to ShopRepairPayments Table when balance is paid
public function getBalancetoSaveWhenBalanceIsPaid($RepairID)
    {
        $query=$this->db->query("select Balance from repairitems where RepairID='".$RepairID."'");
        
        if($query->num_rows() === 1){
            foreach ($query->result() as $row)
            {
                   
                   $Balance = $row->Balance;
  
                   return $Balance;    
            }   
       } 
    }
//----------------------------------------------------------------------------------------------------
//code below is for HOME-VISIT Repairs
public function saveHomeVisitRepair($FaultID,$CustomerID,$Warranty,$DateOfRepair,$EmpID,$StartTime,$EndTime,$ScheduleStatus)
{
   
    $query="Insert into visitrepairs values('','$FaultID','$CustomerID','$Warranty','$DateOfRepair','$EmpID','$StartTime','$EndTime','$ScheduleStatus')";
    $this->db->query($query);
 }
//code to get TimeToRepair
public function getTimeToRepair($FaultID)
{
    $query=$this->db->query("select TimeToRepair from repairfaults where FaultID='".$FaultID."'");
        
        if($query->num_rows() === 1){
            foreach ($query->result() as $row)
            {
                   
                   $TimeToRepair = $row->TimeToRepair;
  
                   return $TimeToRepair;    
            }   
       }
}
//----------------------------------------------------------------
//********************************************************************** */
// code to display requests made by Customers to the DEO 
public function viewHomeVisitRequeststoSchedule()
{
    $query = $this->db->query('SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,(v.EmpID) as Technician,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c WHERE v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND v.EmpID=0 ORDER BY DateOfRepair ASC');
    return $query->result();
}
//2 functions below are used to get scheduled and unscheduled repairs on the same page
public function getScheduledHomeVisitsByDate($DateOfRepair)
{
    $query = $this->db->query("SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,CONCAT(e.FirstName,' ',e.LastName) as Technician,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c , employees e WHERE v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND v.EmpID=e.EmpID  AND DateOfRepair='".$DateOfRepair."'");
    return $query->result();
}

public function getUnscheduledHomeVisitsByDate($DateOfRepair)
{
    $query = $this->db->query("SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,(v.EmpID) as Technician,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c WHERE v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID  AND v.EmpID=0 AND DateOfRepair='".$DateOfRepair."' ORDER BY v.VisitJobID ASC");
    
    return $query->result();
}

//code below is to get individual update pages

public function getDataToUpdateScheduledHomeVisitsPage($VisitJobID)
{
    $query = $this->db->query("SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,f.TimeToRepair,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,CONCAT(e.FirstName,' ',e.LastName) as Technician,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c , employees e WHERE v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND v.EmpID=e.EmpID AND v.VisitJobID='".$VisitJobID."'");
    return $query->result();
}
public function getDataToUpdateUnScheduledHomeVisitsPage($VisitJobID)
{
    $query = $this->db->query("SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,f.TimeToRepair,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c  WHERE v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID  AND v.VisitJobID='".$VisitJobID."'");
    return $query->result();
}

// 2 functions below are used to update the table

public function updateScheduledHomeVisit($VisitJobID,$DateOfRepair,$StartTime,$EndTime,$EmpID,$ScheduleStatus){
    $query=$this->db->query("update visitrepairs SET ScheduleStatus='$ScheduleStatus' where VisitJobID='".$VisitJobID."'");
    }

public function updateUnScheduledHomeVisit($VisitJobID,$StartTime,$EndTime,$EmpID,$SStatus){
    $query=$this->db->query("update visitrepairs SET StartTime='$StartTime',EndTime='$EndTime',EmpID='$EmpID',ScheduleStatus='$SStatus' where VisitJobID='".$VisitJobID."'");
    }


  // code below is to save  repairs to visitrepairpayments on Schedule 
  public function saverecordsToVisitRepairPayments($VisitJobID,$FaultID,$CustomerID,$EmpID,$TotalCost,$date){
        
    $query="Insert into visitrepairpayments values('','$VisitJobID','$FaultID','$CustomerID','$EmpID','$TotalCost','$date')";
    $this->db->query($query);
    }
 //-----------------------------------------------------------------------
 //code below is to get the FaultID from visitrepairs table to save in visitrepairpayments 
 public function getFaultIDtoSaveInHomeVisitPayments($VisitJobID)
 {
     $query=$this->db->query("SELECT FaultID from visitrepairs where VisitJobID='".$VisitJobID."'");
     if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $FaultID= $row->FaultID;
 
                return $FaultID;    
         }   
    }
 }
 // code below is to get CustomerID visitrepairs table to save in visitrepairpayments
 public function getCustomerIDtoSaveInHomeVisitPayments($VisitJobID)
 {
     $query=$this->db->query("SELECT CustomerID from visitrepairs where VisitJobID='".$VisitJobID."'");
     if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $CustomerID= $row->CustomerID;
 
                return $CustomerID;    
         }   
    }
 }

// code function in line 61 was reused, to get the TotalCost to to save in visitrepairpayments
// code below is to get Warranty from  visitrepairs table to save in visitrepairpayments
public function getWarranty($VisitJobID)
 {
     $query=$this->db->query("SELECT Warranty from visitrepairs where VisitJobID='".$VisitJobID."'");
     if($query->num_rows() === 1){
         foreach ($query->result() as $row)
         {
                
                $Warranty= $row->Warranty;
 
                return $Warranty;    
         }   
    }
 }
//code below is to update date payment was received in the visitrepairpayment
public function updateDatePaymentWasReceivedHomeVisitRepair($date,$VisitJobID){

    $query=$this->db->query("UPDATE visitrepairpayments SET Date='$date' where VisitJobID='".$VisitJobID."'");
    }
//****************************************************************************************** */
// code below is to schedule repairs
public function getLastEndTimeFOrAnEmployeeWithDateSelected($EmpID,$DateOfRepair)
    {
        //$query = $this->db->query("SELECT EmpID,DateOFRepair,StartTime,EndTime FROM visitrepairs WHERE VisitJobID=(SELECT max(VisitJobID) FROM visitrepairs WHERE EmpID='".$EmpID."' AND DateOfRepair='".$DateOfRepair."')");
        $query = $this->db->query("SELECT v.EmpID,CONCAT(e.FirstName,'',e.LastName) as Technician,v.DateOFRepair,v.StartTime,v.EndTime FROM visitrepairs v,employees e WHERE v.EmpID=e.EmpID AND VisitJobID=(SELECT max(VisitJobID) FROM visitrepairs WHERE v.ScheduleStatus='Scheduled' AND EmpID='".$EmpID."' AND DateOfRepair='".$DateOfRepair."')");
        return $query->result();
    }

public function getDateOfRepairToUseInTechEndTimeDisplay($VisitJobID)
{
    $query=$this->db->query("SELECT DateOfRepair FROM visitrepairs WHERE VisitJobID='".$VisitJobID."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $DateOfRepair= $row->DateOfRepair;

               return $DateOfRepair;    
        }   
   }
}
public function getEMPIDToUseInTechEndTimeDisplay($VisitJobID)
{
    $query=$this->db->query("SELECT EmpID FROM visitrepairs WHERE VisitJobID='".$VisitJobID."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $EmpID= $row->EmpID;

               return $EmpID;    
        }   
   }
}
//------------------------------------------------------------------------------------------------
//with Sachini
public function getFaultIDToUseInTechEndTimeDisplay($VisitJobID)
{
    $query=$this->db->query("SELECT FaultID FROM visitrepairs WHERE VisitJobID='".$VisitJobID."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $FaultID= $row->FaultID;

               return $FaultID;    
        }   
   }
}     
//-------------------
public function getTimeToRepairFROMFaultIDToUseInTechEndTimeDisplay($FaultID)
{
    $query=$this->db->query("SELECT TimeToRepair FROM repairfaults WHERE FaultID='".$FaultID."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $TimeToRepair= $row->TimeToRepair;

               return $TimeToRepair;    
        }   
   }
} 
//---------------------------------------------------------------------------------------------------
// code below is to show the repairs with in a selected time period
public function viewAllHomeVisitsWithinPeriod($StartDate,$EndDate)
{
   
  
  $query = $this->db->query("SELECT v.VisitJobID,v.FaultID,f.ItemName,f.Fault,v.CustomerID,c.Address,c.Email,v.Warranty,v.DateOfRepair,(v.EmpID) as Technician,v.StartTime,v.EndTime,v.ScheduleStatus FROM visitrepairs v, repairfaults f, Customers c WHERE v.DateOfRepair BETWEEN '".$StartDate."' AND '".$EndDate."' AND v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID ORDER BY DateOfRepair ASC");
// $query = $this->db->query("SELECT * FROM visitrepairs WHERE DateOfRepair BETWEEN '".$StartDate."' AND '".$EndDate."'");
   return $query->result_array();
   
   
}

public function getEndTimeToScheduleByaddingtwoHours($EmpID,$DateOfRepair){
    $query=$this->db->query("SELECT v.EndTime FROM visitrepairs v,employees e WHERE v.EmpID=e.EmpID AND VisitJobID=(SELECT max(VisitJobID) FROM visitrepairs WHERE v.ScheduleStatus='Scheduled' AND EmpID='".$EmpID."' AND DateOfRepair='".$DateOfRepair."')");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $EndTimeL= $row->EndTime;

               return $EndTimeL;    
        }   
   }
}
//*************************************************************** */
//-------------------------------------------------------------------------------------------
//code below is to generate invoice for Home-Visit Repairs
//function below gets the max invoice no from VISITREPAIR PAYMENTS
public function getInvoiceNo(){
    $query=$this->db->query("SELECT InvoiceNo FROM visitrepairpayments WHERE InvoiceNo=(SELECT max(InvoiceNo) FROM visitrepairpayments)");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $InvoiceNo= $row->InvoiceNo;

               return $InvoiceNo;    
        }   
   }
}
//code below is re-used twice : For generating invoice on schedule and after scheduling
public function getScheduleDetailstoInvoiceOnSchedule($InvoiceNo)
{
    $query=$this->db->query("SELECT v.InvoiceNo,v.VisitJobID,CONCAT(c.FirstName,' ',c.LastName) as Customer,c.Email,c.Address,CONCAT(e.FirstName,' ',e.LastName)as Technician,e.NIC,f.ItemName,f.Fault,r.Warranty,r.DateOfRepair,r.StartTime,r.EndTime,v.Payment FROM visitrepairpayments v, visitrepairs r,employees e,repairfaults f, customers c WHERE v.EmpID=e.EmpID AND v.VisitJobID=r.VisitJobID AND v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND v.InvoiceNo='".$InvoiceNo."'");
    return $query->result_array();
}
//----------------------------------------------------------------------------------------------------
//code below is to generate invoice after homevisits have been scheduled for TECHNICIAN reference
public function viewallScheduledRepairstogenerateInvoiceAfterScheduled()

{
    $query=$this->db->query("SELECT v.InvoiceNo, r.VisitJobID,r.FaultID,r.CustomerID,c.Email,c.Address,r.Warranty,v.Payment,r.DateOfRepair,r.EmpID,r.StartTime,r.EndTime FROM visitrepairs r, visitrepairpayments v, customers c WHERE r.VisitJobID=v.VisitJobID AND v.CustomerID=c.CustomerID AND  ScheduleStatus='Scheduled'");
    return $query->result_array();
}
//************************************************************************************* */
//code below is to get details to print invoice on shop repair acceptance

//function below gets the max invoice no from VISITREPAIR PAYMENTS
public function getInvoiceNoForshoprepairs(){
    $query=$this->db->query("SELECT InvoiceNo FROM shoprepairpayments WHERE InvoiceNo=(SELECT max(InvoiceNo) FROM shoprepairpayments)");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $InvoiceNo= $row->InvoiceNo;

               return $InvoiceNo;    
        }   
   }
}
public function getdetailstoInvoiceOnShopRepairAcceptance($InvoiceNo)
{
    $query=$this->db->query("SELECT v.InvoiceNo,v.RepairID,CONCAT(u.FirstName,'',u.LastName)as DEO,CONCAT(c.FirstName,' ',c.LastName) as Customer,c.ContactNo,f.ItemName,f.Fault,r.Description,r.AcceptDate,r.ReturnDate,r.Warranty,r.TotalCost,r.AdvancePaid,r.Balance, CONCAT(e.FirstName,' ',e.LastName)as Technician,v.Date FROM shoprepairpayments v, repairitems r,repairfaults f, customers c, employees e,users u WHERE v.RepairID=r.RepairID AND v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND r.EmpID=e.EmpID AND v.UserID=u.UserID AND v.InvoiceNo='".$InvoiceNo."'");
    return $query->result_array();
}
//-----------------------------------------------------------
//code below is to get details to print invoice on item retutn

public function getdetailstoInvoiceOnShopRepairDelivered($InvoiceNo)

{
    $query=$this->db->query("SELECT v.InvoiceNo,v.RepairID,CONCAT(u.FirstName,'',u.LastName)as DEO,CONCAT(c.FirstName,' ',c.LastName) as Customer,c.ContactNo,f.ItemName,f.Fault,r.Description,CONCAT(e.FirstName,' ',e.LastName)as Technician,r.Warranty,v.Payment,v.Date FROM shoprepairpayments v, repairitems r,repairfaults f, customers c, employees e,users u WHERE v.RepairID=r.RepairID AND v.FaultID=f.FaultID AND v.CustomerID=c.CustomerID AND r.EmpID=e.EmpID AND v.UserID=u.UserID AND v.InvoiceNo='".$InvoiceNo."'");
    return $query->result_array();
}
//-----------------------------------------------------------
//code below is to save the DEO who accepts and returns items accepted at shop for repair

public function getUserIDTosaveinshoprepairpayments($username,$password){
    $query=$this->db->query("SELECT UserID FROM Users WHERE Email ='".$username."' AND PASSWORD='".$password."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $UserID= $row->UserID;

               return $UserID;    
        }   
   }
    
}
//-------------------------------------------------------------
//code below is to get the CustomerID to the schedule home visit repair form
public function getCustomerIDtoHomeVisitRepairs($username){
    $query=$this->db->query("SELECT CustomerID FROM customers WHERE Email ='".$username."'");
    if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               $CustomerID= $row->CustomerID;

               return $CustomerID;    
        }   
   }
    
}



}

?>