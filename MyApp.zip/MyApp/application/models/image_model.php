<?php
class image_model extends CI_Model
{
    public function __construct() 
    {
        /* Call the Model constructor */
        parent::__construct();
    }   

public function getAllModels(){
  
    
    $query = $this->db->query('SELECT Id FROM products');
    return $query->result_array();
}
//********************************************************************************************* */
public function update_items_image($Id,$Image){

    $query=$this->db->query("update products SET Image='$Image' where Id='".$Id."'");
}
//************************************************************************************************
/*function update_dp($ModelNo, $file_name) {
    $this->db->set("image", $file_name);
    $this->db->where("ModelNo", $ModelNo);
    $this->db->update("items");
    $row = $this->db->affected_rows();

    if ($row) {
        return $image_path;
    } else{
        return FALSE;
    }
}*/
//********************************************************************************************
public function getimage() {
    //$this->db->select('*');
    //$this->db->from('items');
    //$query = $this->db->get();
    $query = $this->db->query('SELECT image FROM items WHERE ModelNo="SRS-XB40"');
   
   /* if($query->num_rows() === 1){
        foreach ($query->result() as $row)
        {
               
               //$image = $row->image;

               return $image;    
        }   
   } */
  /*  if($query->num_rows() != 0){
        return $image;
    }else{
        return false;
    }*/
}
//************************************************************************************** */


 
}

