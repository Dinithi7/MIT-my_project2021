<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config = array(
    'protocol' => 'smtp',
    'smtp_host' => 'smtp.gmail.com', 
    'smtp_port' => 465,
    'smtp_user' => 'mymitproject2021@gmail.com',
    'smtp_pass' => '',
    'smtp_crypto' => 'ssl', 
    'mailtype' => 'text', 
    'smtp_timeout' => '4', 
    'charset' => 'iso-8859-1',
    'wordwrap' => TRUE
);
